# psy-foundation protocol

The protocol defines the typed messages and state schemas that flow between
foundation components and devices. It is **transport-agnostic** — the same
schemas work over BroadcastChannel, WebSocket, WebRTC, Web MIDI, or an Ableton
Link adapter.

## Core types

### MusicalTransport

The time model. Owned exclusively by `packages/transport` → `TransportClock`.

```typescript
interface MusicalTransport {
  bpm: number;
  beat: number;          // monotonically increasing
  bar: number;
  beatsPerBar: number;
  beatTime: number;      // musical seconds since beat 0
  barTime: number;
  phase: number;         // 0..1 within current beat
  barPhase: number;      // 0..1 within current bar
  confidence: number;    // 0..1
  locked: boolean;
  revision: number;      // bumps on every correction (deterministic testing)
  origin: { audioTime: number; beatIndex: number; bpm: number };
  lastObservationAgo: number;
  observationCount: number;
}
```

### MusicalEvent

A discriminated union of time-stamped musical events that flow over a Channel.

```typescript
type MusicalEvent =
  | BeatEvent       // { type: 'beat', beat, bar, transport, at }
  | SectionEvent    // { type: 'section', section, bar, at }
  | EnergyEvent     // { type: 'energy', energy, at }
  | DropEvent       // { type: 'drop', intensity, at }
  | NoteEvent       // { type: 'note', note, velocity, duration, channel, at }
  | PatternEvent;   // { type: 'pattern', patternId, trackId, at }
```

### MusicalContext

The musical situation a device is operating in.

```typescript
interface MusicalContext {
  key: string;           // e.g. 'A'
  rootPc: number;        // 0..11 (C=0)
  scale: string;         // e.g. 'phrygian-dominant'
  energy: number;        // 0..1
  style: string;         // e.g. 'full-on'
  section: string;       // e.g. 'drop'
  beatsPerBar: number;
}
```

### DeviceCapabilities

What a device can do. Advertised via `PsyDevice.capabilities()`.

```typescript
interface DeviceCapabilities {
  audio: boolean;
  midi: boolean;
  inputs: number;
  outputs: number;
  voices: number;
  latencyMs: number;
  roles: string[];       // e.g. ['kick', 'bass', 'lead']
}
```

### Material

A unit of reusable musical content with metadata.

```typescript
interface Material {
  id: string;
  type: MaterialType;    // 'motif' | 'rhythm' | 'bass-pattern' | ...
  role: string;
  style: string;
  tempoRange: [number, number];
  keyCompatibility: number[];
  energy: number;
  novelty: number;
  source: string;
  confidence: number;
  usageCount: number;
  reward: number;
  lastUsed: number | null;
  payload: unknown;      // type-specific (see packages/material/src/types.ts)
}
```

### MusicalAction

An action a device or orchestrator can take. **DO NOTHING is legal.**

```typescript
type MusicalAction =
  | { type: 'play'; materialId: string }
  | { type: 'variation'; materialId: string; transform: string }
  | { type: 'do-nothing' };
```

### Experience

A recorded learning experience.

```typescript
interface Experience {
  context: MusicalContext;
  action: MusicalAction;
  outcome: MusicalOutcome;
  reward: number;        // -1..1
  at: number;
}
```

## Channel abstraction

The messaging transport. Distinct from the musical transport (time model).

```typescript
interface Channel {
  subscribe(listener: (event: MusicalEvent) => void): Unsubscribe;
  publish(event: MusicalEvent): void;
  close(): void;
  readonly name: string;
}
```

`InMemoryChannel` is the reference implementation. Future adapters
(BroadcastChannel, WebSocket, WebRTC, Web MIDI, Ableton Link) implement this
same interface.

## Data flow

```
RADIO → OBSERVATION → ESTIMATION → MUSICAL TRANSPORT → LOCAL SCHEDULER → AUDIO
                         ↓                ↓
                    MusicalEvent    DeviceHost.pushTransport()
                         ↓                ↓
                    Channel  ──→  PsyDevice.onEvent()
                                     PsyDevice.onTransport()
```

## Ownership matrix

| State | Owner | Readers |
| --- | --- | --- |
| transport | `packages/transport` → TransportClock | all devices (read-only) |
| musical context | `packages/music` → MusicalContextStore | devices, scheduler, learning |
| analysis features | `packages/analysis` → FeatureStore | transport estimator, music inference |
| arrangement | `packages/scheduler` → ArrangementStore | devices |
| scheduled events | `packages/scheduler` → Scheduler | audio renderers |
| device state | the device itself | foundation reads only capabilities |
| learning state | `packages/learning` → ExperienceStore | music/scheduler (advisory) |
| audio time | `packages/dsp` → AudioClock | scheduler only |

Anything not in this table does not exist as owned state.
