# psy-foundation architecture

## Origin
Built from the forensic audit of 7 existing PSY-family repositories (psy, psy3-clean, psy4, psy5, forge, nova, PromptForge). Full audit findings in the project worklog.

## What we extracted (verified by reading code, not READMEs)
- BeatPLL (octave-error folding) ← psy4/src/lib/beatPLL.ts → packages/transport
- Forensic DSP cluster ← psy4/src/lib/studio/engine/forensic/* → packages/analysis, packages/dsp (future)
- Lead motif generator ← psy/index.html:200-281 → packages/music/motif.ts
- PooledEngine pattern ← psy5/index.html:354-372 → packages/dsp (future)
- Step/Pattern schema ← psy5/index.html:160-186 → packages/material, packages/scheduler

## What we retired
- psy4EngineV2.ts (5485 lines, dead hub) + glue
- Worklet wrappers + pooledEngine (orphan)
- psy4 audit-reports/*.md (fabricated test results)
- psy3-clean (4-line patch of psy)
- psy5 state model (origin of multi-source-of-truth disease)
- forge (vaporware) — only Prisma skeleton worth keeping
- PromptForge (Python, separate universe)

## Security
- nova/nova-server.cjs commits a live Z.AI session JWT in a public sibling repo → rotate + scrub.
- psy4/.env committed but only contains local SQLite path (hygiene, not leak).
- All other env usage clean.

## Ownership matrix (single source of truth)
- transport (beat/bar/phase/bpm/confidence) → packages/transport → TransportClock
- musical context (key/scale/energy/style/section) → packages/music → MusicalContextStore
- analysis features → packages/analysis → FeatureStore
- arrangement → packages/scheduler → ArrangementStore
- scheduled events → packages/scheduler → Scheduler
- device state → the device itself
- learning state → packages/learning (M4, future) → ExperienceStore
- audio time → packages/dsp (M5, future) → AudioClock

## Build order
- M0 forensic audit ✓
- M1 transport · protocol · device-sdk · fixtures ✓
- M2 scheduler · analysis ✓
- M3 music · material ✓
- M4 learning (future)
- M5 dsp (future)
- M6 reference-lab · sync-lab · benchmark-lab (future)

## Rules
1. Investigation before code.
2. One source of truth per piece of musical state.
3. Radio is observer, not clock.
4. Transport ≠ renderer ≠ radio ≠ UI.
5. No device policy.
6. Every claim has evidence.
