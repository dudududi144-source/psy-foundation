# Contributing to psy-foundation

## Non-negotiable rules

1. **Investigation before code.** No copying because a name sounds right. Read the actual code.
2. **No monolith.** Every package has an explicit API, tests, and real usage.
3. **One source of truth.** Every piece of musical state has exactly one owner. The DOM is a pure projection. Macros are an *intent* layer resolved at trigger time, never in-place mutations of model fields.
4. **Radio is observer, not clock.** `RADIO → OBSERVATION → ESTIMATION → MUSICAL TRANSPORT → LOCAL SCHEDULER → AUDIO`.
5. **Transport ≠ renderer ≠ radio ≠ UI.** Transport is the musical time model, nothing else.
6. **No device policy.** If a feature looks like "another device", it does not belong here.
7. **Every claim has evidence.** "real-time" requires a benchmark. "AI" requires context/action/outcome/reward. "commercial quality" requires A/B. "production ready" requires tests.

## Development setup

```bash
bun install
bun test          # run all 250 tests
bun run lint      # biome check
bun run typecheck # tsc --noEmit per package
```

## Adding a new package

1. Create `packages/<name>/` with `src/`, `tests/`, `package.json`, `tsconfig.json`.
2. Add the package to the root `workspaces` (already covers `packages/*`).
3. Write the API in `src/index.ts` — explicit exports, `verbatimModuleSyntax`-safe.
4. Write tests in `tests/<name>.test.ts`. Every public function needs at least one test.
5. Run `bun test`, `bun run typecheck`, `bunx biome check src` — all must pass.
6. Add the package to the README table.
7. Commit with a message following the pattern: `M<N>: <package> — <one-line summary>`.

## Commit message convention

```
M<N>: <package name> — <short summary>

<bullet points describing what was added>
```

Examples:
- `M5: dsp package — oscillators, filters, envelopes, FX, metering, voice pool`
- `fix: transport octave-fold threshold was too tight for 60bpm`

## Running benchmarks

```bash
bun run benchmarks:transport   # transport accuracy across 14 fixtures
bun run benchmarks:analysis    # analysis pipeline accuracy
bun apps/benchmark-lab/src/index.ts  # full benchmark suite
```

## Security

- **Never commit secrets.** `.env` files are gitignored. If you accidentally commit a credential, scrub it from history with `git filter-repo`.
- Tokens go in environment variables, never in code or config files.
- If you find an exposed credential in the repo, rotate it immediately and report it.

## What does NOT belong here

- Another device (synth, drum machine, groovebox) — that's a PSY DEVICE, not foundation.
- UI components — foundation is headless.
- Radio stream handling — that's an observer feeding the transport.
- Presets for specific synths — use the `material` package schema instead.
- Neural networks — the `learning` package is a contextual bandit, not ML.

## License

By contributing, you agree that your contributions are licensed under the MIT License.
