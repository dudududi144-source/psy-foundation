# psy-foundation

Shared musical infrastructure for the PSY device family. Not a device — the gravity every PSY device is built on.

## Packages (M0–M3)

| Package | Milestone | Tests | Purpose |
| --- | --- | --- | --- |
| transport | M1 | 12 | MusicalTransport: beat/bar/phase/bpm/confidence. Observer-fed PLL. |
| protocol | M1 | 8 | MusicalEvent types + Channel abstraction. Transport-agnostic. |
| device-sdk | M1 | 12 | PsyDevice interface + DeviceHost + ReferenceDevice. |
| fixtures | M1 | 10 | 14 synthetic radio fixtures (deterministic). |
| scheduler | M2 | 18 | MusicalPlan → ScheduledEvent[]. Deterministic pure function. |
| analysis | M2 | 26 | onset/beat/tempo/pitch/chroma/spectral features. Multi-hypothesis tempo. |
| music | M3 | 43 | 18 scales, 18 chords, motif generator, variation ops, bass grammar. |
| material | M3 | 23 | 9 material kinds + MaterialLibrary + seed library. |

**152 tests total. All green.**

## Rules
1. Investigation before code.
2. One source of truth per piece of musical state.
3. Radio is observer, not clock.
4. Transport ≠ renderer ≠ radio ≠ UI.
5. No device policy.
6. Every claim has evidence.

## Status
M0 (forensic audit) ✓ · M1 (transport/protocol/device-sdk/fixtures) ✓ · M2 (scheduler/analysis) ✓ · M3 (music/material) ✓
