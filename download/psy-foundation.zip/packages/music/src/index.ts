// Scales and modes
export {
  type Scale,
  SCALES,
  NOTE_NAMES,
  degreeToMidi,
  degreeToPc,
  getScale,
  isInScale,
  listScales,
  nameToPc,
  nearestDegree,
  pcToName,
  scaleNotes,
  scalePcs,
  stableDegrees,
} from './scales.ts'

// Chords
export {
  type ChordType,
  CHORD_TYPES,
  chordNotes,
  chordPcs,
  chordTension,
  getChordType,
  listChordTypes,
  voiceChord,
} from './chords.ts'

// RNG
export { Rng } from './rng.ts'

// Motif
export {
  type MotifNote,
  type MotifOptions,
  type MotifTransform,
  allInScale,
  fragment,
  generateMotif,
  invert,
  retrograde,
  transpose,
  vary,
} from './motif.ts'

// Bass
export {
  type BassNote,
  type BassPatternOptions,
  type BassStyle,
  type TensionCurve,
  generateBassPattern,
  sampleTension,
  tensionToDensity,
  tensionToOctave,
} from './bass.ts'

// Rhythm
export {
  type RhythmOptions,
  type RhythmPattern,
  backbeat,
  combine,
  density,
  drivingHats,
  fourOnFloor,
  humanize,
  invertRhythm,
  offbeatHats,
  psyKick,
  rhythm,
  swing,
} from './rhythm.ts'

// MusicalContext (v2 substrate)
export {
  type MusicalContext,
  createMusicalContext,
  hasChord,
} from './musical-context.ts'

// Structural Motif (v2)
export {
  type CreateMotifOptions,
  type Motif,
  type MotifNote as MotifNoteV2,
  createMotif,
  motifIdentity,
  motifSimilarity,
} from './motif-v2.ts'

// MotifMemory
export {
  type IngestOptions,
  type MotifMemoryEntry,
  MotifMemory,
} from './motif-memory.ts'

// Transformations
export {
  callResponse,
  contourMutation,
  invert as invertMotifV2,
  isScaleSnapped,
  intervalSubstitution,
  motifScale,
  refreshMotif,
  retrograde as retrogradeMotifV2,
  rhythmicDisplacement,
  rhythmicStretch,
  shiftRegister,
  transpose as transposeMotifV2,
} from './transformation.ts'

// PhrasePlanner
export {
  type PhrasePlan,
  type PhrasePlanOptions,
  type PhraseRole,
  type PhraseSlot,
  applyTransformId,
  contextDegreeToMidi,
  contextStableDegrees,
  generateMotifV2,
  planPhrase,
  renderPhraseNotes,
  renderSectionNotes as renderPhraseSectionNotes,
} from './phrase-planner.ts'

// SectionPlanner
export {
  type SectionPlan,
  type SectionPlanOptions,
  type SectionRole,
  type SectionSlot,
  planSection,
  renderSectionNotes,
} from './section-planner.ts'

// Diversity metrics
export {
  type MeasureOptions,
  type MusicalityHealthReport,
  type MusicalityMetrics,
  MUSICALITY_BOUNDS,
  healthReport,
  measureMusicality,
} from './diversity.ts'

// CandidateScorer
export {
  type CandidateScore,
  type CandidateScoreBreakdown,
  type CandidateScorerOptions,
  CandidateScorer,
  contextScalePcs,
} from './candidate-scorer.ts'
