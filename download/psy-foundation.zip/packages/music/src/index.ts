// Scales and modes
export {
  type Scale,
  SCALES,
  NOTE_NAMES,
  degreeToMidi,
  degreeToPc,
  getScale,
  isInScale,
  listScales,
  nameToPc,
  nearestDegree,
  pcToName,
  scaleNotes,
  scalePcs,
  stableDegrees,
} from './scales.ts'

// Chords
export {
  type ChordType,
  CHORD_TYPES,
  chordNotes,
  chordPcs,
  chordTension,
  getChordType,
  listChordTypes,
  voiceChord,
} from './chords.ts'

// RNG
export { Rng } from './rng.ts'

// Motif
export {
  type MotifNote,
  type MotifOptions,
  type MotifTransform,
  allInScale,
  fragment,
  generateMotif,
  invert,
  retrograde,
  transpose,
  vary,
} from './motif.ts'

// Bass
export {
  type BassNote,
  type BassPatternOptions,
  type BassStyle,
  type TensionCurve,
  generateBassPattern,
  sampleTension,
  tensionToDensity,
  tensionToOctave,
} from './bass.ts'

// Rhythm
export {
  type RhythmOptions,
  type RhythmPattern,
  backbeat,
  combine,
  density,
  drivingHats,
  fourOnFloor,
  humanize,
  invertRhythm,
  offbeatHats,
  psyKick,
  rhythm,
  swing,
} from './rhythm.ts'
