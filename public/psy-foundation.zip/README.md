# psy-foundation

Shared musical infrastructure for the PSY device family.

This is **not** a device. It is the **gravity** that every future PSY device
(PSY6, drums, sampler, FX, …) is built on top of.

> SHARED TIME · SHARED PROTOCOL · SHARED MUSICAL LANGUAGE · SHARED MATERIAL ·
> SHARED LEARNING PRIMITIVES — but every device stays LOCAL, DETERMINISTIC,
> INDEPENDENT, MUSICAL.

## What lives here

| Package | Purpose | Milestone |
| --- | --- | --- |
| `packages/transport` | Musical time model: beat / bar / phase / bpm / confidence / revision. Observer-fed, not radio-clock-fed. | M1 |
| `packages/protocol` | Typed events (`MusicalEvent`, `MusicalContext`, `DeviceCapabilities`, …) + `Channel` abstraction (transport-agnostic messaging). | M1 |
| `packages/device-sdk` | `PsyDevice` interface, subscription host, capability discovery, local scheduling, latency reporting, graceful degradation. | M1 |
| `packages/fixtures` | Synthetic radio corpus: 150 BPM perfect, jitter, ramp, jump, missing beat, false kick, half/double time, gaps, sparse, dense, drop, breakdown. | M1 |
| `packages/scheduler` | `MusicalTransport` + `MusicalPlan` → `ScheduledEvent[]`. Deterministic. Knows nothing about React / UI / radio / presets. | M2 |
| `packages/analysis` | onset · beat · tempo · phase · pitch · chroma · spectral flux/centroid/flatness · energy · transient density · bass activity · role occupancy · section boundaries. SIGNAL → FEATURES → INFERENCE. | M2 |
| `packages/music` | scales · modes · intervals · chords · harmony · contour · rhythm grammar · groove · motif · phrase · variation · transposition · inversion · fragmentation · call/response · bass grammar · tension curves. STRUCTURED VARIATION, not random. | M3 |
| `packages/material` | `Motif` · `Rhythm` · `BassPattern` · `DrumPattern` · `Fill` · `Phrase` · `FXGesture` · `Preset` · `Texture` + metadata schema. Reusable across devices. | M3 |
| `packages/learning` | CONTEXT + ACTION + OUTCOME + REWARD. `DO NOTHING` is a legal action. Learns what worked in which context / style / energy / role. | M4 |
| `packages/dsp` | band-limited osc · PolyBLEP · PeriodicWave · FM · wavetable · filters · envelopes · DC blocker · saturation · delay · reverb · stereo · metering · voice lifecycle. AudioWorklet only where measured-necessary. | M5 |
| `apps/reference-lab` | Browser research tool: feed stream/audio → BPM, beat grid, phase, confidence, key candidates, energy, spectral features, role occupancy, melody candidates, motifs, sections. | M6 |
| `apps/sync-lab` | Simulate devices A/B/C → BPM, beat, bar, phase, audio time, network offset, jitter, drift, relock. | M6 |
| `apps/benchmark-lab` | Timing / runtime / music / learning benchmarks. Real numbers, never `console.log`. | M6 |

## Non-negotiable rules

1. **Investigation before code.** No copying because a name sounds right.
2. **No monolith.** Every package has an explicit API, tests, and real usage.
3. **One source of truth.** Every piece of musical state has exactly one owner.
   The DOM is a pure projection. Macros are an *intent* layer resolved at
   trigger time, never in-place mutations of model fields.
4. **Radio is observer, not clock.**
   `RADIO → OBSERVATION → ESTIMATION → MUSICAL TRANSPORT → LOCAL SCHEDULER → AUDIO`.
   `observedBeatTime`, `estimatedBeatTime`, and `predictedBeatTime` never mix
   with `AudioContext.currentTime` without explicit latency compensation.
5. **Transport ≠ AudioRenderer ≠ Radio ≠ UI.** Transport is the musical time
   model, nothing else.
6. **No device policy.** If a feature looks like "another device", it does not
   belong here.
7. **Every claim has evidence.** "real-time" requires a benchmark. "AI" requires
   context/action/outcome/reward. "commercial quality" requires A/B.
   "production ready" requires tests.

## Relation to the rest of the PSY family

```
                    psy-foundation
                          │
             ┌────────────┼────────────┐
             │            │            │
          TRANSPORT     MUSIC        AUDIO
             │            │            │
             └────────────┼────────────┘
                          │
                      DEVICE SDK
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
       PSY6             DRUMS             SAMPLER
        │                 │                 │
        └─────────────────┼─────────────────┘
                          │
                         FX
                          │
                    FUTURE DEVICES
```

- **NOVA** — generation / orchestration (agent layer). Sibling, not a dependency.
- **FORGE** — validation / CI / delivery. Foundation publishes a benchmark
  contract that Forge consumes.
- **PSY DEVICES** — products built on this foundation.

## Status

**Milestone 0 (forensic audit)** — complete. See `docs/architecture/forensic-audit.md`.

**Milestone 1 (transport · protocol · device-sdk · fixtures)** — in progress.

## License

Proprietary. PSY family.
