/**
 * DSP primitives for analysis. Pure TS, no AudioWorklet, no dependencies.
 *
 * These are deliberately NOT optimized for real-time audio-thread use — they
 * run on the main thread / worker over analysis windows (typically 1024-4096
 * samples). For audio-thread DSP, see packages/dsp (M5).
 */

/** Apply a Hann window in-place. */
export function hannWindow(buf: Float32Array): void {
  const n = buf.length
  for (let i = 0; i < n; i++) {
    buf[i] = buf[i] * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (n - 1)))
  }
}

/** Magnitude spectrum from a complex FFT output (interleaved real/imag). */
export function magnitudeSpectrum(real: Float32Array, imag: Float32Array): Float32Array {
  const n = real.length
  const out = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    out[i] = Math.sqrt(real[i] * real[i] + imag[i] * imag[i])
  }
  return out
}

/**
 * In-place radix-2 Cooley-Tukey FFT.
 * `real` and `imag` must be the same length, which must be a power of 2.
 */
export function fft(real: Float32Array, imag: Float32Array): void {
  const n = real.length
  if (n <= 1) return
  if ((n & (n - 1)) !== 0) {
    throw new Error(`fft: length must be power of 2, got ${n}`)
  }

  // Bit reversal.
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1
    for (; j & bit; bit >>= 1) {
      j ^= bit
    }
    j ^= bit
    if (i < j) {
      const tr = real[i]
      real[i] = real[j]
      real[j] = tr
      const ti = imag[i]
      imag[i] = imag[j]
      imag[j] = ti
    }
  }

  // Butterfly.
  for (let len = 2; len <= n; len <<= 1) {
    const half = len >> 1
    const angle = (-2 * Math.PI) / len
    const wReal = Math.cos(angle)
    const wImag = Math.sin(angle)
    for (let i = 0; i < n; i += len) {
      let curReal = 1
      let curImag = 0
      for (let k = 0; k < half; k++) {
        const aReal = real[i + k]
        const aImag = imag[i + k]
        const bReal = real[i + k + half]
        const bImag = imag[i + k + half]
        const tReal = curReal * bReal - curImag * bImag
        const tImag = curReal * bImag + curImag * bReal
        real[i + k] = aReal + tReal
        imag[i + k] = aImag + tImag
        real[i + k + half] = aReal - tReal
        imag[i + k + half] = aImag - tImag
        const nextReal = curReal * wReal - curImag * wImag
        curImag = curReal * wImag + curImag * wReal
        curReal = nextReal
      }
    }
  }
}

/** Compute the magnitude spectrum of a windowed frame. */
export function spectrum(frame: Float32Array): Float32Array {
  const n = frame.length
  const real = new Float32Array(n)
  const imag = new Float32Array(n)
  for (let i = 0; i < n; i++) real[i] = frame[i]
  hannWindow(real)
  fft(real, imag)
  return magnitudeSpectrum(real, imag)
}
