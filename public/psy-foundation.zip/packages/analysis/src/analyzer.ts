/**
 * Analyzer — stateful stream wrapper over the analysis primitives.
 *
 * Feed it audio frames via {@link Analyzer.ingest}; query features / onsets /
 * inference via getters. Designed for real-time use (one frame per animation
 * tick or audio callback), but the analysis itself is frame-by-frame and
 * deterministic.
 *
 * This is the public API of the analysis package. Labs and devices use this;
 * they do not call the primitives directly.
 */

import { spectrum } from './dsp.ts'
import {
  bassActivity,
  highEnergy,
  lowMidEnergy,
  rmsEnergy,
  spectralCentroid,
  spectralFlatness,
  spectralFlux,
  zeroCrossingRate,
} from './features.ts'
import { detectSectionBoundaries, inferMusical, refineTempoWithContext } from './inference.ts'
import type { MusicalInference, SectionLabel } from './inference.ts'
import { detectOnsets } from './onset.ts'
import type { Onset } from './onset.ts'
import { chroma, detectPitch, dominantPitchClass } from './pitch.ts'
import type { PitchEstimate } from './pitch.ts'
import { estimateTempo, pickMusicalWinner } from './tempo.ts'
import type { TempoHypothesis } from './tempo.ts'

export interface AnalyzerOptions {
  sampleRate: number
  frameSize?: number
  hopSize?: number
  /** How many recent onsets to keep (for role inference). Default 64. */
  onsetHistorySize?: number
  /** How many recent sections to keep (for boundary detection). Default 32. */
  sectionHistorySize?: number
}

export interface AnalyzerFrame {
  /** Audio time (seconds) of the frame center. */
  at: number
  rms: number
  centroidHz: number
  flatness: number
  zcr: number
  bass: number
  lowMid: number
  high: number
  flux: number
}

const DEFAULTS: Required<AnalyzerOptions> = {
  sampleRate: 44100,
  frameSize: 1024,
  hopSize: 512,
  onsetHistorySize: 64,
  sectionHistorySize: 32,
}

export class Analyzer {
  private readonly opts: Required<AnalyzerOptions>
  private prevMag: Float32Array | null = null
  private _frameCount = 0
  private readonly onsetHistory: Onset[] = []
  private readonly sectionHistory: SectionLabel[] = []
  private readonly _fluxHistory: number[] = []
  private lastFrame: AnalyzerFrame | null = null
  private lastInference: MusicalInference | null = null
  private lastPitch: PitchEstimate | null = null
  private lastChroma: Float32Array | null = null

  constructor(opts: AnalyzerOptions) {
    this.opts = { ...DEFAULTS, ...opts }
  }

  /**
   * Ingest a frame of audio samples. Returns the extracted features for this
   * frame. Also updates internal history (onsets, sections, flux).
   */
  ingest(frame: Float32Array): AnalyzerFrame {
    const { sampleRate, frameSize } = this.opts
    const mag = spectrum(frame)
    const at = this.frameCount * (this.opts.hopSize / sampleRate) + frameSize / 2 / sampleRate

    const rms = rmsEnergy(frame)
    const centroidHz = spectralCentroid(mag, sampleRate)
    const flatness = spectralFlatness(mag)
    const zcr = zeroCrossingRate(frame)
    const bass = bassActivity(mag, sampleRate)
    const lowMid = lowMidEnergy(mag, sampleRate)
    const high = highEnergy(mag, sampleRate)
    const flux = this.prevMag ? spectralFlux(this.prevMag, mag) : 0

    this._fluxHistory.push(flux)
    if (this._fluxHistory.length > 128) this._fluxHistory.shift()
    this.prevMag = mag

    const out: AnalyzerFrame = { at, rms, centroidHz, flatness, zcr, bass, lowMid, high, flux }
    this.lastFrame = out
    this._frameCount += 1

    // Onset detection on the full signal is done at the caller level (over
    // the whole signal); here we just keep the latest frame for the inference
    // layer. For real-time onset detection, the caller should run detectOnsets
    // periodically over a sliding window.
    this.lastInference = inferMusical(mag, sampleRate, this.onsetHistory.slice(-32))
    this.lastChroma = chroma(mag, sampleRate)
    this.lastPitch = detectPitch(frame, sampleRate)

    // Track section changes.
    const section = this.lastInference.section
    if (
      this.sectionHistory.length === 0 ||
      this.sectionHistory[this.sectionHistory.length - 1] !== section
    ) {
      this.sectionHistory.push(section)
      if (this.sectionHistory.length > this.opts.sectionHistorySize) this.sectionHistory.shift()
    }

    return out
  }

  /** Push a detected onset into the history (used when the caller runs
   *  detectOnsets over a sliding window and feeds results here). */
  pushOnset(onset: Onset): void {
    this.onsetHistory.push(onset)
    if (this.onsetHistory.length > this.opts.onsetHistorySize) this.onsetHistory.shift()
  }

  /** Run onset detection over a longer signal and merge results into history. */
  detectOnsetsIn(signal: Float32Array): Onset[] {
    const onsets = detectOnsets(signal, {
      sampleRate: this.opts.sampleRate,
      frameSize: this.opts.frameSize,
      hopSize: this.opts.hopSize,
    })
    for (const o of onsets) this.pushOnset(o)
    return onsets
  }

  /** Estimate tempo from accumulated onsets. */
  estimateTempo(): { best: TempoHypothesis | null; top: TempoHypothesis[] } {
    if (this.onsetHistory.length < 2) return { best: null, top: [] }
    const result = estimateTempo(this.onsetHistory)
    if (result.best) {
      const refined = refineTempoWithContext(result.best, this.onsetHistory)
      const top = result.top.map((h) => refineTempoWithContext(h, this.onsetHistory))
      return { best: refined, top }
    }
    return result
  }

  /** Pick the musical winner from the current tempo hypotheses. */
  musicalTempo(): TempoHypothesis | null {
    const { top } = this.estimateTempo()
    return pickMusicalWinner(top)
  }

  // ── Getters (latest state) ──

  get latestFrame(): AnalyzerFrame | null {
    return this.lastFrame
  }
  get latestInference(): MusicalInference | null {
    return this.lastInference
  }
  get latestPitch(): PitchEstimate | null {
    return this.lastPitch
  }
  get latestChroma(): Float32Array | null {
    return this.lastChroma
  }
  get latestDominantPitchClass(): { name: string; pc: number; strength: number } | null {
    return this.lastChroma ? dominantPitchClass(this.lastChroma) : null
  }
  get onsets(): readonly Onset[] {
    return this.onsetHistory
  }
  get sections(): readonly SectionLabel[] {
    return this.sectionHistory
  }
  get sectionBoundaries(): number[] {
    return detectSectionBoundaries(this.sectionHistory)
  }
  get fluxHistory(): readonly number[] {
    return this._fluxHistory
  }

  get sampleRate(): number {
    return this.opts.sampleRate
  }
  get frameSize(): number {
    return this.opts.frameSize
  }
  get frameCount(): number {
    return this._frameCount
  }

  /** Reset all history. */
  reset(): void {
    this.prevMag = null
    this._frameCount = 0
    this.onsetHistory.length = 0
    this.sectionHistory.length = 0
    this._fluxHistory.length = 0
    this.lastFrame = null
    this.lastInference = null
    this.lastPitch = null
    this.lastChroma = null
  }
}

export type { MusicalInference, SectionLabel, EnergyClass, RoleOccupancy } from './inference.ts'
export type { Onset } from './onset.ts'
export type { TempoHypothesis } from './tempo.ts'
export type { PitchEstimate } from './pitch.ts'
