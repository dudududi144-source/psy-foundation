/**
 * Onset detector — finds transient events (kick hits, drum strikes) in a
 * time-domain signal. Uses spectral flux with an adaptive threshold.
 *
 * Output: a list of onset times (seconds) and their strengths. These feed the
 * tempo tracker / transport as `BeatObservation`s.
 *
 * This is the SIGNAL → ONSET layer. It does NOT decide bpm or phase — that's
 * the tempo tracker's job.
 */

import { spectrum } from './dsp.ts'
import { spectralFlux } from './features.ts'

export interface Onset {
  /** Time in seconds. */
  at: number
  /** Strength 0..1 (normalized). */
  strength: number
}

export interface OnsetDetectorOptions {
  sampleRate: number
  /** FFT frame size (power of 2). Default 1024. */
  frameSize?: number
  /** Hop size in samples. Default 512. */
  hopSize?: number
  /** Adaptive threshold multiplier: a flux sample is an onset if it exceeds
   *  median(localWindow) * threshold. Default 1.5. */
  threshold?: number
  /** Local window length (in hops) for median threshold. Default 20 (~230ms at 44.1k/512). */
  localWindow?: number
  /** Min inter-onset interval (seconds) to suppress double-triggers. Default 0.05. */
  minIntervalSec?: number
}

const DEFAULTS: Required<OnsetDetectorOptions> = {
  sampleRate: 44100,
  frameSize: 1024,
  hopSize: 512,
  threshold: 1.5,
  localWindow: 20,
  minIntervalSec: 0.05,
}

export function detectOnsets(signal: Float32Array, opts: OnsetDetectorOptions): Onset[] {
  const o = { ...DEFAULTS, ...opts }
  const { sampleRate, frameSize, hopSize, threshold, localWindow, minIntervalSec } = o

  // Compute flux per hop.
  const flux: number[] = []
  const times: number[] = []
  let prevMag: Float32Array | null = null
  const frame = new Float32Array(frameSize)

  for (let start = 0; start + frameSize <= signal.length; start += hopSize) {
    for (let i = 0; i < frameSize; i++) {
      frame[i] = signal[start + i] ?? 0
    }
    const mag = spectrum(frame)
    if (prevMag) {
      flux.push(spectralFlux(prevMag, mag))
      times.push(start / sampleRate + frameSize / 2 / sampleRate)
    }
    prevMag = mag
  }

  if (flux.length === 0) return []

  // Adaptive threshold: rolling median of |localWindow| samples.
  // A flux sample is a peak candidate if it exceeds median * threshold.
  const peaks = findPeaks(flux, times, threshold, localWindow)

  // Suppress peaks too close together (min interval).
  const minIntervalSamples = minIntervalSec // already in seconds
  const result: Onset[] = []
  // Normalize strengths to 0..1.
  let maxStrength = 1e-12
  for (const p of peaks) if (p.strength > maxStrength) maxStrength = p.strength

  for (const p of peaks) {
    if (result.length === 0 || p.at - result[result.length - 1].at >= minIntervalSamples) {
      result.push({ at: p.at, strength: p.strength / maxStrength })
    } else if (p.strength > result[result.length - 1].strength) {
      // Replace the previous peak if this one is stronger and closer than minInterval.
      result[result.length - 1] = { at: p.at, strength: p.strength / maxStrength }
    }
  }
  return result
}

interface Peak {
  at: number
  strength: number
}

function findPeaks(flux: number[], times: number[], threshold: number, windowSize: number): Peak[] {
  const peaks: Peak[] = []
  const half = Math.floor(windowSize / 2)
  for (let i = 0; i < flux.length; i++) {
    const lo = Math.max(0, i - half)
    const hi = Math.min(flux.length - 1, i + half)
    const localMedian = median(flux.slice(lo, hi + 1))
    const candidate = flux[i]
    if (candidate > localMedian * threshold && candidate > 0) {
      // Local maximum check: must be >= neighbors.
      const left = i > 0 ? flux[i - 1] : 0
      const right = i < flux.length - 1 ? flux[i + 1] : 0
      if (candidate >= left && candidate >= right) {
        peaks.push({ at: times[i] ?? 0, strength: candidate })
      }
    }
  }
  return peaks
}

function median(arr: number[]): number {
  if (arr.length === 0) return 0
  const sorted = [...arr].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  if (sorted.length % 2 === 0) {
    const a = sorted[mid - 1] ?? 0
    const b = sorted[mid] ?? 0
    return (a + b) / 2
  }
  return sorted[mid] ?? 0
}
