/**
 * Multi-hypothesis tempo tracker.
 *
 * PROBLEM (from M1 benchmark): a single-hypothesis PLL like TransportClock's
 * BeatEstimator can lock to half-time when the input is sparse (kicks only on
 * beats 1 and 3 of a bar). The octave-fold logic only triggers when the
 * current estimate is *near* 2x or 0.5x the observed interval — but if the
 * estimate has already drifted, the fold never fires.
 *
 * SOLUTION: maintain multiple tempo hypotheses simultaneously (base, ×2, ÷2),
 * score each by phase consistency with the onset stream, and pick the winner.
 * This is the classic beat-tracking approach (e.g. Ellis 2007, Davies-Plumbley).
 *
 * This is the SIGNAL → INFERENCE layer. It does NOT own transport state — it
 * emits a {@link TempoHypothesis} that the TransportClock (or a higher layer)
 * can use to seed / correct itself.
 */

import type { Onset } from './onset.ts'

export interface TempoHypothesis {
  bpm: number
  /** Phase offset in beats, 0..1, relative to the first onset. */
  phase: number
  /** Score 0..1 — how well this hypothesis fits the onsets. */
  score: number
}

export interface TempoTrackerOptions {
  /** Min bpm to consider. Default 60. */
  minBpm?: number
  /** Max bpm to consider. Default 200. */
  maxBpm?: number
  /** Step size for bpm grid. Default 0.5 bpm. */
  bpmStep?: number
  /** Octave hypotheses to also score: [1] only, or [0.5, 1, 2]. Default [0.5, 1, 2]. */
  octaves?: number[]
}

const DEFAULTS: Required<TempoTrackerOptions> = {
  minBpm: 60,
  maxBpm: 200,
  bpmStep: 0.5,
  octaves: [0.5, 1, 2],
}

/**
 * Estimate tempo from onsets using a multi-hypothesis approach.
 *
 * Algorithm:
 *  1. For each candidate bpm in [minBpm, maxBpm] (step bpmStep):
 *     - For each octave in `octaves`:
 *       - Compute the phase (in beats, 0..1) that best aligns the first onset
 *         to a beat boundary, by minimizing the sum of squared distances from
 *         each onset to its nearest beat.
 *       - Score = 1 - normalizedError.
 *  2. Return the (bpm, octave, phase) with the highest score.
 *  3. Also return the top-N runners-up (for debugging / lab display).
 */
export function estimateTempo(
  onsets: Onset[],
  opts: TempoTrackerOptions = {}
): {
  best: TempoHypothesis | null
  top: TempoHypothesis[]
} {
  const o = { ...DEFAULTS, ...opts }
  if (onsets.length < 2) return { best: null, top: [] }

  const candidates: TempoHypothesis[] = []
  for (let bpm = o.minBpm; bpm <= o.maxBpm; bpm += o.bpmStep) {
    for (const octave of o.octaves) {
      const candidateBpm = bpm * octave
      if (candidateBpm < o.minBpm || candidateBpm > o.maxBpm) continue
      const { phase, score } = scoreHypothesis(onsets, candidateBpm)
      candidates.push({ bpm: candidateBpm, phase, score })
    }
  }

  candidates.sort((a, b) => b.score - a.score)
  const top = candidates.slice(0, 5)
  return { best: candidates[0] ?? null, top }
}

function scoreHypothesis(onsets: Onset[], bpm: number): { phase: number; score: number } {
  const secPerBeat = 60 / bpm
  const t0 = onsets[0].at

  // Try 16 phase offsets evenly distributed in [0, 1) beats.
  const PHASE_STEPS = 16
  let bestPhase = 0
  let bestError = Number.POSITIVE_INFINITY

  for (let p = 0; p < PHASE_STEPS; p++) {
    const phase = p / PHASE_STEPS
    let error = 0
    for (const onset of onsets) {
      const dt = onset.at - t0
      const beatFloat = dt / secPerBeat + phase
      const nearest = Math.round(beatFloat)
      const dist = Math.abs(beatFloat - nearest)
      // Fold distance to 0..0.5 (a half-beat off is the worst case).
      const folded = Math.min(dist, 1 - dist)
      error += folded * folded
    }
    if (error < bestError) {
      bestError = error
      bestPhase = phase
    }
  }

  // Normalize: max possible error = onsets.length * 0.25 (0.5^2).
  const maxError = onsets.length * 0.25
  const score = maxError > 0 ? 1 - bestError / maxError : 0
  return { phase: bestPhase, score }
}

/**
 * Convenience: pick the highest-scoring bpm from a list of hypotheses, but
 * prefer the one whose bpm is closest to a "natural" range when scores are
 * within `tolerance` of each other. This breaks ties toward musical tempi
 * (e.g. 150 over 75 when both score similarly).
 */
export function pickMusicalWinner(
  hypotheses: TempoHypothesis[],
  preferredRange: [number, number] = [100, 180],
  tolerance = 0.02
): TempoHypothesis | null {
  if (hypotheses.length === 0) return null
  const sorted = [...hypotheses].sort((a, b) => b.score - a.score)
  const top = sorted[0]
  const close = sorted.filter((h) => h.score >= top.score - tolerance)
  if (close.length === 1) return top
  // Among close scores, prefer the one in preferredRange; else the middle bpm.
  const inRange = close.filter((h) => h.bpm >= preferredRange[0] && h.bpm <= preferredRange[1])
  if (inRange.length > 0) {
    return inRange.sort((a, b) => b.score - a.score)[0]
  }
  // Else pick the median bpm.
  close.sort((a, b) => a.bpm - b.bpm)
  return close[Math.floor(close.length / 2)]
}
