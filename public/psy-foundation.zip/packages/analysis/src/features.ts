/**
 * Spectral feature extractors.
 *
 * All operate on a magnitude spectrum (output of `spectrum()`). Each returns a
 * single scalar per frame. These are FEATURES, not semantic claims — the
 * inference layer (./inference.ts) decides what they mean musically.
 */

/** Frequency (Hz) of a bin index, given sampleRate and FFT size. */
export function binToFreq(bin: number, sampleRate: number, fftSize: number): number {
  return (bin * sampleRate) / fftSize
}

/** Bin index nearest to a frequency. */
export function freqToBin(freq: number, sampleRate: number, fftSize: number): number {
  return Math.round((freq * fftSize) / sampleRate)
}

/** Spectral centroid (Hz) — the "brightness" of the spectrum. */
export function spectralCentroid(mag: Float32Array, sampleRate: number): number {
  let num = 0
  let den = 0
  const n = mag.length
  for (let i = 0; i < n; i++) {
    const m = mag[i]
    num += i * m
    den += m
  }
  if (den <= 1e-12) return 0
  return (num / den) * (sampleRate / (2 * n))
}

/** Spectral flatness 0..1 — 1 = white noise, 0 = pure tone. */
export function spectralFlatness(mag: Float32Array): number {
  let logSum = 0
  let linSum = 0
  let count = 0
  const n = mag.length
  for (let i = 0; i < n; i++) {
    const m = mag[i]
    if (m > 1e-12) {
      logSum += Math.log(m)
      linSum += m
      count++
    }
  }
  if (count === 0 || linSum <= 1e-12) return 0
  const geoMean = Math.exp(logSum / count)
  const arithMean = linSum / count
  return arithMean > 1e-12 ? Math.min(1, geoMean / arithMean) : 0
}

/** Spectral flux — sum of positive magnitude differences between frames. */
export function spectralFlux(prev: Float32Array, curr: Float32Array): number {
  const n = Math.min(prev.length, curr.length)
  let sum = 0
  for (let i = 0; i < n; i++) {
    const diff = curr[i] - prev[i]
    if (diff > 0) sum += diff * diff
  }
  return sum / n
}

/** RMS energy of a time-domain frame. */
export function rmsEnergy(frame: Float32Array): number {
  let sum = 0
  for (let i = 0; i < frame.length; i++) {
    sum += frame[i] * frame[i]
  }
  return Math.sqrt(sum / frame.length)
}

/** Zero-crossing rate (per sample). Useful for voicing detection. */
export function zeroCrossingRate(frame: Float32Array): number {
  if (frame.length < 2) return 0
  let crossings = 0
  for (let i = 1; i < frame.length; i++) {
    if (frame[i - 1] >= 0 !== frame[i] >= 0) crossings++
  }
  return crossings / (frame.length - 1)
}

/** Sum of magnitudes in a frequency band [loHz, hiHz). */
export function bandEnergy(
  mag: Float32Array,
  sampleRate: number,
  loHz: number,
  hiHz: number
): number {
  const lo = Math.max(0, freqToBin(loHz, sampleRate, mag.length * 2))
  const hi = Math.min(mag.length - 1, freqToBin(hiHz, sampleRate, mag.length * 2))
  let sum = 0
  for (let i = lo; i <= hi; i++) {
    sum += mag[i] ?? 0
  }
  return sum
}

/** Bass activity: energy in 20-120 Hz. */
export function bassActivity(mag: Float32Array, sampleRate: number): number {
  return bandEnergy(mag, sampleRate, 20, 120)
}

/** Low-mid energy: 120-500 Hz. */
export function lowMidEnergy(mag: Float32Array, sampleRate: number): number {
  return bandEnergy(mag, sampleRate, 120, 500)
}

/** High energy: 2000-8000 Hz. */
export function highEnergy(mag: Float32Array, sampleRate: number): number {
  return bandEnergy(mag, sampleRate, 2000, 8000)
}

/** Transient density: count of onset-positive bins (sharp rises). */
export function transientDensity(fluxHistory: number[], threshold: number): number {
  if (fluxHistory.length === 0) return 0
  let count = 0
  for (const f of fluxHistory) {
    if (f > threshold) count++
  }
  return count / fluxHistory.length
}
