/**
 * @psy-foundation/analysis
 *
 * Browser audio analysis toolbox. SIGNAL → FEATURES → MUSICAL INFERENCE.
 *
 * Layers:
 *  - dsp.ts           spectrum(), fft(), hannWindow()
 *  - features.ts      spectral centroid/flatness/flux, RMS, ZCR, band energy
 *  - onset.ts         detectOnsets() — adaptive spectral-flux onset detection
 *  - pitch.ts         detectPitch() (autocorrelation), chroma(), pitch class
 *  - tempo.ts         estimateTempo() — multi-hypothesis, fixes sparse half-time
 *  - inference.ts     role occupancy, energy class, section label, section boundaries
 *  - analyzer.ts      Analyzer — stateful stream wrapper (public API)
 *
 * CRITICAL: never make semantic claims directly from the spectrum. Every claim
 * here is derived from extracted features with explicit reasoning.
 */

export { fft, hannWindow, magnitudeSpectrum, spectrum } from './dsp.ts'
export {
  bassActivity,
  bandEnergy,
  binToFreq,
  freqToBin,
  highEnergy,
  lowMidEnergy,
  rmsEnergy,
  spectralCentroid,
  spectralFlatness,
  spectralFlux,
  transientDensity,
  zeroCrossingRate,
} from './features.ts'
export { detectOnsets } from './onset.ts'
export type { Onset, OnsetDetectorOptions } from './onset.ts'
export { estimateTempo, pickMusicalWinner } from './tempo.ts'
export type { TempoHypothesis, TempoTrackerOptions } from './tempo.ts'
export { chroma, detectPitch, dominantPitchClass, midiToName } from './pitch.ts'
export type { PitchEstimate } from './pitch.ts'
export { detectSectionBoundaries, inferMusical, refineTempoWithContext } from './inference.ts'
export type { EnergyClass, MusicalInference, RoleOccupancy, SectionLabel } from './inference.ts'
export { Analyzer } from './analyzer.ts'
export type { AnalyzerFrame, AnalyzerOptions } from './analyzer.ts'
