/**
 * Musical inference — turns raw features into semantic musical claims.
 *
 * CRITICAL RULE (from the user): do NOT make semantic claims directly from
 * the spectrum. Every claim here must be derived from FEATURES that have been
 * extracted by ./features.ts / ./pitch.ts, with explicit reasoning.
 *
 * Outputs:
 *  - {@link RoleOccupancy}: how much of each role (kick/bass/lead/etc.) is
 *    present in the signal.
 *  - {@link EnergyClass}: discrete energy label.
 *  - {@link SectionLabel}: high-level section guess (intro/drop/breakdown).
 */

import {
  bassActivity,
  highEnergy,
  lowMidEnergy,
  spectralCentroid,
  spectralFlatness,
} from './features.ts'
import type { Onset } from './onset.ts'
import type { TempoHypothesis } from './tempo.ts'

export interface RoleOccupancy {
  /** 0..1 — how present the kick is. */
  kick: number
  /** 0..1 — bass presence. */
  bass: number
  /** 0..1 — lead/melodic presence. */
  lead: number
  /** 0..1 — high-frequency percussion (hats) presence. */
  hats: number
}

export type EnergyClass = 'silent' | 'low' | 'medium' | 'high'

export type SectionLabel = 'intro' | 'build' | 'drop' | 'breakdown' | 'outro'

export interface MusicalInference {
  occupancy: RoleOccupancy
  energy: EnergyClass
  section: SectionLabel
  /** Bass-to-total ratio 0..1. */
  bassRatio: number
  /** Brightness 0..1 (normalized spectral centroid). */
  brightness: number
  /** Noisiness 0..1 (spectral flatness). */
  noisiness: number
}

/**
 * Infer musical roles and energy from a frame's features.
 *
 * @param mag magnitude spectrum of the current frame
 * @param sampleRate signal sample rate
 * @param onsets recent onsets (last ~2 seconds) for transient-based roles
 */
export function inferMusical(
  mag: Float32Array,
  sampleRate: number,
  onsets: Onset[],
  opts?: { centroidRefHz?: number }
): MusicalInference {
  const centroidRefHz = opts?.centroidRefHz ?? 4000

  const bass = bassActivity(mag, sampleRate)
  const lowMid = lowMidEnergy(mag, sampleRate)
  const high = highEnergy(mag, sampleRate)
  const centroid = spectralCentroid(mag, sampleRate)
  const flatness = spectralFlatness(mag)

  const totalEnergy = bass + lowMid + high + 1e-9
  const bassRatio = bass / totalEnergy
  const brightness = Math.min(1, centroid / centroidRefHz)
  const noisiness = flatness

  // Kick presence: bass energy + recent bass-band onsets.
  const recentKickOnsets = onsets.filter((o) => o.strength > 0.5).length
  const kickOnsetRate = Math.min(1, recentKickOnsets / 8) // 8 strong onsets = saturated
  const kick = Math.min(1, (bass / (totalEnergy * 0.5)) * 0.7 + kickOnsetRate * 0.3)

  // Bass presence: low-mid energy relative to total.
  const bassPresence = Math.min(1, lowMid / (totalEnergy * 0.5))

  // Lead presence: mid-to-high centroid + low flatness (tonal, not noise).
  const lead = Math.min(1, brightness * (1 - noisiness) * 1.2)

  // Hats: high energy + high flatness (broadband noise-like).
  const hats = Math.min(1, (high / (totalEnergy * 0.4)) * (0.5 + noisiness * 0.5))

  const occupancy: RoleOccupancy = {
    kick: clamp01(kick),
    bass: clamp01(bassPresence),
    lead: clamp01(lead),
    hats: clamp01(hats),
  }

  const energy = classifyEnergy(totalEnergy)
  const section = classifySection(occupancy, energy, bassRatio)

  return {
    occupancy,
    energy,
    section,
    bassRatio,
    brightness,
    noisiness,
  }
}

function classifyEnergy(total: number): EnergyClass {
  // Empirical thresholds (calibrated against synthetic fixtures).
  if (total < 0.01) return 'silent'
  if (total < 0.5) return 'low'
  if (total < 5) return 'medium'
  return 'high'
}

function classifySection(occ: RoleOccupancy, energy: EnergyClass, bassRatio: number): SectionLabel {
  if (energy === 'silent') return 'breakdown'
  if (energy === 'low' && bassRatio < 0.3) return 'intro'
  if (occ.kick > 0.6 && occ.bass > 0.4 && energy === 'high') return 'drop'
  if (energy === 'medium' && occ.lead > 0.4) return 'build'
  if (energy === 'low') return 'outro'
  return 'build'
}

/**
 * Detect section boundaries from a sequence of inferences.
 * Returns the indices where the section label changes.
 */
export function detectSectionBoundaries(sections: SectionLabel[]): number[] {
  const boundaries: number[] = []
  for (let i = 1; i < sections.length; i++) {
    if (sections[i] !== sections[i - 1]) boundaries.push(i)
  }
  return boundaries
}

/**
 * Refine a tempo hypothesis using musical context. If the winning hypothesis
 * is below the preferred musical range and doubling it would land in range,
 * double it. This is the explicit fix for the M1 sparse-fixture limitation:
 * a sparse kick pattern (beats 1 and 3 only) makes the raw estimator lock to
 * half-time, but musically we know psytrance lives at 130-180 BPM.
 *
 * The refinement is conservative: it only doubles, never halves, and only
 * when the doubled bpm is in or near the preferred range.
 */
export function refineTempoWithContext(
  hypothesis: TempoHypothesis,
  _onsets: Onset[],
  opts?: { preferredRange?: [number, number] }
): TempoHypothesis {
  const preferredRange = opts?.preferredRange ?? [100, 180]
  const lo = preferredRange[0]
  const hi = preferredRange[1]

  // If the hypothesis is below the preferred range and doubling lands in range.
  if (hypothesis.bpm < lo && hypothesis.bpm * 2 >= lo && hypothesis.bpm * 2 <= hi * 1.2) {
    return {
      ...hypothesis,
      bpm: hypothesis.bpm * 2,
      phase: hypothesis.phase / 2,
      // Slight penalty: we're making an assumption, not measuring.
      score: hypothesis.score * 0.92,
    }
  }
  return hypothesis
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v
}
