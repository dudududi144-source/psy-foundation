/**
 * Pitch & chroma detection.
 *
 * Pitch: fundamental frequency estimate via autocorrelation (time-domain).
 * Chroma: 12-bin pitch-class profile from the magnitude spectrum.
 *
 * Both are FEATURES. The inference layer decides musical meaning.
 */

import { binToFreq } from './features.ts'

export interface PitchEstimate {
  /** Frequency in Hz, or null if no clear pitch. */
  freq: number | null
  /** Clarity 0..1 — how peaked the autocorrelation is. */
  clarity: number
  /** MIDI note number (float), or null. */
  midi: number | null
}

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

/** Estimate pitch via autocorrelation. Good for monophonic signals.
 *
 * To avoid subharmonic errors (picking 55 Hz when the true pitch is 440 Hz),
 * we scan from short lags (high freq) to long lags (low freq) and accept the
 * FIRST lag whose correlation exceeds 80% of the global max. This biases
 * toward the shortest period (highest frequency), which is the correct
 * behavior for harmonic signals where the fundamental has the shortest period.
 */
export function detectPitch(
  frame: Float32Array,
  sampleRate: number,
  minHz = 50,
  maxHz = 2000
): PitchEstimate {
  const minLag = Math.floor(sampleRate / maxHz)
  const maxLag = Math.floor(sampleRate / minHz)
  const n = frame.length

  if (n < maxLag + 1) {
    return { freq: null, clarity: 0, midi: null }
  }

  // Normalize the frame to remove DC.
  let mean = 0
  for (let i = 0; i < n; i++) mean += frame[i]
  mean /= n
  const norm = new Float32Array(n)
  for (let i = 0; i < n; i++) norm[i] = frame[i] - mean

  let totalEnergy = 0
  for (let i = 0; i < n; i++) totalEnergy += norm[i] * norm[i]
  if (totalEnergy < 1e-9) return { freq: null, clarity: 0, midi: null }

  // Compute correlation for all lags.
  const corr = new Float32Array(maxLag + 1)
  for (let lag = minLag; lag <= maxLag; lag++) {
    let sum = 0
    for (let i = 0; i < n - lag; i++) {
      sum += norm[i] * norm[i + lag]
    }
    corr[lag] = sum / (n - lag)
  }

  // Find the global max correlation.
  let globalMax = 0
  for (let lag = minLag; lag <= maxLag; lag++) {
    if (corr[lag] > globalMax) globalMax = corr[lag]
  }
  if (globalMax <= 0) return { freq: null, clarity: 0, midi: null }

  // Scan from short lag (high freq) to long lag (low freq). Accept the first
  // lag that is a local maximum AND exceeds 80% of the global max. This
  // biases toward the fundamental (shortest period).
  const threshold = globalMax * 0.8
  let bestLag = 0
  for (let lag = minLag; lag <= maxLag - 1; lag++) {
    if (corr[lag] >= threshold && corr[lag] >= corr[lag - 1] && corr[lag] >= corr[lag + 1]) {
      bestLag = lag
      break
    }
  }

  // Fallback: if no local max above threshold, use the global max.
  if (bestLag === 0) {
    for (let lag = minLag; lag <= maxLag; lag++) {
      if (corr[lag] === globalMax) {
        bestLag = lag
        break
      }
    }
  }

  if (bestLag === 0) return { freq: null, clarity: 0, midi: null }

  const freq = sampleRate / bestLag
  const clarity = Math.min(1, globalMax / (totalEnergy / n))
  const midi = freq > 0 ? 69 + 12 * Math.log2(freq / 440) : null
  return { freq, clarity, midi }
}

/** 12-bin chroma vector from a magnitude spectrum. Sums energy per pitch class. */
export function chroma(mag: Float32Array, sampleRate: number): Float32Array {
  const out = new Float32Array(12)
  const n = mag.length
  const refFreq = 440 // A4
  for (let i = 1; i < n; i++) {
    const freq = binToFreq(i, sampleRate, n * 2)
    if (freq < 55 || freq > 2000) continue // restrict to musical range
    const midi = 69 + 12 * Math.log2(freq / refFreq)
    if (midi < 0 || !Number.isFinite(midi)) continue
    const pc = Math.round(midi) % 12
    out[((pc % 12) + 12) % 12] += mag[i] ?? 0
  }
  // Normalize.
  let max = 0
  for (let i = 0; i < 12; i++) if (out[i] > max) max = out[i]
  if (max > 0) {
    for (let i = 0; i < 12; i++) out[i] = out[i] / max
  }
  return out
}

/** Best-matching pitch class name from a chroma vector. */
export function dominantPitchClass(chromaVec: Float32Array): {
  name: string
  pc: number
  strength: number
} {
  let best = 0
  let bestVal = -1
  for (let i = 0; i < 12; i++) {
    if (chromaVec[i] > bestVal) {
      bestVal = chromaVec[i]
      best = i
    }
  }
  return { name: NOTE_NAMES[best] ?? '?', pc: best, strength: bestVal }
}

/** Convert a MIDI note number to a note name. */
export function midiToName(midi: number): string {
  const pc = ((Math.round(midi) % 12) + 12) % 12
  const octave = Math.floor(Math.round(midi) / 12) - 1
  return `${NOTE_NAMES[pc]}${octave}`
}
