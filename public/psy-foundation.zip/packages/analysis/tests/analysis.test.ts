import { describe, expect, test } from 'bun:test'
import { corpus, getFixture } from '@psy-foundation/fixtures'
import { Analyzer } from '../src/analyzer.ts'
import { fft, hannWindow, spectrum } from '../src/dsp.ts'
import {
  bassActivity,
  highEnergy,
  rmsEnergy,
  spectralFlatness,
  spectralFlux,
  zeroCrossingRate,
} from '../src/features.ts'
import { refineTempoWithContext } from '../src/inference.ts'
import { inferMusical } from '../src/inference.ts'
import { detectOnsets } from '../src/onset.ts'
import { chroma, detectPitch, midiToName } from '../src/pitch.ts'
import { estimateTempo, pickMusicalWinner } from '../src/tempo.ts'

describe('dsp — fft', () => {
  test('fft of a pure tone peaks at the correct bin', () => {
    const n = 1024
    const sampleRate = 44100
    const freq = 440
    const real = new Float32Array(n)
    const imag = new Float32Array(n)
    for (let i = 0; i < n; i++) {
      real[i] = Math.sin((2 * Math.PI * freq * i) / sampleRate)
    }
    hannWindow(real)
    fft(real, imag)
    // Magnitude spectrum (first half only is meaningful for real input).
    let peakBin = 0
    let peakVal = 0
    for (let i = 0; i < n / 2; i++) {
      const m = Math.sqrt(real[i] * real[i] + imag[i] * imag[i])
      if (m > peakVal) {
        peakVal = m
        peakBin = i
      }
    }
    const peakFreq = (peakBin * sampleRate) / n
    expect(peakFreq).toBeGreaterThan(freq - 30)
    expect(peakFreq).toBeLessThan(freq + 30)
  })

  test('fft rejects non-power-of 2', () => {
    const real = new Float32Array(3)
    const imag = new Float32Array(3)
    expect(() => fft(real, imag)).toThrow()
  })

  test('spectrum returns magnitude array of correct length', () => {
    const frame = new Float32Array(256)
    const mag = spectrum(frame)
    expect(mag.length).toBe(256)
  })
})

describe('features', () => {
  test('rmsEnergy of silence is 0', () => {
    expect(rmsEnergy(new Float32Array(1024))).toBe(0)
  })

  test('rmsEnergy of full-scale sine is ~0.707', () => {
    const n = 1024
    const frame = new Float32Array(n)
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 440 * i) / 44100)
    const r = rmsEnergy(frame)
    expect(r).toBeGreaterThan(0.6)
    expect(r).toBeLessThan(0.8)
  })

  test('spectralFlatness of a pure tone is near 0', () => {
    const n = 1024
    const frame = new Float32Array(n)
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 440 * i) / 44100)
    const mag = spectrum(frame)
    expect(spectralFlatness(mag)).toBeLessThan(0.1)
  })

  test('zeroCrossingRate of silence is 0', () => {
    expect(zeroCrossingRate(new Float32Array(1024))).toBe(0)
  })

  test('spectralFlux between identical spectra is 0', () => {
    const mag = spectrum(new Float32Array(1024))
    expect(spectralFlux(mag, mag)).toBe(0)
  })

  test('bandEnergy sums the right bins', () => {
    const n = 1024
    const sampleRate = 44100
    const frame = new Float32Array(n)
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 100 * i) / sampleRate)
    const mag = spectrum(frame)
    const e100 = bassActivity(mag, sampleRate) // 20-120 Hz band includes 100 Hz
    const eHigh = highEnergy(mag, sampleRate) // 2000-8000 Hz band, no energy at 100 Hz
    expect(e100).toBeGreaterThan(eHigh)
  })
})

describe('onset detection', () => {
  test('detects onsets in the perfect-150 fixture', () => {
    const fx = getFixture('perfect-150')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    // 150 BPM over 25.6s = 64 beats. We should find a good fraction of them.
    expect(onsets.length).toBeGreaterThan(40)
    // First onset should be near the first ground-truth beat.
    expect(Math.abs(onsets[0].at - fx.groundTruthBeats[0])).toBeLessThan(0.1)
  })

  test('onset strengths are normalized 0..1', () => {
    const fx = getFixture('perfect-150')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    for (const o of onsets) {
      expect(o.strength).toBeGreaterThanOrEqual(0)
      expect(o.strength).toBeLessThanOrEqual(1)
    }
  })

  test('onsets are monotonically increasing in time', () => {
    const fx = getFixture('perfect-150')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    for (let i = 1; i < onsets.length; i++) {
      expect(onsets[i].at).toBeGreaterThanOrEqual(onsets[i - 1].at)
    }
  })
})

describe('tempo estimation', () => {
  test('estimates 150 BPM from perfect-150 onsets', () => {
    const fx = getFixture('perfect-150')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    const { best } = estimateTempo(onsets)
    expect(best).not.toBeNull()
    expect(best?.bpm).toBeGreaterThan(140)
    expect(best?.bpm).toBeLessThan(160)
  })

  test('THE M1 SPARSE FIX: estimates 150 (not 75) from sparse fixture', () => {
    const fx = getFixture('sparse')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    const { top } = estimateTempo(onsets)
    // Apply refinement to each hypothesis before picking (same as Analyzer does).
    const refined = top.map((h) => refineTempoWithContext(h, onsets))
    const winner = pickMusicalWinner(refined)
    expect(winner).not.toBeNull()
    // This is the explicit fix: sparse should NOT lock to 75.
    expect(winner?.bpm).toBeGreaterThan(130)
    expect(winner?.bpm).toBeLessThan(170)
  })

  test('refineTempoWithContext doubles sub-100 bpm into preferred range', () => {
    const onsets = Array.from({ length: 8 }, (_, i) => ({ at: i * 0.8, strength: 0.9 }))
    const hyp = { bpm: 75, phase: 0, score: 0.9 }
    const refined = refineTempoWithContext(hyp, onsets)
    expect(refined.bpm).toBe(150)
  })

  test('tempo from breakdown fixture recovers to ~140', () => {
    const fx = getFixture('breakdown')
    const onsets = detectOnsets(fx.signal, { sampleRate: fx.sampleRate })
    const { top } = estimateTempo(onsets)
    const winner = pickMusicalWinner(top)
    expect(winner).not.toBeNull()
    expect(winner?.bpm).toBeGreaterThan(125)
    expect(winner?.bpm).toBeLessThan(155)
  })
})

describe('pitch & chroma', () => {
  test('detectPitch finds 440 Hz from a sine', () => {
    const n = 4096
    const sampleRate = 44100
    const frame = new Float32Array(n)
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 440 * i) / sampleRate)
    const p = detectPitch(frame, sampleRate)
    expect(p.freq).not.toBeNull()
    const freq = p.freq as number
    expect(freq).toBeGreaterThan(430)
    expect(freq).toBeLessThan(450)
    expect(p.midi).not.toBeNull()
    const midi = p.midi as number
    expect(Math.round(midi)).toBe(69) // A4
  })

  test('midiToName(69) === "A4"', () => {
    expect(midiToName(69)).toBe('A4')
  })

  test('chroma of a 440 Hz tone peaks at pitch class 9 (A)', () => {
    const n = 8192
    const sampleRate = 44100
    const frame = new Float32Array(n)
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 440 * i) / sampleRate)
    const mag = spectrum(frame)
    const c = chroma(mag, sampleRate)
    let peak = 0
    let peakIdx = 0
    for (let i = 0; i < 12; i++) {
      if (c[i] > peak) {
        peak = c[i]
        peakIdx = i
      }
    }
    expect(peakIdx).toBe(9) // A
  })

  test('detectPitch returns null for silence', () => {
    const p = detectPitch(new Float32Array(4096), 44100)
    expect(p.freq).toBeNull()
    expect(p.clarity).toBe(0)
  })
})

describe('inference', () => {
  test('inferMusical classifies a bass-heavy frame', () => {
    const n = 2048
    const sampleRate = 44100
    const frame = new Float32Array(n)
    // 60 Hz sine (bass territory).
    for (let i = 0; i < n; i++) frame[i] = Math.sin((2 * Math.PI * 60 * i) / sampleRate)
    const mag = spectrum(frame)
    const inf = inferMusical(mag, sampleRate, [])
    expect(inf.bassRatio).toBeGreaterThan(0.3)
    expect(inf.occupancy.bass).toBeGreaterThan(0)
  })

  test('inferMusical classifies silence as silent/breakdown', () => {
    const mag = spectrum(new Float32Array(2048))
    const inf = inferMusical(mag, 44100, [])
    expect(inf.energy).toBe('silent')
  })
})

describe('Analyzer (stream API)', () => {
  test('ingest accumulates frames and history', () => {
    const an = new Analyzer({ sampleRate: 44100, frameSize: 1024, hopSize: 512 })
    const frame = new Float32Array(1024)
    for (let i = 0; i < 1024; i++) frame[i] = Math.sin((2 * Math.PI * 440 * i) / 44100)
    an.ingest(frame)
    an.ingest(frame)
    expect(an.frameCount).toBe(2)
    expect(an.latestFrame).not.toBeNull()
    expect(an.latestPitch).not.toBeNull()
  })

  test('detectOnsetsIn + musicalTempo on perfect-150', () => {
    const fx = getFixture('perfect-150')
    const an = new Analyzer({ sampleRate: fx.sampleRate, frameSize: 1024, hopSize: 512 })
    an.detectOnsetsIn(fx.signal)
    const tempo = an.musicalTempo()
    expect(tempo).not.toBeNull()
    expect(tempo?.bpm).toBeGreaterThan(140)
    expect(tempo?.bpm).toBeLessThan(160)
  })

  test('reset clears history', () => {
    const an = new Analyzer({ sampleRate: 44100 })
    const frame = new Float32Array(1024)
    an.ingest(frame)
    an.reset()
    expect(an.frameCount).toBe(0)
    expect(an.latestFrame).toBeNull()
  })

  test('corpus import works (analysis depends on fixtures)', () => {
    expect(corpus.length).toBe(14)
  })
})
