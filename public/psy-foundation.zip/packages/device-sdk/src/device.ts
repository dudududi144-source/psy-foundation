/**
 * PsyDevice — the contract every PSY device implements.
 *
 * A device is a PLUGIN of the foundation. It receives transport, context, and
 * events from a {@link DeviceHost}, but it MUST be able to produce sound
 * independently (graceful degradation): if the host disappears, the device
 * keeps running on its last-known transport. The Brain is advisory, not
 * required for audio.
 *
 * The SDK intentionally has NO dependency on a specific synth implementation,
 * React, UI, radio, or presets. A device is local, deterministic, independent,
 * musical.
 */

import type { DeviceCapabilities, MusicalContext, MusicalEvent } from '@psy-foundation/protocol'
import type { MusicalTransport } from '@psy-foundation/transport'

export interface PsyDevice {
  /** Stable unique id within the session. */
  id: string
  /** Advertise what this device can do. Called once on registration. */
  capabilities(): DeviceCapabilities
  /** Called whenever the transport snapshot changes (throttled by the host). */
  onTransport(transport: MusicalTransport): void
  /** Called when the musical context (key/scale/energy/style/section) changes. */
  onContext(context: MusicalContext): void
  /** Called for each musical event routed to this device. */
  onEvent(event: MusicalEvent): void
  /** Optional lifecycle hooks. */
  onStart?(): void
  onStop?(): void
  /** Optional: report the device's current output latency in ms (for compensation). */
  reportLatencyMs?(): number
}
