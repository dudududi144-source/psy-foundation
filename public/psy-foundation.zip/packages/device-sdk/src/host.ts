/**
 * DeviceHost — the registry and router for {@link PsyDevice} instances.
 *
 * Responsibilities:
 *  - register/unregister devices;
 *  - push transport snapshots and musical context to every device;
 *  - subscribe to a {@link Channel} and route each {@link MusicalEvent} to
 *    every device's `onEvent`.
 *
 * The host is the ONLY thing a device knows about above it. Devices never
 * import each other. This keeps the device graph acyclic and testable.
 *
 * Transport throttling: transport snapshots can arrive every animation frame
 * (60 Hz). Pushing all of them to every device is wasteful. The host throttles
 * transport delivery to `transportMinIntervalMs` (default ~16ms = 60Hz, but
 * deduplicated by revision so devices only wake on actual changes).
 */

import type {
  Channel,
  DeviceCapabilities,
  MusicalContext,
  MusicalEvent,
} from '@psy-foundation/protocol'
import type { MusicalTransport } from '@psy-foundation/transport'
import type { PsyDevice } from './device.ts'

export interface DeviceHostOptions {
  /** Min ms between transport pushes, even if revision changed. Default 0 (no throttle). */
  transportMinIntervalMs?: number
  /** If true, only push transport when revision changes. Default true. */
  transportDedupByRevision?: boolean
}

export class DeviceHost {
  private readonly devices = new Map<string, PsyDevice>()
  private readonly channel: Channel
  private readonly opts: Required<DeviceHostOptions>
  private channelUnsub: (() => void) | null = null
  private lastTransportRevision: number | null = null
  private lastTransportPushAt = 0

  constructor(channel: Channel, opts: DeviceHostOptions = {}) {
    this.channel = channel
    this.opts = {
      transportMinIntervalMs: opts.transportMinIntervalMs ?? 0,
      transportDedupByRevision: opts.transportDedupByRevision ?? true,
    }
    this.startEventRouting()
  }

  /** Register a device. Calls onStart if present. Idempotent by id. */
  register(device: PsyDevice): void {
    if (this.devices.has(device.id)) {
      throw new Error(`Device already registered: ${device.id}`)
    }
    this.devices.set(device.id, device)
    device.onStart?.()
  }

  /** Unregister a device. Calls onStop if present. */
  unregister(id: string): void {
    const device = this.devices.get(id)
    if (!device) return
    device.onStop?.()
    this.devices.delete(id)
  }

  /** List registered devices with their capabilities. */
  list(): Array<{ id: string; capabilities: DeviceCapabilities }> {
    return Array.from(this.devices.values()).map((d) => ({
      id: d.id,
      capabilities: d.capabilities(),
    }))
  }

  /** Find devices that can fill a given role. */
  findByRole(role: string): PsyDevice[] {
    return Array.from(this.devices.values()).filter((d) => d.capabilities().roles.includes(role))
  }

  /** Push a transport snapshot to every device (subject to throttling). */
  pushTransport(transport: MusicalTransport, nowMs: number): void {
    if (this.opts.transportDedupByRevision) {
      if (this.lastTransportRevision === transport.revision) return
      this.lastTransportRevision = transport.revision
    }
    if (this.opts.transportMinIntervalMs > 0) {
      if (nowMs - this.lastTransportPushAt < this.opts.transportMinIntervalMs) return
      this.lastTransportPushAt = nowMs
    }
    for (const device of this.devices.values()) {
      device.onTransport(transport)
    }
  }

  /** Push a musical context to every device. */
  pushContext(context: MusicalContext): void {
    for (const device of this.devices.values()) {
      device.onContext(context)
    }
  }

  /** Publish an event over the channel (it will be routed back to devices). */
  publish(event: MusicalEvent): void {
    this.channel.publish(event)
  }

  /** Tear down: unregister all devices and stop routing. */
  dispose(): void {
    for (const device of Array.from(this.devices.values())) {
      device.onStop?.()
    }
    this.devices.clear()
    this.channelUnsub?.()
    this.channelUnsub = null
  }

  get deviceCount(): number {
    return this.devices.size
  }

  private startEventRouting(): void {
    this.channelUnsub = this.channel.subscribe((event: MusicalEvent) => {
      for (const device of this.devices.values()) {
        device.onEvent(event)
      }
    })
  }
}
