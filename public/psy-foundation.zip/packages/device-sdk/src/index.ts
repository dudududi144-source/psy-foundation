/**
 * @psy-foundation/device-sdk
 *
 * PSY device SDK. A device is a plugin of the foundation: it receives
 * transport / context / events from a DeviceHost, but can sound independently.
 */

export type { PsyDevice } from './device.ts'
export { DeviceHost } from './host.ts'
export type { DeviceHostOptions } from './host.ts'
export { ReferenceDevice } from './reference.ts'
export type { ReferenceDeviceOptions } from './reference.ts'
