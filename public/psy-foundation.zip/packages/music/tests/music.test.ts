import { describe, expect, test } from 'bun:test'
import {
  backbeat,
  chordNotes,
  chordPcs,
  chordTension,
  combine,
  degreeToMidi,
  density,
  drivingHats,
  fourOnFloor,
  fragment,
  generateBassPattern,
  generateMotif,
  getChordType,
  getScale,
  humanize,
  invert,
  invertRhythm,
  isInScale,
  listChordTypes,
  listScales,
  nameToPc,
  nearestDegree,
  offbeatHats,
  pcToName,
  psyKick,
  retrograde,
  sampleTension,
  scalePcs,
  stableDegrees,
  swing,
  tensionToDensity,
  tensionToOctave,
  transpose,
  vary,
  voiceChord,
} from '../src/index.ts'

describe('scales', () => {
  test('phrygian-dominant is available (extracted from psy)', () => {
    const s = getScale('phrygian-dominant')
    expect(s).not.toBeNull()
    expect(s.intervals).toEqual([0, 1, 4, 5, 7, 8, 10])
  })

  test('alias lookup works (spanish-gypsy = phrygian-dominant)', () => {
    expect(getScale('spanish-gypsy')).toEqual(getScale('phrygian-dominant'))
  })

  test('listScales returns at least 15 scales', () => {
    expect(listScales().length).toBeGreaterThanOrEqual(15)
  })

  test('scalePcs computes pitch classes', () => {
    const s = getScale('major') as never
    expect(scalePcs(0, s)).toEqual([0, 2, 4, 5, 7, 9, 11]) // C major
    expect(scalePcs(9, s)).toEqual([9, 11, 1, 2, 4, 6, 8]) // A major
  })

  test('degreeToMidi wraps octaves', () => {
    const s = getScale('major') as never
    expect(degreeToMidi(0, s, 0)).toBe(60) // C4
    expect(degreeToMidi(0, s, 7)).toBe(72) // C5 (one octave up)
    expect(degreeToMidi(0, s, -7)).toBe(48) // C3
  })

  test('isInScale checks membership', () => {
    const s = getScale('major') as never
    expect(isInScale(0, s, 60)).toBe(true) // C in C major
    expect(isInScale(0, s, 61)).toBe(false) // C# not in C major
  })

  test('nearestDegree finds closest scale tone', () => {
    const s = getScale('major') as never
    expect(nearestDegree(0, s, 60)).toBe(0) // C → degree 0
    expect(nearestDegree(0, s, 62)).toBe(1) // D → degree 1
  })

  test('stableDegrees returns root and fifth', () => {
    const s = getScale('major') as never
    const stable = stableDegrees(s)
    expect(stable).toContain(0)
    expect(stable.length).toBeGreaterThanOrEqual(2)
  })

  test('pcToName / nameToPc round-trip', () => {
    for (let pc = 0; pc < 12; pc++) {
      expect(nameToPc(pcToName(pc))).toBe(pc)
    }
  })
})

describe('chords', () => {
  test('major triad intervals', () => {
    expect((getChordType('major') as { intervals: number[] }).intervals).toEqual([0, 4, 7])
  })

  test('dom7 alias "7"', () => {
    expect(getChordType('7')).toEqual(getChordType('dom7'))
  })

  test('chordNotes builds MIDI notes', () => {
    const c = getChordType('major') as never
    expect(chordNotes(0, c)).toEqual([60, 64, 67]) // C major: C4 E4 G4
  })

  test('chordPcs returns pitch classes', () => {
    const c = getChordType('min7') as never
    expect(chordPcs(0, c)).toEqual([0, 3, 7, 10])
  })

  test('chordTension: major triad is low, dim7 is high', () => {
    const major = getChordType('major') as never
    const dim7 = getChordType('dim7') as never
    expect(chordTension(major)).toBeLessThan(chordTension(dim7))
  })

  test('voiceChord with no previous returns default voicing', () => {
    const c = getChordType('major') as never
    const v = voiceChord(0, c, null)
    expect(v).toEqual([60, 64, 67])
  })

  test('voiceChord with previous moves voices smoothly', () => {
    const cMaj = getChordType('major') as never
    const dMin = getChordType('minor') as never
    const v1 = voiceChord(0, cMaj, null) // [60, 64, 67]
    const v2 = voiceChord(2, dMin, v1) // D minor from C major
    // Should be close to the previous voicing (no jumps > a tritone).
    for (let i = 0; i < v2.length; i++) {
      expect(Math.abs(v2[i] - v1[i])).toBeLessThan(7)
    }
  })

  test('listChordTypes returns at least 15 types', () => {
    expect(listChordTypes().length).toBeGreaterThanOrEqual(15)
  })
})

describe('motif', () => {
  test('generateMotif produces notes in the scale', () => {
    const s = getScale('phrygian-dominant') as never
    const notes = generateMotif(0, s, { seed: 42, steps: 32 })
    expect(notes.length).toBeGreaterThan(0)
    for (const n of notes) {
      expect(isInScale(0, s, n.midi)).toBe(true)
    }
  })

  test('motif is deterministic given the same seed', () => {
    const s = getScale('phrygian-dominant') as never
    const a = generateMotif(0, s, { seed: 7 })
    const b = generateMotif(0, s, { seed: 7 })
    expect(a).toEqual(b)
  })

  test('different seeds → different motifs', () => {
    const s = getScale('phrygian-dominant') as never
    const a = generateMotif(0, s, { seed: 1 })
    const b = generateMotif(0, s, { seed: 2 })
    expect(a).not.toEqual(b)
  })

  test('motif ends on the root (resolution)', () => {
    const s = getScale('major') as never
    const notes = generateMotif(0, s, { seed: 3, steps: 32 })
    const last = notes[notes.length - 1]
    expect(last).toBeDefined()
    // Last note should be a root (C in C major = midi 60 or 48 or 72).
    expect(last.midi % 12).toBe(0)
  })

  test('transpose shifts all notes by scale degrees', () => {
    const s = getScale('major') as never
    const original = generateMotif(0, s, { seed: 5 })
    const transposed = transpose(original, 0, s, 1) // up one degree
    expect(transposed.length).toBe(original.length)
    // At least some notes should differ.
    const diff = original.some((n, i) => n.midi !== transposed[i].midi)
    expect(diff).toBe(true)
  })

  test('invert mirrors around the first note', () => {
    const s = getScale('major') as never
    const original = generateMotif(0, s, { seed: 5 })
    const inverted = invert(original, 0, s)
    expect(inverted.length).toBe(original.length)
    // First note should be unchanged (it's the mirror axis).
    expect(inverted[0].midi).toBe(original[0].midi)
  })

  test('fragment keeps only the first N notes', () => {
    const s = getScale('major') as never
    const original = generateMotif(0, s, { seed: 5 })
    const frag = fragment(original, 2)
    expect(frag.length).toBe(2)
  })

  test('retrograde reverses note order', () => {
    const s = getScale('major') as never
    const original = generateMotif(0, s, { seed: 5 })
    const retro = retrograde(original)
    expect(retro.length).toBe(original.length)
    expect(retro[0].midi).toBe(original[original.length - 1].midi)
  })

  test('vary with "none" returns a copy', () => {
    const s = getScale('major') as never
    const original = generateMotif(0, s, { seed: 5 })
    const copy = vary(original, 0, s, 'none')
    expect(copy).toEqual(original)
    // Ensure it's a copy, not the same reference.
    expect(copy).not.toBe(original)
  })
})

describe('bass', () => {
  test('kb3 pattern has 5 notes (kick + 4 bass)', () => {
    const s = getScale('phrygian-dominant') as never
    const notes = generateBassPattern(0, s, { style: 'kb3', seed: 1 })
    expect(notes.length).toBeGreaterThanOrEqual(5)
  })

  test('four-on-floor has 4 bass notes on beats', () => {
    const s = getScale('major') as never
    const notes = generateBassPattern(0, s, { style: 'four-on-floor' })
    expect(notes.length).toBe(4)
    expect(notes.map((n) => n.step)).toEqual([0, 4, 8, 12])
  })

  test('bass is deterministic given seed', () => {
    const s = getScale('major') as never
    const a = generateBassPattern(0, s, { seed: 7 })
    const b = generateBassPattern(0, s, { seed: 7 })
    expect(a).toEqual(b)
  })

  test('sampleTension: build goes 0→1', () => {
    expect(sampleTension('build', 0)).toBeCloseTo(0, 5)
    expect(sampleTension('build', 1)).toBeCloseTo(1, 5)
    expect(sampleTension('build', 0.5)).toBeCloseTo(0.5, 5)
  })

  test('sampleTension: peak rises then falls', () => {
    expect(sampleTension('peak', 0.5)).toBeCloseTo(1, 5)
    expect(sampleTension('peak', 0)).toBeCloseTo(0, 5)
    expect(sampleTension('peak', 1)).toBeCloseTo(0, 5)
  })

  test('tensionToDensity is monotonic', () => {
    expect(tensionToDensity(0)).toBeLessThanOrEqual(tensionToDensity(1))
  })

  test('tensionToOctave raises at high tension', () => {
    expect(tensionToOctave(0.9, 3)).toBe(4)
    expect(tensionToOctave(0.3, 3)).toBe(3)
  })
})

describe('rhythm', () => {
  test('fourOnFloor hits on 0,4,8,12', () => {
    const r = fourOnFloor()
    expect(r.hits.filter(Boolean).length).toBe(4)
    expect(r.hits[0]).toBe(true)
    expect(r.hits[4]).toBe(true)
    expect(r.hits[1]).toBe(false)
  })

  test('offbeatHats hits on 2,6,10,14', () => {
    const r = offbeatHats()
    expect(r.hits[2]).toBe(true)
    expect(r.hits[6]).toBe(true)
    expect(r.hits[0]).toBe(false)
  })

  test('psyKick has a single hit at step 0', () => {
    const r = psyKick()
    expect(r.hits.filter(Boolean).length).toBe(1)
    expect(r.hits[0]).toBe(true)
  })

  test('drivingHats hits every step with accents', () => {
    const r = drivingHats()
    expect(r.hits.every(Boolean)).toBe(true)
    expect(r.velocities?.[0]).toBeGreaterThan(r.velocities?.[1])
  })

  test('swing delays odd steps', () => {
    const r = swing(fourOnFloor(), 0.25)
    expect(r.micros?.[1]).toBe(0.25)
    expect(r.micros?.[0]).toBe(0)
  })

  test('humanize is deterministic given seed', () => {
    const a = humanize(fourOnFloor(), 0.02, 42)
    const b = humanize(fourOnFloor(), 0.02, 42)
    expect(a.micros).toEqual(b.micros)
  })

  test('combine ORs hits', () => {
    const a = fourOnFloor() // 0,4,8,12
    const b = offbeatHats() // 2,6,10,14
    const c = combine(a, b)
    expect(c.hits.filter(Boolean).length).toBe(8)
  })

  test('invertRhythm flips hits/rests', () => {
    const r = fourOnFloor()
    const inv = invertRhythm(r)
    expect(inv.hits[0]).toBe(false)
    expect(inv.hits[1]).toBe(true)
  })

  test('density reports hit fraction', () => {
    expect(density(fourOnFloor())).toBeCloseTo(0.25, 5) // 4/16
    expect(density(drivingHats())).toBeCloseTo(1, 5) // 16/16
  })

  test('backbeat hits on beats 2 and 4', () => {
    const r = backbeat()
    expect(r.hits[4]).toBe(true)
    expect(r.hits[12]).toBe(true)
  })
})
