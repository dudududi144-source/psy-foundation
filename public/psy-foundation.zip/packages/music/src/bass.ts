/**
 * Bass grammar & rhythm patterns.
 *
 * Extracted from psy's K-B-B-B bass pattern (kick on 1, bass on 1.5, 2.5, 3.5)
 * and generalized. Also provides tension curve helpers for arranging energy
 * across a section.
 */

import { Rng } from './rng.ts'
import type { Scale } from './scales.ts'
import { degreeToMidi } from './scales.ts'

export interface BassNote {
  /** Step index in the bar (0..15 for 16-step). */
  step: number
  midi: number
  velocity: number
  durationSteps: number
}

export interface BassPatternOptions {
  /** Pattern style. 'kb3' = kick on 1 + bass on 1.5, 2.5, 3.5 (psy default). */
  style?: 'kb3' | 'four-on-floor' | 'offbeat' | 'syncopated'
  /** Root degree for bass notes (default 0 = root). */
  rootDegree?: number
  /** Probability of a passing tone (default 0.2). */
  passingProb?: number
  /** Octave for bass (default 2). */
  octave?: number
  /** Seed for deterministic passing tones. */
  seed?: number
}

const DEFAULTS: Required<BassPatternOptions> = {
  style: 'kb3',
  rootDegree: 0,
  passingProb: 0.2,
  octave: 2,
  seed: 1,
}

/**
 * Generate a bass pattern for one bar (16 steps).
 * The pattern is a function of (rootPc, scale, style, seed) — deterministic.
 */
export function generateBassPattern(
  rootPc: number,
  scale: Scale,
  opts: BassPatternOptions = {}
): BassNote[] {
  const o = { ...DEFAULTS, ...opts }
  const rng = new Rng(o.seed)
  const notes: BassNote[] = []

  const rootMidi = degreeToMidi(rootPc, scale, o.rootDegree, o.octave)
  const fifthMidi = degreeToMidi(rootPc, scale, o.rootDegree + 4, o.octave)
  const octaveMidi = degreeToMidi(rootPc, scale, o.rootDegree + 7, o.octave)

  switch (o.style) {
    case 'kb3': {
      // Kick on step 0 (we still emit a bass note there too, low velocity).
      notes.push({ step: 0, midi: rootMidi, velocity: 0.9, durationSteps: 1 })
      // Bass on 1.5, 2.5, 3.5 = steps 2, 6, 10 (8th-note offbeats after each beat).
      for (const step of [2, 6, 10, 14]) {
        const usePassing = rng.next() < o.passingProb
        const midi = usePassing ? fifthMidi : rootMidi
        notes.push({
          step,
          midi,
          velocity: 0.7,
          durationSteps: 1,
        })
      }
      // Octave jump on the last offbeat for drive.
      if (rng.next() < 0.5) {
        notes.push({ step: 14, midi: octaveMidi, velocity: 0.8, durationSteps: 1 })
      }
      break
    }
    case 'four-on-floor': {
      // Bass on every beat (steps 0, 4, 8, 12).
      for (const step of [0, 4, 8, 12]) {
        notes.push({ step, midi: rootMidi, velocity: 0.8, durationSteps: 2 })
      }
      break
    }
    case 'offbeat': {
      // Bass on every offbeat (steps 2, 6, 10, 14) — classic house/psy.
      for (const step of [2, 6, 10, 14]) {
        notes.push({ step, midi: rootMidi, velocity: 0.75, durationSteps: 2 })
      }
      break
    }
    case 'syncopated': {
      // Syncopated: steps 0, 3, 6, 10, 14.
      for (const step of [0, 3, 6, 10, 14]) {
        const usePassing = rng.next() < o.passingProb
        const midi = usePassing ? fifthMidi : rootMidi
        notes.push({ step, midi, velocity: 0.7, durationSteps: 1 })
      }
      break
    }
  }

  return notes
}

// ── Tension curves ──

export type TensionCurve = 'flat' | 'build' | 'release' | 'peak' | 'valley'

/**
 * Sample a tension curve at position t (0..1) → tension 0..1.
 * Used by arrangers to shape energy across a section.
 */
export function sampleTension(curve: TensionCurve, t: number): number {
  const x = Math.max(0, Math.min(1, t))
  switch (curve) {
    case 'flat':
      return 0.5
    case 'build':
      return x // 0 → 1
    case 'release':
      return 1 - x // 1 → 0
    case 'peak':
      // Rises to 0.5, falls after.
      return x < 0.5 ? x * 2 : (1 - x) * 2
    case 'valley':
      // Falls to 0.5, rises after.
      return x < 0.5 ? 1 - x * 2 : (x - 0.5) * 2
  }
}

/**
 * Map a tension value (0..1) to a density multiplier (0..1).
 * Low tension → sparse; high tension → dense.
 */
export function tensionToDensity(tension: number): number {
  return Math.max(0.1, Math.min(1, tension))
}

/**
 * Map tension to an octave offset.
 * Low tension → low octave; high tension → +1 octave.
 */
export function tensionToOctave(tension: number, base = 3): number {
  return tension > 0.7 ? base + 1 : base
}
