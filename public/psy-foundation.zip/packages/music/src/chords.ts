/**
 * Chords & harmony.
 *
 * Chord types (triads, sevenths, extensions) as interval stacks. Voicing and
 * voice-leading helpers for arranging notes across octaves with smooth motion.
 */

export interface ChordType {
  name: string
  /** Intervals from the root, in semitones. */
  intervals: number[]
  aliases?: string[]
}

const CHORD_TYPES: ChordType[] = [
  // Triads
  { name: 'major', intervals: [0, 4, 7], aliases: ['M', 'maj'] },
  { name: 'minor', intervals: [0, 3, 7], aliases: ['m', 'min'] },
  { name: 'diminished', intervals: [0, 3, 6], aliases: ['dim', 'o'] },
  { name: 'augmented', intervals: [0, 4, 8], aliases: ['aug', '+'] },
  { name: 'sus2', intervals: [0, 2, 7] },
  { name: 'sus4', intervals: [0, 5, 7] },

  // Sevenths
  { name: 'maj7', intervals: [0, 4, 7, 11], aliases: ['M7', 'Δ'] },
  { name: 'min7', intervals: [0, 3, 7, 10], aliases: ['m7', '-7'] },
  { name: 'dom7', intervals: [0, 4, 7, 10], aliases: ['7'] },
  { name: 'min7b5', intervals: [0, 3, 6, 10], aliases: ['half-dim', 'ø'] },
  { name: 'dim7', intervals: [0, 3, 6, 9], aliases: ['o7'] },
  { name: 'min-maj7', intervals: [0, 3, 7, 11], aliases: ['mMaj7'] },

  // Sixth
  { name: 'maj6', intervals: [0, 4, 7, 9], aliases: ['6'] },
  { name: 'min6', intervals: [0, 3, 7, 9], aliases: ['m6'] },

  // Extensions (psytrance uses these for tension)
  { name: 'min9', intervals: [0, 3, 7, 10, 14], aliases: ['m9'] },
  { name: 'maj9', intervals: [0, 4, 7, 11, 14], aliases: ['M9'] },
  { name: 'dom9', intervals: [0, 4, 7, 10, 14], aliases: ['9'] },
  { name: 'min11', intervals: [0, 3, 7, 10, 14, 17], aliases: ['m11'] },
]

const CHORD_MAP: Map<string, ChordType> = (() => {
  const m = new Map<string, ChordType>()
  for (const c of CHORD_TYPES) {
    m.set(c.name, c)
    for (const alias of c.aliases ?? []) m.set(alias, c)
  }
  return m
})()

/** Look up a chord type by name or alias. */
export function getChordType(name: string): ChordType | null {
  const key = name.toLowerCase()
  return CHORD_MAP.get(key) ?? null
}

/** List all chord type names. */
export function listChordTypes(): string[] {
  return CHORD_TYPES.map((c) => c.name)
}

/** Build a chord's MIDI notes from a root pitch class + chord type + octave. */
export function chordNotes(rootPc: number, type: ChordType, octave = 4): number[] {
  // Root at C4=60 + rootPc.
  return type.intervals.map((iv) => 60 + rootPc + iv + (octave - 4) * 12)
}

/** Pitch classes of a chord. */
export function chordPcs(rootPc: number, type: ChordType): number[] {
  return type.intervals.map((iv) => (((rootPc + iv) % 12) + 12) % 12)
}

/**
 * Voice a chord with smooth voice leading from a previous voicing.
 * Greedy nearest-note assignment. Deterministic.
 */
export function voiceChord(
  currentRootPc: number,
  currentType: ChordType,
  previousVoicing: number[] | null,
  octave = 4
): number[] {
  const target = chordNotes(currentRootPc, currentType, octave)
  if (!previousVoicing || previousVoicing.length === 0) {
    // Default voicing: root in the bass, others above.
    return [...target]
  }

  // For each target chord tone, pick the octave-invariant nearest to a previous voice.
  const voiced: number[] = []
  for (const tone of target) {
    let best = tone
    let bestDist = Number.POSITIVE_INFINITY
    for (const prev of previousVoicing) {
      // Distance in pitch-class space, then choose the octave closest to prev.
      const pcDiff = (((tone - prev) % 12) + 12) % 12
      const upDist = pcDiff
      const downDist = pcDiff - 12
      const candidateUp = prev + upDist
      const candidateDown = prev + downDist
      if (Math.abs(candidateUp - prev) < bestDist) {
        bestDist = Math.abs(candidateUp - prev)
        best = candidateUp
      }
      if (Math.abs(candidateDown - prev) < bestDist) {
        bestDist = Math.abs(candidateDown - prev)
        best = candidateDown
      }
    }
    voiced.push(best)
  }
  return voiced.sort((a, b) => a - b)
}

/**
 * Harmonic tension score 0..1 for a chord (rough heuristic).
 * Diminished/augmented/dominant = high tension; major triad = low.
 */
export function chordTension(type: ChordType): number {
  const pcs = chordPcs(0, type)
  const has = (pc: number) => pcs.includes(((pc % 12) + 12) % 12)
  let tension = 0
  // Tritone (6 semitones from root or third) raises tension.
  if (has(6) || has(10)) tension += 0.3
  // Minor third lowers tension slightly.
  if (has(3) && !has(4)) tension += 0.1
  // Major seventh = smooth tension.
  if (has(11)) tension += 0.15
  // Extensions add complexity.
  if (type.intervals.length > 4) tension += 0.15
  return Math.min(1, tension)
}
