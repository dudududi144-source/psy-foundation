/**
 * Scales & modes.
 *
 * A scale is defined by its interval pattern (semitones from the root). This
 * module ships the scales used across the PSY family, extracted from the audit:
 *  - psy's 6 psytrance scales (Phrygian Dominant, harmonic minor, etc.)
 *  - common western scales (major, minor, pentatonic, blues)
 *
 * All operations are pure functions of (rootPc, scale). No state, no randomness.
 */

/** A scale definition: name + interval pattern (semitones from root, ascending). */
export interface Scale {
  name: string
  /** Intervals in semitones from the root. Always starts with 0. */
  intervals: number[]
  /** Aliases / common alternate names. */
  aliases?: string[]
}

const SCALES: Scale[] = [
  // Western diatonic
  { name: 'major', intervals: [0, 2, 4, 5, 7, 9, 11], aliases: ['ionian'] },
  { name: 'minor', intervals: [0, 2, 3, 5, 7, 8, 10], aliases: ['aeolian', 'natural-minor'] },
  { name: 'harmonic-minor', intervals: [0, 2, 3, 5, 7, 8, 11] },
  { name: 'melodic-minor', intervals: [0, 2, 3, 5, 7, 9, 11] },

  // Modes
  { name: 'dorian', intervals: [0, 2, 3, 5, 7, 9, 10] },
  { name: 'phrygian', intervals: [0, 1, 3, 5, 7, 8, 10] },
  { name: 'lydian', intervals: [0, 2, 4, 6, 7, 9, 11] },
  { name: 'mixolydian', intervals: [0, 2, 4, 5, 7, 9, 10] },
  { name: 'locrian', intervals: [0, 1, 3, 5, 6, 8, 10] },

  // Psytrance family (from psy audit — these are the genre-defining scales)
  {
    name: 'phrygian-dominant',
    intervals: [0, 1, 4, 5, 7, 8, 10],
    aliases: ['spanish-gypsy', 'phrygian-major'],
  },
  {
    name: 'double-harmonic',
    intervals: [0, 1, 4, 5, 7, 8, 11],
    aliases: ['byzantine', 'hungarian-minor'],
  },
  { name: 'hungarian-major', intervals: [0, 3, 4, 6, 7, 9, 10] },
  { name: 'neapolitan-minor', intervals: [0, 1, 3, 5, 7, 8, 11] },

  // Pentatonic & blues
  { name: 'major-pentatonic', intervals: [0, 2, 4, 7, 9] },
  { name: 'minor-pentatonic', intervals: [0, 3, 5, 7, 10] },
  { name: 'blues', intervals: [0, 3, 5, 6, 7, 10] },

  // Whole-tone & diminished (for tension)
  { name: 'whole-tone', intervals: [0, 2, 4, 6, 8, 10] },
  { name: 'diminished', intervals: [0, 2, 3, 5, 6, 8, 9, 11], aliases: ['octatonic'] },
]

const SCALE_MAP: Map<string, Scale> = (() => {
  const m = new Map<string, Scale>()
  for (const s of SCALES) {
    m.set(s.name, s)
    for (const alias of s.aliases ?? []) m.set(alias, s)
  }
  return m
})()

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

/** Look up a scale by name or alias. Returns null if not found. */
export function getScale(name: string): Scale | null {
  const key = name.toLowerCase().replace(/\s+/g, '-')
  return SCALE_MAP.get(key) ?? null
}

/** List all available scale names. */
export function listScales(): string[] {
  return SCALES.map((s) => s.name)
}

/** Convert a pitch class (0-11) to a note name. */
export function pcToName(pc: number): string {
  return NOTE_NAMES[((pc % 12) + 12) % 12] ?? '?'
}

/** Convert a note name to a pitch class (0-11). Returns -1 if invalid. */
export function nameToPc(name: string): number {
  const n = name.trim()
  const idx = NOTE_NAMES.indexOf(n)
  return idx
}

/**
 * Get the pitch classes of a scale rooted at `rootPc`.
 * Returns an array of 0-11 values, length = scale.intervals.length.
 */
export function scalePcs(rootPc: number, scale: Scale): number[] {
  return scale.intervals.map((iv) => (((rootPc + iv) % 12) + 12) % 12)
}

/**
 * Get the MIDI notes of a scale across a range of octaves.
 * @param rootPc pitch class of the root (0-11)
 * @param scale the scale
 * @param fromMidi lowest MIDI note (inclusive)
 * @param toMidi highest MIDI note (exclusive)
 */
export function scaleNotes(
  rootPc: number,
  scale: Scale,
  fromMidi: number,
  toMidi: number
): number[] {
  const pcs = new Set(scalePcs(rootPc, scale))
  const notes: number[] = []
  for (let m = fromMidi; m < toMidi; m++) {
    if (pcs.has(((m % 12) + 12) % 12)) notes.push(m)
  }
  return notes
}

/** Degree index → pitch class. Degree can exceed scale length (wraps to next octave). */
export function degreeToPc(rootPc: number, scale: Scale, degree: number): number {
  const len = scale.intervals.length
  const octave = Math.floor(degree / len)
  const idx = ((degree % len) + len) % len
  const base = scale.intervals[idx] ?? 0
  return (((rootPc + base + octave * 12) % 12) + 12) % 12
}

/** Degree index → MIDI note. */
export function degreeToMidi(rootPc: number, scale: Scale, degree: number, octave = 4): number {
  const len = scale.intervals.length
  const octaveOffset = Math.floor(degree / len)
  const idx = ((degree % len) + len) % len
  const base = scale.intervals[idx] ?? 0
  // MIDI: C4 = 60. Root pc at octave 4 = 60 + rootPc.
  return 60 + rootPc + base + (octave - 4) * 12 + octaveOffset * 12
}

/** Check if a MIDI note belongs to the scale. */
export function isInScale(rootPc: number, scale: Scale, midi: number): boolean {
  const pc = ((midi % 12) + 12) % 12
  return scalePcs(rootPc, scale).includes(pc)
}

/** Find the nearest scale degree to a MIDI note. */
export function nearestDegree(rootPc: number, scale: Scale, midi: number): number {
  // Brute-force search over a range of degrees.
  let bestDeg = 0
  let bestDist = Number.POSITIVE_INFINITY
  for (let d = -7; d <= 21; d++) {
    const noteMidi = degreeToMidi(rootPc, scale, d)
    const dist = Math.abs(noteMidi - midi)
    if (dist < bestDist) {
      bestDist = dist
      bestDeg = d
    }
  }
  return bestDeg
}

/** The stable tones of a scale (root and fifth, used for motif resolution). */
export function stableDegrees(scale: Scale): number[] {
  // Degree 0 = root, degree 4 (if 7-note scale) or middle = fifth.
  if (scale.intervals.length >= 5) {
    return [0, Math.floor(scale.intervals.length / 2)]
  }
  return [0]
}
