/**
 * Rhythm grammar & groove.
 *
 * Rhythm patterns as boolean/probability grids, plus groove (micro-timing)
 * and accent patterns. These feed the scheduler (M2) as PatternStep data.
 */

export interface RhythmPattern {
  /** 16-step grid: true = hit, false = rest. */
  hits: boolean[]
  /** Per-step velocity 0..1 (defaults to 1 for hits). */
  velocities?: number[]
  /** Per-step probability 0..1 (defaults to 1). */
  probabilities?: number[]
  /** Per-step micro-timing offset in beats (-0.5..0.5). */
  micros?: number[]
}

const DEFAULT_STEPS = 16

/** Build a rhythm from a hit pattern + optional accents. */
export function rhythm(
  hits: boolean[],
  opts: { velocities?: number[]; probabilities?: number[]; micros?: number[] } = {}
): RhythmPattern {
  return {
    hits,
    velocities: opts.velocities,
    probabilities: opts.probabilities,
    micros: opts.micros,
  }
}

/** Four-on-the-floor: hits on 0, 4, 8, 12. */
export function fourOnFloor(steps = DEFAULT_STEPS): RhythmPattern {
  const hits = Array.from({ length: steps }, () => false)
  for (let i = 0; i < steps; i += 4) hits[i] = true
  return rhythm(hits)
}

/** Offbeat hats: hits on 2, 6, 10, 14. */
export function offbeatHats(steps = DEFAULT_STEPS): RhythmPattern {
  const hits = Array.from({ length: steps }, () => false)
  for (let i = 2; i < steps; i += 4) hits[i] = true
  return rhythm(hits)
}

/** Psytrance kick: hit on 0 of every bar (single hit at step 0). */
export function psyKick(): RhythmPattern {
  const hits = Array.from({ length: DEFAULT_STEPS }, () => false)
  hits[0] = true
  return rhythm(hits, { velocities: [1] })
}

/** Syncopated snare/clap on beats 2 and 4 (steps 4 and 12). */
export function backbeat(steps = DEFAULT_STEPS): RhythmPattern {
  const hits = Array.from({ length: steps }, () => false)
  if (steps >= 5) hits[4] = true
  if (steps >= 13) hits[12] = true
  return rhythm(hits, { velocities: [0.9, 0.9] })
}

/** A driving 16th-note hat pattern with accents on the downbeats. */
export function drivingHats(steps = DEFAULT_STEPS): RhythmPattern {
  const hits = Array.from({ length: steps }, () => true)
  const velocities = hits.map((_, i) => (i % 4 === 0 ? 0.9 : 0.5))
  return rhythm(hits, { velocities })
}

/** Apply a swing feel: delay odd 8th notes by `amount` beats (0..0.5). */
export function swing(pattern: RhythmPattern, amount: number): RhythmPattern {
  const micros = Array.from({ length: pattern.hits.length }, (_, i) => {
    if (i % 2 === 1) return amount
    return 0
  })
  return { ...pattern, micros }
}

/** Apply a humanize: random micro-timing offsets, deterministic given seed. */
export function humanize(pattern: RhythmPattern, amountSec: number, seed: number): RhythmPattern {
  let s = seed >>> 0
  const rng = () => {
    s = (s + 0x6d2b79f5) >>> 0
    let t = s
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
  const micros = pattern.hits.map(() => (rng() * 2 - 1) * amountSec)
  return { ...pattern, micros }
}

/** Combine two patterns (OR their hits, max their velocities). */
export function combine(a: RhythmPattern, b: RhythmPattern): RhythmPattern {
  const len = Math.max(a.hits.length, b.hits.length)
  const hits: boolean[] = []
  const velocities: number[] = []
  for (let i = 0; i < len; i++) {
    const ha = a.hits[i] ?? false
    const hb = b.hits[i] ?? false
    hits.push(ha || hb)
    const va = a.velocities?.[i] ?? 0
    const vb = b.velocities?.[i] ?? 0
    velocities.push(Math.max(va, vb))
  }
  return rhythm(hits, { velocities })
}

/** Invert a pattern (hits become rests, rests become hits). */
export function invertRhythm(pattern: RhythmPattern): RhythmPattern {
  return rhythm(
    pattern.hits.map((h) => !h),
    { velocities: pattern.velocities }
  )
}

/** Density of a pattern: fraction of steps that are hits. */
export function density(pattern: RhythmPattern): number {
  if (pattern.hits.length === 0) return 0
  return pattern.hits.filter(Boolean).length / pattern.hits.length
}
