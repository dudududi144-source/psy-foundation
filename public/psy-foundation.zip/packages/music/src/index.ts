/**
 * @psy-foundation/music
 *
 * Musical intelligence primitives. STRUCTURED VARIATION, not random generation.
 *
 * Modules:
 *  - scales.ts    18 scales/modes (incl. phrygian-dominant from psy audit)
 *  - chords.ts    18 chord types + voice leading + tension scoring
 *  - motif.ts     call-&-response motif generator (extracted from psy) +
 *                 variation operators (transpose, invert, fragment, retrograde)
 *  - bass.ts      bass grammar (kb3, four-on-floor, offbeat, syncopated) +
 *                 tension curves (flat, build, release, peak, valley)
 *  - rhythm.ts    rhythm patterns + swing + humanize + combine + density
 */

export type { Scale } from './scales.ts'
export {
  degreeToMidi,
  degreeToPc,
  getScale,
  isInScale,
  listScales,
  nameToPc,
  nearestDegree,
  pcToName,
  scaleNotes,
  scalePcs,
  stableDegrees,
} from './scales.ts'
export type { ChordType } from './chords.ts'
export {
  chordNotes,
  chordPcs,
  chordTension,
  getChordType,
  listChordTypes,
  voiceChord,
} from './chords.ts'
export type { MotifNote, MotifOptions } from './motif.ts'
export {
  fragment,
  generateMotif,
  invert,
  retrograde,
  transpose,
  vary,
} from './motif.ts'
export type { BassNote, BassPatternOptions, TensionCurve } from './bass.ts'
export {
  generateBassPattern,
  sampleTension,
  tensionToDensity,
  tensionToOctave,
} from './bass.ts'
export type { RhythmPattern } from './rhythm.ts'
export {
  backbeat,
  combine,
  density,
  drivingHats,
  fourOnFloor,
  humanize,
  invertRhythm,
  offbeatHats,
  psyKick,
  rhythm,
  swing,
} from './rhythm.ts'
export { Rng } from './rng.ts'
