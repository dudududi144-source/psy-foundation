/**
 * Motif generation & variation.
 *
 * Extracted and generalized from psy/index.html:200-281 — the lead motif
 * generator that was identified in the M0 audit as "the single most valuable
 * piece of music intelligence in the entire PSY family".
 *
 * The motif generator produces a 32-step call-&-response phrase:
 *  - stable tones (root/fifth) on strong beats
 *  - passing motion off-beat
 *  - response bar shifted ±1 scale degree, resolved to root
 *  - glide only on characteristic 2-3 semitone intervals
 *
 * Pure functions of (seed, rootPc, scale, options). Deterministic. No randomness
 * except through the injected seed.
 */

import { Rng } from './rng.ts'
import type { Scale } from './scales.ts'
import { degreeToMidi, stableDegrees } from './scales.ts'

export interface MotifOptions {
  /** Seed for deterministic generation. */
  seed?: number
  /** Number of steps in the motif (default 32 = 2 bars at 16-step). */
  steps?: number
  /** Density 0..1 — probability of a note on any given step. */
  density?: number
  /** Glide probability 0..1 for characteristic intervals. */
  glideProb?: number
  /** Response shift in scale degrees (default 1). */
  responseShift?: number
  /** Strong-beat pattern: which steps (0-indexed) are "strong". Default [0, 8, 16, 24]. */
  strongBeats?: number[]
}

export interface MotifNote {
  /** Step index 0..steps-1. */
  step: number
  /** MIDI note. */
  midi: number
  /** 0..1 velocity. */
  velocity: number
  /** Duration in steps. */
  durationSteps: number
  /** Should this note glide from the previous? */
  glide: boolean
}

const DEFAULTS: Required<MotifOptions> = {
  seed: 1,
  steps: 32,
  density: 0.6,
  glideProb: 0.4,
  responseShift: 1,
  strongBeats: [0, 8, 16, 24],
}

/**
 * Generate a call-&-response motif.
 *
 * The motif is two halves:
 *  - first half (steps 0..steps/2-1): the "call" — starts on a stable tone,
 *    moves by step, lands on a stable tone at the end.
 *  - second half (steps steps/2..steps-1): the "response" — shifts the call
 *    by `responseShift` scale degrees, then resolves to the root on the final
 *    strong beat.
 */
export function generateMotif(rootPc: number, scale: Scale, opts: MotifOptions = {}): MotifNote[] {
  const o = { ...DEFAULTS, ...opts }
  const rng = new Rng(o.seed)
  const half = Math.floor(o.steps / 2)
  const stable = stableDegrees(scale)
  const rootDegree = 0

  const notes: MotifNote[] = []

  // ── Call ──
  let currentDegree = stable[0] ?? 0
  for (let i = 0; i < half; i++) {
    const isStrong = o.strongBeats.includes(i)
    if (isStrong) {
      // Strong beat: prefer a stable tone.
      const target = stable[rng.next() < 0.7 ? 0 : 1] ?? 0
      const glide = shouldGlide(currentDegree, target, scale, rng, o.glideProb)
      notes.push({
        step: i,
        midi: degreeToMidi(rootPc, scale, target),
        velocity: 0.9,
        durationSteps: 1,
        glide,
      })
      currentDegree = target
    } else if (rng.next() < o.density) {
      // Off-beat: step motion (±1 or ±2 degrees).
      const stepDir = rng.next() < 0.5 ? 1 : -1
      const stepSize = rng.next() < 0.7 ? 1 : 2
      const nextDeg = currentDegree + stepDir * stepSize
      const glide = shouldGlide(currentDegree, nextDeg, scale, rng, o.glideProb)
      notes.push({
        step: i,
        midi: degreeToMidi(rootPc, scale, nextDeg),
        velocity: 0.6,
        durationSteps: 1,
        glide,
      })
      currentDegree = nextDeg
    }
  }

  // ── Response ──
  // Shift the call by responseShift, then resolve to root at the end.
  for (let i = 0; i < half; i++) {
    const responseStep = i + half
    const isStrong = o.strongBeats.includes(responseStep)
    const isFinal = i === half - 1

    if (isFinal) {
      // Resolve to root on the final strong beat.
      notes.push({
        step: responseStep,
        midi: degreeToMidi(rootPc, scale, rootDegree),
        velocity: 1,
        durationSteps: 2,
        glide: shouldGlide(currentDegree, rootDegree, scale, rng, o.glideProb),
      })
      currentDegree = rootDegree
    } else if (isStrong) {
      // Strong beat: shifted stable tone.
      const target = (stable[rng.next() < 0.7 ? 0 : 1] ?? 0) + o.responseShift
      const glide = shouldGlide(currentDegree, target, scale, rng, o.glideProb)
      notes.push({
        step: responseStep,
        midi: degreeToMidi(rootPc, scale, target),
        velocity: 0.85,
        durationSteps: 1,
        glide,
      })
      currentDegree = target
    } else if (rng.next() < o.density) {
      // Off-beat: step motion, shifted.
      const stepDir = rng.next() < 0.5 ? 1 : -1
      const stepSize = rng.next() < 0.7 ? 1 : 2
      const nextDeg = currentDegree + stepDir * stepSize
      const glide = shouldGlide(currentDegree, nextDeg, scale, rng, o.glideProb)
      notes.push({
        step: responseStep,
        midi: degreeToMidi(rootPc, scale, nextDeg),
        velocity: 0.55,
        durationSteps: 1,
        glide,
      })
      currentDegree = nextDeg
    }
  }

  return notes
}

/** Decide whether to glide based on the interval size (characteristic = 2-3 semitones). */
function shouldGlide(
  fromDeg: number,
  toDeg: number,
  scale: Scale,
  rng: Rng,
  glideProb: number
): boolean {
  const fromMidi = degreeToMidi(0, scale, fromDeg)
  const toMidi = degreeToMidi(0, scale, toDeg)
  const interval = Math.abs(toMidi - fromMidi)
  // Glide only on small characteristic intervals (1-3 semitones).
  if (interval >= 1 && interval <= 3) {
    return rng.next() < glideProb
  }
  return false
}

// ── Variation operators (structured variation, not random) ──

/** Transpose a motif by N scale degrees. */
export function transpose(
  notes: MotifNote[],
  rootPc: number,
  scale: Scale,
  degrees: number
): MotifNote[] {
  if (degrees === 0) return notes.map((n) => ({ ...n }))
  // Find each note's degree, shift it, recompute midi.
  return notes.map((n) => {
    const oldDeg = findDegreeForMidi(rootPc, scale, n.midi)
    const newDeg = oldDeg + degrees
    return { ...n, midi: degreeToMidi(rootPc, scale, newDeg) }
  })
}

/** Invert a motif around its first note (mirror in scale-degree space). */
export function invert(notes: MotifNote[], rootPc: number, scale: Scale): MotifNote[] {
  if (notes.length === 0) return []
  const firstDeg = findDegreeForMidi(rootPc, scale, notes[0].midi)
  return notes.map((n) => {
    const deg = findDegreeForMidi(rootPc, scale, n.midi)
    const inverted = firstDeg - (deg - firstDeg)
    return { ...n, midi: degreeToMidi(rootPc, scale, inverted) }
  })
}

/** Fragment: keep only the first N notes. */
export function fragment(notes: MotifNote[], count: number): MotifNote[] {
  return notes.slice(0, count)
}

/** Retrograde: reverse the note order (keeps step positions). */
export function retrograde(notes: MotifNote[]): MotifNote[] {
  return [...notes].reverse().map((n, _i) => ({ ...n }))
}

/**
 * Apply a named variation transform.
 * This is the API the learning system (M4) will call: it gives a name to each
 * operator so actions are describable.
 */
export function vary(
  notes: MotifNote[],
  rootPc: number,
  scale: Scale,
  transform: 'transpose' | 'invert' | 'fragment' | 'retrograde' | 'none',
  amount = 1
): MotifNote[] {
  switch (transform) {
    case 'transpose':
      return transpose(notes, rootPc, scale, amount)
    case 'invert':
      return invert(notes, rootPc, scale)
    case 'fragment':
      return fragment(notes, amount)
    case 'retrograde':
      return retrograde(notes)
    default:
      return notes.map((n) => ({ ...n }))
  }
}

/** Find the scale degree whose MIDI is closest to a given MIDI note. */
function findDegreeForMidi(rootPc: number, scale: Scale, midi: number): number {
  let bestDeg = 0
  let bestDist = Number.POSITIVE_INFINITY
  for (let d = -14; d <= 28; d++) {
    const m = degreeToMidi(rootPc, scale, d)
    const dist = Math.abs(m - midi)
    if (dist < bestDist) {
      bestDist = dist
      bestDeg = d
    }
  }
  return bestDeg
}
