/** A compact, serializable view of {@link MusicalTransport} for messaging. */
export interface TransportState {
  bpm: number
  beat: number
  bar: number
  phase: number
  locked: boolean
  confidence: number
  revision: number
}

/** The musical situation a device is operating in. */
export interface MusicalContext {
  /** Tonic note name, e.g. 'A'. */
  key: string
  /** Tonic pitch class, 0..11 (C=0). */
  rootPc: number
  /** Scale name, e.g. 'phrygian-dominant'. */
  scale: string
  /** Energy 0..1. */
  energy: number
  /** Style label, e.g. 'full-on', 'progressive'. */
  style: string
  /** Current section label, e.g. 'drop'. */
  section: string
  beatsPerBar: number
}

/** What a device can do. Advertised via {@link PsyDevice.capabilities}. */
export interface DeviceCapabilities {
  /** Can produce audio output. */
  audio: boolean
  /** Consumes/produces MIDI. */
  midi: boolean
  /** Number of input channels. */
  inputs: number
  /** Number of output channels. */
  outputs: number
  /** Max polyphony (0 = none / unlimited). */
  voices: number
  /** Reported output latency in milliseconds. */
  latencyMs: number
  /** Roles this device can fill, e.g. ['kick','bass','lead']. */
  roles: string[]
}

/** Live status of a device in a session. */
export interface DeviceState {
  id: string
  online: boolean
  lastSeen: number
  capabilities: DeviceCapabilities
}

/** A session = a group of devices sharing transport + context. */
export interface SessionState {
  id: string
  startedAt: number
  devices: DeviceState[]
}

/** Material kinds reusable across devices. */
export type MaterialType =
  | 'motif'
  | 'rhythm'
  | 'bass-pattern'
  | 'drum-pattern'
  | 'fill'
  | 'phrase'
  | 'fx-gesture'
  | 'preset'
  | 'texture'

/** A unit of reusable musical material with metadata. */
export interface Material {
  id: string
  type: MaterialType
  role: string
  style: string
  /** [minBpm, maxBpm] this material suits. */
  tempoRange: [number, number]
  /** Compatible root pitch classes (empty = any). */
  keyCompatibility: number[]
  /** 0..1 typical energy. */
  energy: number
  /** 0..1 novelty vs the rest of the library. */
  novelty: number
  /** Origin label, e.g. 'hand-authored', 'generated', 'extracted-psy4'. */
  source: string
  /** 0..1 confidence in this material. */
  confidence: number
  /** How many times it has been used. */
  usageCount: number
  /** Accumulated reward from the learning system. */
  reward: number
  /** Last-used audio time, or null. */
  lastUsed: number | null
  /** Type-specific payload. */
  payload: unknown
}

/** An action a device (or orchestrator) can take. `do-nothing` is legal. */
export type MusicalAction =
  | { type: 'play'; materialId: string }
  | { type: 'variation'; materialId: string; transform: string }
  | { type: 'do-nothing' }

/** What happened as a result of an action. */
export type MusicalOutcome =
  | { type: 'sounded'; durationSec: number }
  | { type: 'skipped' }
  | { type: 'collided'; reason: string }

/** A recorded experience for the learning system. */
export interface Experience {
  context: MusicalContext
  action: MusicalAction
  outcome: MusicalOutcome
  /** -1..1 reward signal. */
  reward: number
  at: number
}
