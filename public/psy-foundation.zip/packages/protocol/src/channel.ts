/**
 * Channel — the transport-agnostic messaging abstraction.
 *
 * The protocol does NOT assume any specific transport. Today an in-memory
 * broadcast is enough for tests and single-page devices. Future adapters
 * (BroadcastChannel, WebSocket, WebRTC, Web MIDI, Ableton Link) implement
 * this same interface.
 *
 * IMPORTANT: This is the MESSAGING transport, distinct from the MUSICAL
 * transport (MusicalTransport = the time model). Naming is kept separate to
 * avoid the confusion that plagued PSY6.
 */

import type { MusicalEvent } from './events.ts'

export type ChannelListener<E = MusicalEvent> = (event: E) => void
export type Unsubscribe = () => void

export interface Channel {
  /** Subscribe to events. Returns an unsubscribe function. */
  subscribe(listener: ChannelListener): Unsubscribe
  /** Publish an event to all subscribers. */
  publish(event: MusicalEvent): void
  /** Tear down all subscriptions. */
  close(): void
  /** Human-readable name for debugging. */
  readonly name: string
}

/**
 * InMemoryChannel — reference implementation. Synchronous broadcast to all
 * subscribers in the current process. Used by tests, single-page multi-device
 * setups, and as the fallback when no network transport is configured.
 */
export class InMemoryChannel implements Channel {
  readonly name: string
  private readonly listeners = new Set<ChannelListener>()
  private closed = false

  constructor(name = 'in-memory') {
    this.name = name
  }

  subscribe(listener: ChannelListener): Unsubscribe {
    if (this.closed) throw new Error(`Channel "${this.name}" is closed`)
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  publish(event: MusicalEvent): void {
    if (this.closed) return
    // Snapshot to allow unsubscribe during iteration.
    const listeners = Array.from(this.listeners)
    for (const l of listeners) l(event)
  }

  close(): void {
    this.closed = true
    this.listeners.clear()
  }

  /** Current subscriber count (for tests / introspection). */
  get subscriberCount(): number {
    return this.listeners.size
  }
}
