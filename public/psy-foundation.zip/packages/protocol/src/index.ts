/**
 * @psy-foundation/protocol
 *
 * Typed events and state schemas shared across the PSY device family.
 * Transport-agnostic messaging via the {@link Channel} abstraction.
 */

export type {
  EventTime,
  MusicalEvent,
  BeatEvent,
  SectionEvent,
  EnergyEvent,
  DropEvent,
  NoteEvent,
  PatternEvent,
  EventOfType,
} from './events.ts'
export type {
  TransportState,
  MusicalContext,
  DeviceCapabilities,
  DeviceState,
  SessionState,
  Material,
  MaterialType,
  MusicalAction,
  MusicalOutcome,
  Experience,
} from './state.ts'
export type { Channel, ChannelListener, Unsubscribe } from './channel.ts'
export { InMemoryChannel } from './channel.ts'
