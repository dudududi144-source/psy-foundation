/**
 * Musical events — the typed messages that flow over a {@link Channel}.
 *
 * Transport-agnostic: these schemas carry no assumption about whether they
 * travel over BroadcastChannel, WebSocket, WebRTC, Web MIDI, or an Ableton
 * Link adapter. The Channel abstraction (see ./channel.ts) is the only
 * delivery contract.
 *
 * Events are VALUES, not callbacks. A device that receives a `BeatEvent` can
 * replay it, log it, or ignore it. This keeps devices deterministic and
 * testable.
 */

import type { MusicalTransport } from '@psy-foundation/transport'

/** Audio-context time (seconds) at which the event is/was relevant. */
export type EventTime = number

export interface BeatEvent {
  type: 'beat'
  beat: number
  bar: number
  /** Snapshot of the transport at this beat (single source of truth). */
  transport: MusicalTransport
  at: EventTime
}

export interface SectionEvent {
  type: 'section'
  /** e.g. 'intro', 'build', 'drop', 'breakdown', 'riser'. */
  section: string
  bar: number
  at: EventTime
}

export interface EnergyEvent {
  type: 'energy'
  /** 0..1 energy estimate. */
  energy: number
  at: EventTime
}

export interface DropEvent {
  type: 'drop'
  /** 0..1 intensity. */
  intensity: number
  at: EventTime
}

export interface NoteEvent {
  type: 'note'
  /** MIDI note number. */
  note: number
  /** 0..1 velocity. */
  velocity: number
  /** Duration in seconds. */
  duration: number
  /** Logical channel / track id. */
  channel: string
  at: EventTime
}

export interface PatternEvent {
  type: 'pattern'
  patternId: string
  trackId: string
  at: EventTime
}

export type MusicalEvent =
  | BeatEvent
  | SectionEvent
  | EnergyEvent
  | DropEvent
  | NoteEvent
  | PatternEvent

/** Narrow a MusicalEvent to a specific `type`. */
export type EventOfType<T extends MusicalEvent['type']> = Extract<MusicalEvent, { type: T }>
