/**
 * Material factory — convenience builders that use the music package to
 * generate material payloads and wrap them in full Material objects.
 *
 * These are the "authoring" entry points: a composer or generator calls
 * makeMotifMaterial / makeBassPatternMaterial / etc. to get a ready-to-use
 * Material with metadata.
 */

import { generateBassPattern, generateMotif, getScale } from '@psy-foundation/music'
import type { RhythmPattern } from '@psy-foundation/music'
import type { Material } from '@psy-foundation/protocol'
import { createMaterial } from './material.ts'
import type {
  BassPatternPayload,
  DrumPatternPayload,
  FXGesturePayload,
  FillPayload,
  MotifPayload,
  PresetPayload,
  RhythmPayload,
  TexturePayload,
} from './types.ts'

export interface MotifMaterialOptions {
  rootPc: number
  scaleName: string
  seed?: number
  steps?: number
  density?: number
  role?: string
  style?: string
  energy?: number
}

/** Build a Motif material from generator options. */
export function makeMotifMaterial(opts: MotifMaterialOptions): Material {
  const scale = getScale(opts.scaleName)
  if (!scale) throw new Error(`Unknown scale: ${opts.scaleName}`)

  const genOpts: { seed?: number; steps?: number; density?: number } = {}
  if (opts.seed !== undefined) genOpts.seed = opts.seed
  if (opts.steps !== undefined) genOpts.steps = opts.steps
  if (opts.density !== undefined) genOpts.density = opts.density
  const notes = generateMotif(opts.rootPc, scale, genOpts)

  const payload: MotifPayload = {
    kind: 'motif',
    rootPc: opts.rootPc,
    scaleName: opts.scaleName,
    notes,
  }

  return createMaterial({
    role: opts.role ?? 'lead',
    style: opts.style ?? 'psytrance',
    tempoRange: [130, 170],
    keyCompatibility: [opts.rootPc],
    energy: opts.energy ?? 0.7,
    novelty: 0.5,
    source: 'generated',
    confidence: 0.8,
    payload,
  })
}

export interface BassMaterialOptions {
  rootPc: number
  scaleName: string
  style?: 'kb3' | 'four-on-floor' | 'offbeat' | 'syncopated'
  seed?: number
  role?: string
  energy?: number
}

/** Build a BassPattern material. */
export function makeBassPatternMaterial(opts: BassMaterialOptions): Material {
  const scale = getScale(opts.scaleName)
  if (!scale) throw new Error(`Unknown scale: ${opts.scaleName}`)

  const bassOpts: { style?: 'kb3' | 'four-on-floor' | 'offbeat' | 'syncopated'; seed?: number } = {}
  if (opts.style !== undefined) bassOpts.style = opts.style
  if (opts.seed !== undefined) bassOpts.seed = opts.seed
  const notes = generateBassPattern(opts.rootPc, scale, bassOpts)

  const payload: BassPatternPayload = {
    kind: 'bass-pattern',
    rootPc: opts.rootPc,
    scaleName: opts.scaleName,
    style: opts.style ?? 'kb3',
    notes,
  }

  return createMaterial({
    role: opts.role ?? 'bass',
    style: 'psytrance',
    tempoRange: [130, 170],
    keyCompatibility: [opts.rootPc],
    energy: opts.energy ?? 0.8,
    novelty: 0.3,
    source: 'generated',
    confidence: 0.85,
    payload,
  })
}

export interface RhythmMaterialOptions {
  pattern: RhythmPattern
  role?: string
  style?: string
  energy?: number
}

/** Build a Rhythm material from an existing RhythmPattern. */
export function makeRhythmMaterial(opts: RhythmMaterialOptions): Material {
  const payload: RhythmPayload = {
    kind: 'rhythm',
    steps: opts.pattern.hits.length,
    hits: opts.pattern.hits,
    velocities: opts.pattern.velocities ?? opts.pattern.hits.map(() => 1),
    micros: opts.pattern.micros ?? opts.pattern.hits.map(() => 0),
  }

  return createMaterial({
    role: opts.role ?? 'percussion',
    style: opts.style ?? 'psytrance',
    tempoRange: [120, 180],
    keyCompatibility: [],
    energy: opts.energy ?? 0.6,
    novelty: 0.3,
    source: 'generated',
    confidence: 0.8,
    payload,
  })
}

export interface DrumPatternMaterialOptions {
  tracks: Record<string, RhythmPattern>
  role?: string
  style?: string
  energy?: number
}

/** Build a DrumPattern material (multi-track). */
export function makeDrumPatternMaterial(opts: DrumPatternMaterialOptions): Material {
  const payload: DrumPatternPayload = {
    kind: 'drum-pattern',
    tracks: opts.tracks,
  }

  return createMaterial({
    role: opts.role ?? 'drums',
    style: opts.style ?? 'psytrance',
    tempoRange: [130, 170],
    keyCompatibility: [],
    energy: opts.energy ?? 0.75,
    novelty: 0.4,
    source: 'generated',
    confidence: 0.85,
    payload,
  })
}

export interface FillMaterialOptions {
  steps: number
  notesByStep: number[][]
  velocities: number[]
  role?: string
  energy?: number
}

/** Build a Fill material. */
export function makeFillMaterial(opts: FillMaterialOptions): Material {
  const payload: FillPayload = {
    kind: 'fill',
    steps: opts.steps,
    notesByStep: opts.notesByStep,
    velocities: opts.velocities,
    role: opts.role ?? 'snare',
  }

  return createMaterial({
    role: opts.role ?? 'fill',
    style: 'psytrance',
    tempoRange: [130, 170],
    keyCompatibility: [],
    energy: opts.energy ?? 0.6,
    novelty: 0.6,
    source: 'generated',
    confidence: 0.7,
    payload,
  })
}

export interface PresetMaterialOptions {
  engine: string
  params: Record<string, number>
  role?: string
  style?: string
}

/** Build a Preset material. */
export function makePresetMaterial(opts: PresetMaterialOptions): Material {
  const payload: PresetPayload = {
    kind: 'preset',
    engine: opts.engine,
    params: opts.params,
  }

  return createMaterial({
    role: opts.role ?? 'synth',
    style: opts.style ?? 'psytrance',
    tempoRange: [60, 200],
    keyCompatibility: [],
    energy: 0.5,
    novelty: 0.3,
    source: 'hand-authored',
    confidence: 0.9,
    payload,
  })
}

export interface FXGestureMaterialOptions {
  param: string
  points: Array<{ t: number; v: number }>
  durationSec: number
  role?: string
}

/** Build an FXGesture material. */
export function makeFXGestureMaterial(opts: FXGestureMaterialOptions): Material {
  const payload: FXGesturePayload = {
    kind: 'fx-gesture',
    param: opts.param,
    points: opts.points,
    durationSec: opts.durationSec,
  }

  return createMaterial({
    role: opts.role ?? 'fx',
    style: 'psytrance',
    tempoRange: [60, 200],
    keyCompatibility: [],
    energy: 0.4,
    novelty: 0.5,
    source: 'generated',
    confidence: 0.7,
    payload,
  })
}

export interface TextureMaterialOptions {
  rootHz: number
  partials: Array<{ ratio: number; amp: number }>
  lfo?: { rateHz: number; depth: number }
  role?: string
}

/** Build a Texture material. */
export function makeTextureMaterial(opts: TextureMaterialOptions): Material {
  const payload: TexturePayload = {
    kind: 'texture',
    rootHz: opts.rootHz,
    partials: opts.partials,
    lfo: opts.lfo,
  }

  return createMaterial({
    role: opts.role ?? 'texture',
    style: 'psytrance',
    tempoRange: [60, 200],
    keyCompatibility: [],
    energy: 0.3,
    novelty: 0.4,
    source: 'generated',
    confidence: 0.7,
    payload,
  })
}
