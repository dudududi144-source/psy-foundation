/**
 * @psy-foundation/material
 *
 * Musical material library. Reusable across devices.
 */

export type {
  BassPatternPayload,
  DrumPatternPayload,
  FillPayload,
  FXGesturePayload,
  MaterialPayload,
  MotifPayload,
  PresetPayload,
  RhythmPayload,
  TexturePayload,
} from './types.ts'
export { payloadKind } from './types.ts'
export {
  createMaterial,
  MaterialLibrary,
} from './material.ts'
export type { CreateMaterialOptions, MaterialMetadata } from './material.ts'
export {
  makeBassPatternMaterial,
  makeDrumPatternMaterial,
  makeFXGestureMaterial,
  makeFillMaterial,
  makeMotifMaterial,
  makePresetMaterial,
  makeRhythmMaterial,
  makeTextureMaterial,
} from './factory.ts'
export type {
  BassMaterialOptions,
  DrumPatternMaterialOptions,
  FillMaterialOptions,
  FXGestureMaterialOptions,
  MotifMaterialOptions,
  PresetMaterialOptions,
  RhythmMaterialOptions,
  TextureMaterialOptions,
} from './factory.ts'
export { createSeedLibrary } from './seed.ts'
