/**
 * Seed library — a starter collection of materials for the PSY family.
 *
 * This is the "data/scales + data/motifs + data/rhythms" of the foundation
 * in code form (a future iteration can load from JSON files in data/).
 *
 * Every device gets the same seed library. The learning system (M4) extends
 * it at runtime.
 */

import { backbeat, drivingHats, fourOnFloor, offbeatHats, psyKick } from '@psy-foundation/music'
import type { Material } from '@psy-foundation/protocol'
import {
  makeBassPatternMaterial,
  makeDrumPatternMaterial,
  makeFXGestureMaterial,
  makeMotifMaterial,
  makePresetMaterial,
  makeRhythmMaterial,
  makeTextureMaterial,
} from './factory.ts'
import { MaterialLibrary } from './material.ts'

/** Build the default seed library. */
export function createSeedLibrary(): MaterialLibrary {
  const lib = new MaterialLibrary()

  // ── Motifs (psy lead in phrygian-dominant, several seeds) ──
  const motifs: Material[] = [
    makeMotifMaterial({
      rootPc: 4,
      scaleName: 'phrygian-dominant',
      seed: 1,
      role: 'lead',
      energy: 0.75,
    }),
    makeMotifMaterial({
      rootPc: 4,
      scaleName: 'phrygian-dominant',
      seed: 2,
      role: 'lead',
      energy: 0.7,
    }),
    makeMotifMaterial({
      rootPc: 9,
      scaleName: 'phrygian-dominant',
      seed: 3,
      role: 'lead',
      energy: 0.8,
    }),
    makeMotifMaterial({
      rootPc: 11,
      scaleName: 'harmonic-minor',
      seed: 4,
      role: 'lead',
      energy: 0.7,
    }),
  ]
  for (const m of motifs) lib.add(m)

  // ── Bass patterns ──
  const basses: Material[] = [
    makeBassPatternMaterial({ rootPc: 4, scaleName: 'phrygian-dominant', style: 'kb3', seed: 1 }),
    makeBassPatternMaterial({ rootPc: 4, scaleName: 'phrygian-dominant', style: 'offbeat' }),
    makeBassPatternMaterial({ rootPc: 9, scaleName: 'phrygian-dominant', style: 'kb3', seed: 2 }),
  ]
  for (const m of basses) lib.add(m)

  // ── Rhythms ──
  lib.add(makeRhythmMaterial({ pattern: psyKick(), role: 'kick', energy: 0.9 }))
  lib.add(makeRhythmMaterial({ pattern: fourOnFloor(), role: 'kick', energy: 0.85 }))
  lib.add(makeRhythmMaterial({ pattern: offbeatHats(), role: 'hat', energy: 0.5 }))
  lib.add(makeRhythmMaterial({ pattern: drivingHats(), role: 'hat', energy: 0.7 }))
  lib.add(makeRhythmMaterial({ pattern: backbeat(), role: 'snare', energy: 0.6 }))

  // ── Drum patterns (multi-track) ──
  lib.add(
    makeDrumPatternMaterial({
      tracks: {
        kick: fourOnFloor(),
        hat: offbeatHats(),
        snare: backbeat(),
      },
      energy: 0.85,
    })
  )
  lib.add(
    makeDrumPatternMaterial({
      tracks: {
        kick: psyKick(),
        hat: drivingHats(),
      },
      energy: 0.8,
    })
  )

  // ── Presets ──
  lib.add(
    makePresetMaterial({
      engine: 'psy-lead',
      params: { cutoff: 0.7, resonance: 0.4, decay: 0.3, detune: 0.15 },
      role: 'lead',
    })
  )
  lib.add(
    makePresetMaterial({
      engine: 'psy-bass',
      params: { cutoff: 0.5, resonance: 0.6, decay: 0.2, distortion: 0.4 },
      role: 'bass',
    })
  )

  // ── FX gestures ──
  lib.add(
    makeFXGestureMaterial({
      param: 'filter-cutoff',
      points: [
        { t: 0, v: 0.2 },
        { t: 0.5, v: 0.8 },
        { t: 1, v: 0.3 },
      ],
      durationSec: 4,
      role: 'filter-sweep',
    })
  )

  // ── Textures ──
  lib.add(
    makeTextureMaterial({
      rootHz: 55,
      partials: [
        { ratio: 1, amp: 1 },
        { ratio: 1.5, amp: 0.5 },
        { ratio: 2, amp: 0.3 },
        { ratio: 3, amp: 0.15 },
      ],
      lfo: { rateHz: 0.1, depth: 0.3 },
      role: 'drone',
    })
  )

  return lib
}
