/**
 * Material builder + library.
 *
 * A {@link Material} (from @psy-foundation/protocol) is the unit of reusable
 * musical content. This module provides:
 *  - {@link createMaterial}: build a Material with full metadata from a payload.
 *  - {@link MaterialLibrary}: an in-memory store with query + usage tracking.
 *
 * Metadata is the contract: every material carries role, style, tempo range,
 * key compatibility, energy, novelty, source, confidence, usage count, reward,
 * last used. This is what the learning system (M4) reads to decide what to play.
 */

import type { Material, MaterialType } from '@psy-foundation/protocol'
import type { MaterialPayload } from './types.ts'

export interface MaterialMetadata {
  role: string
  style: string
  tempoRange: [number, number]
  keyCompatibility: number[]
  energy: number
  novelty: number
  source: string
  confidence: number
}

export interface CreateMaterialOptions extends MaterialMetadata {
  id?: string
  payload: MaterialPayload
}

let idCounter = 0

/** Generate a stable id. */
function nextId(prefix: string): string {
  idCounter += 1
  return `${prefix}-${idCounter.toString(36).padStart(4, '0')}`
}

/** Create a Material with full metadata. */
export function createMaterial(opts: CreateMaterialOptions): Material {
  return {
    id: opts.id ?? nextId(opts.payload.kind),
    type: opts.payload.kind as MaterialType,
    role: opts.role,
    style: opts.style,
    tempoRange: opts.tempoRange,
    keyCompatibility: opts.keyCompatibility,
    energy: opts.energy,
    novelty: opts.novelty,
    source: opts.source,
    confidence: opts.confidence,
    usageCount: 0,
    reward: 0,
    lastUsed: null,
    payload: opts.payload,
  }
}

/**
 * MaterialLibrary — in-memory store with query + usage tracking.
 *
 * This is the single source of truth for "what material exists". Devices query
 * it; the learning system updates reward/usage on it. Persisted to disk/DB by
 * a future adapter — the library itself is transport-agnostic.
 */
export class MaterialLibrary {
  private readonly materials = new Map<string, Material>()

  /** Add a material. Throws if id already exists. */
  add(material: Material): void {
    if (this.materials.has(material.id)) {
      throw new Error(`Material already exists: ${material.id}`)
    }
    this.materials.set(material.id, material)
  }

  /** Get a material by id. */
  get(id: string): Material | undefined {
    return this.materials.get(id)
  }

  /** Remove a material. */
  remove(id: string): boolean {
    return this.materials.delete(id)
  }

  /** Total count. */
  get size(): number {
    return this.materials.size
  }

  /** List all materials. */
  list(): Material[] {
    return Array.from(this.materials.values())
  }

  /** Query materials by criteria. All filters are optional. */
  query(opts: {
    type?: MaterialType
    role?: string
    style?: string
    bpm?: number
    rootPc?: number
    minEnergy?: number
    maxEnergy?: number
    limit?: number
  }): Material[] {
    let results = this.list()

    if (opts.type) results = results.filter((m) => m.type === opts.type)
    if (opts.role) results = results.filter((m) => m.role === opts.role)
    if (opts.style) results = results.filter((m) => m.style === opts.style)
    if (opts.bpm !== undefined) {
      const bpm = opts.bpm
      results = results.filter((m) => bpm >= m.tempoRange[0] && bpm <= m.tempoRange[1])
    }
    if (opts.rootPc !== undefined) {
      const rootPc = opts.rootPc
      results = results.filter(
        (m) => m.keyCompatibility.length === 0 || m.keyCompatibility.includes(rootPc)
      )
    }
    if (opts.minEnergy !== undefined) {
      const minE = opts.minEnergy
      results = results.filter((m) => m.energy >= minE)
    }
    if (opts.maxEnergy !== undefined) {
      const maxE = opts.maxEnergy
      results = results.filter((m) => m.energy <= maxE)
    }

    if (opts.limit !== undefined) results = results.slice(0, opts.limit)
    return results
  }

  /** Record that a material was used (bumps usageCount + lastUsed). */
  markUsed(id: string, at: number): void {
    const m = this.materials.get(id)
    if (!m) return
    m.usageCount += 1
    m.lastUsed = at
  }

  /** Add reward to a material (for the learning system). */
  addReward(id: string, reward: number): void {
    const m = this.materials.get(id)
    if (!m) return
    m.reward += reward
  }

  /** Serialize to JSON (for persistence). */
  toJSON(): Material[] {
    return this.list()
  }

  /** Load from JSON. */
  static fromJSON(data: Material[]): MaterialLibrary {
    const lib = new MaterialLibrary()
    for (const m of data) lib.add(m)
    return lib
  }
}
