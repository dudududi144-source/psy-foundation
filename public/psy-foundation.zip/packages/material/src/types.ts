/**
 * Material types — the concrete payloads for each {@link MaterialType}.
 *
 * A {@link Material} (from @psy-foundation/protocol) carries metadata +
 * an opaque `payload`. This module defines the typed payloads so that
 * devices and the learning system can pattern-match on material kind.
 *
 * Every payload is serializable (JSON-safe) so material can travel over a
 * Channel or be persisted to a library.
 */

import type { BassNote, MotifNote, RhythmPattern } from '@psy-foundation/music'

/** A motif: a sequence of notes with step positions. */
export interface MotifPayload {
  kind: 'motif'
  rootPc: number
  scaleName: string
  notes: MotifNote[]
}

/** A rhythm pattern: hits + velocities + micros. */
export interface RhythmPayload {
  kind: 'rhythm'
  steps: number
  hits: boolean[]
  velocities: number[]
  micros: number[]
}

/** A bass pattern: notes with step positions. */
export interface BassPatternPayload {
  kind: 'bass-pattern'
  rootPc: number
  scaleName: string
  style: string
  notes: BassNote[]
}

/** A drum pattern: per-track rhythm patterns. */
export interface DrumPatternPayload {
  kind: 'drum-pattern'
  /** Map of role → rhythm. Roles: 'kick', 'bass', 'snare', 'hat', 'lead'. */
  tracks: Record<string, RhythmPattern>
}

/** A fill: a short pattern played at section boundaries. */
export interface FillPayload {
  kind: 'fill'
  /** Length in steps. */
  steps: number
  /** MIDI notes per step (can be empty for rests). */
  notesByStep: number[][]
  /** Velocity per step. */
  velocities: number[]
  /** Which role this fill targets (e.g. 'snare', 'tom'). */
  role: string
}

/** A phrase: a multi-bar sequence of motifs. */
export interface PhrasePayload {
  kind: 'phrase'
  bars: Array<{
    motifId?: string
    bassPatternId?: string
    drumPatternId?: string
  }>
}

/** An FX gesture: a parameter automation curve. */
export interface FXGesturePayload {
  kind: 'fx-gesture'
  /** Parameter name (e.g. 'filter-cutoff', 'reverb-wet'). */
  param: string
  /** (time, value) pairs, normalized 0..1. */
  points: Array<{ t: number; v: number }>
  /** Duration in seconds. */
  durationSec: number
}

/** A synth preset: a bag of parameters. */
export interface PresetPayload {
  kind: 'preset'
  /** Synth engine name (e.g. 'psy-lead', 'psy-bass'). */
  engine: string
  /** Parameter map. */
  params: Record<string, number>
}

/** A texture: an ambient/drone description. */
export interface TexturePayload {
  kind: 'texture'
  /** Root frequency. */
  rootHz: number
  /** Partials: (freq-ratio, amplitude). */
  partials: Array<{ ratio: number; amp: number }>
  /** Modulation: LFO rate in Hz and depth. */
  lfo?: { rateHz: number; depth: number }
}

/** The discriminated union of all payload types. */
export type MaterialPayload =
  | MotifPayload
  | RhythmPayload
  | BassPatternPayload
  | DrumPatternPayload
  | FillPayload
  | PhrasePayload
  | FXGesturePayload
  | PresetPayload
  | TexturePayload

/** Get the kind string from a payload. */
export function payloadKind(payload: MaterialPayload): string {
  return payload.kind
}
