import { describe, expect, test } from 'bun:test'
import {
  MaterialLibrary,
  createMaterial,
  createSeedLibrary,
  makeBassPatternMaterial,
  makeDrumPatternMaterial,
  makeFXGestureMaterial,
  makeMotifMaterial,
  makePresetMaterial,
  makeRhythmMaterial,
  makeTextureMaterial,
} from '../src/index.ts'
import type { MaterialPayload, PresetPayload } from '../src/index.ts'

describe('createMaterial', () => {
  test('builds a Material with full metadata', () => {
    const payload: PresetPayload = {
      kind: 'preset',
      engine: 'test',
      params: { cutoff: 0.5 },
    }
    const m = createMaterial({
      role: 'lead',
      style: 'psytrance',
      tempoRange: [130, 170],
      keyCompatibility: [4],
      energy: 0.7,
      novelty: 0.4,
      source: 'test',
      confidence: 0.9,
      payload,
    })
    expect(m.id).toMatch(/^preset-/)
    expect(m.type).toBe('preset')
    expect(m.role).toBe('lead')
    expect(m.usageCount).toBe(0)
    expect(m.reward).toBe(0)
    expect(m.lastUsed).toBeNull()
    expect(m.payload).toEqual(payload)
  })

  test('auto-generates unique ids', () => {
    const payload: PresetPayload = { kind: 'preset', engine: 'x', params: {} }
    const a = createMaterial({
      role: 'r',
      style: 's',
      tempoRange: [1, 2],
      keyCompatibility: [],
      energy: 0.5,
      novelty: 0.5,
      source: 't',
      confidence: 1,
      payload,
    })
    const b = createMaterial({
      role: 'r',
      style: 's',
      tempoRange: [1, 2],
      keyCompatibility: [],
      energy: 0.5,
      novelty: 0.5,
      source: 't',
      confidence: 1,
      payload,
    })
    expect(a.id).not.toBe(b.id)
  })
})

describe('factory builders', () => {
  test('makeMotifMaterial creates a motif with notes', () => {
    const m = makeMotifMaterial({ rootPc: 4, scaleName: 'phrygian-dominant', seed: 1 })
    expect(m.type).toBe('motif')
    expect(m.role).toBe('lead')
    const payload = m.payload as MaterialPayload
    expect(payload.kind).toBe('motif')
    if (payload.kind === 'motif') {
      expect(payload.notes.length).toBeGreaterThan(0)
      expect(payload.rootPc).toBe(4)
    }
  })

  test('makeMotifMaterial throws on unknown scale', () => {
    expect(() => makeMotifMaterial({ rootPc: 0, scaleName: 'nonexistent' })).toThrow()
  })

  test('makeBassPatternMaterial creates a bass pattern', () => {
    const m = makeBassPatternMaterial({ rootPc: 4, scaleName: 'phrygian-dominant', style: 'kb3' })
    expect(m.type).toBe('bass-pattern')
    expect(m.role).toBe('bass')
    if (m.payload.kind === 'bass-pattern') {
      expect(m.payload.notes.length).toBeGreaterThan(0)
    }
  })

  test('makeRhythmMaterial creates a rhythm', () => {
    const m = makeRhythmMaterial({
      pattern: {
        hits: [true, false, true, false],
        velocities: [1, 0, 0.5, 0],
        micros: [0, 0, 0, 0],
      },
    })
    expect(m.type).toBe('rhythm')
  })

  test('makeDrumPatternMaterial creates a multi-track drum pattern', () => {
    const m = makeDrumPatternMaterial({
      tracks: {
        kick: { hits: [true, false, false, false] },
        hat: { hits: [false, true, false, true] },
      },
    })
    expect(m.type).toBe('drum-pattern')
    if (m.payload.kind === 'drum-pattern') {
      expect(m.payload.tracks.kick).toBeDefined()
      expect(m.payload.tracks.hat).toBeDefined()
    }
  })

  test('makePresetMaterial creates a preset', () => {
    const m = makePresetMaterial({ engine: 'psy-lead', params: { cutoff: 0.7 } })
    expect(m.type).toBe('preset')
    expect(m.role).toBe('synth')
  })

  test('makeFXGestureMaterial creates an fx gesture', () => {
    const m = makeFXGestureMaterial({
      param: 'cutoff',
      points: [
        { t: 0, v: 0 },
        { t: 1, v: 1 },
      ],
      durationSec: 2,
    })
    expect(m.type).toBe('fx-gesture')
  })

  test('makeTextureMaterial creates a texture', () => {
    const m = makeTextureMaterial({
      rootHz: 55,
      partials: [{ ratio: 1, amp: 1 }],
    })
    expect(m.type).toBe('texture')
  })
})

describe('MaterialLibrary', () => {
  test('add + get', () => {
    const lib = new MaterialLibrary()
    const m = makePresetMaterial({ engine: 'x', params: {} })
    lib.add(m)
    expect(lib.size).toBe(1)
    expect(lib.get(m.id)).toBe(m)
  })

  test('add throws on duplicate id', () => {
    const lib = new MaterialLibrary()
    const m = makePresetMaterial({ engine: 'x', params: {} })
    lib.add(m)
    expect(() => lib.add(m)).toThrow()
  })

  test('remove', () => {
    const lib = new MaterialLibrary()
    const m = makePresetMaterial({ engine: 'x', params: {} })
    lib.add(m)
    expect(lib.remove(m.id)).toBe(true)
    expect(lib.size).toBe(0)
  })

  test('query by type', () => {
    const lib = new MaterialLibrary()
    lib.add(makeMotifMaterial({ rootPc: 0, scaleName: 'major' }))
    lib.add(makePresetMaterial({ engine: 'x', params: {} }))
    const motifs = lib.query({ type: 'motif' })
    expect(motifs.length).toBe(1)
  })

  test('query by role', () => {
    const lib = new MaterialLibrary()
    lib.add(makeMotifMaterial({ rootPc: 0, scaleName: 'major', role: 'lead' }))
    lib.add(makeBassPatternMaterial({ rootPc: 0, scaleName: 'major', role: 'bass' }))
    expect(lib.query({ role: 'bass' }).length).toBe(1)
    expect(lib.query({ role: 'lead' }).length).toBe(1)
  })

  test('query by bpm range', () => {
    const lib = new MaterialLibrary()
    lib.add(makeMotifMaterial({ rootPc: 0, scaleName: 'major' }))
    const at150 = lib.query({ bpm: 150 })
    const at50 = lib.query({ bpm: 50 })
    expect(at150.length).toBeGreaterThan(0)
    expect(at50.length).toBe(0) // default tempo range is 130-170
  })

  test('query by rootPc (key compat)', () => {
    const lib = new MaterialLibrary()
    lib.add(makeMotifMaterial({ rootPc: 4, scaleName: 'phrygian-dominant' })) // key compat = [4]
    lib.add(makeRhythmMaterial({ pattern: { hits: [true] } })) // key compat = []
    expect(lib.query({ rootPc: 4 }).length).toBe(2) // both match
    expect(lib.query({ rootPc: 9 }).length).toBe(1) // only the rhythm (empty compat)
  })

  test('markUsed bumps usageCount + lastUsed', () => {
    const lib = new MaterialLibrary()
    const m = makePresetMaterial({ engine: 'x', params: {} })
    lib.add(m)
    lib.markUsed(m.id, 123.4)
    const updated = lib.get(m.id) as never
    expect(updated.usageCount).toBe(1)
    expect(updated.lastUsed).toBe(123.4)
  })

  test('addReward accumulates', () => {
    const lib = new MaterialLibrary()
    const m = makePresetMaterial({ engine: 'x', params: {} })
    lib.add(m)
    lib.addReward(m.id, 0.5)
    lib.addReward(m.id, 0.3)
    expect(lib.get(m.id)?.reward).toBeCloseTo(0.8, 5)
  })

  test('toJSON / fromJSON round-trip', () => {
    const lib = new MaterialLibrary()
    lib.add(makePresetMaterial({ engine: 'x', params: { a: 1 } }))
    lib.add(makeMotifMaterial({ rootPc: 0, scaleName: 'major' }))
    const json = lib.toJSON()
    const restored = MaterialLibrary.fromJSON(json)
    expect(restored.size).toBe(lib.size)
    expect(restored.list()[0].id).toBe(lib.list()[0].id)
  })
})

describe('createSeedLibrary', () => {
  test('returns a library with starter materials', () => {
    const lib = createSeedLibrary()
    expect(lib.size).toBeGreaterThanOrEqual(15)
    // Should have at least one of each major type.
    expect(lib.query({ type: 'motif' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'bass-pattern' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'rhythm' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'drum-pattern' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'preset' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'fx-gesture' }).length).toBeGreaterThan(0)
    expect(lib.query({ type: 'texture' }).length).toBeGreaterThan(0)
  })

  test('seed materials have valid metadata', () => {
    const lib = createSeedLibrary()
    for (const m of lib.list()) {
      expect(m.role).toBeTruthy()
      expect(m.style).toBeTruthy()
      expect(m.tempoRange.length).toBe(2)
      expect(m.tempoRange[0]).toBeLessThan(m.tempoRange[1])
      expect(m.energy).toBeGreaterThanOrEqual(0)
      expect(m.energy).toBeLessThanOrEqual(1)
    }
  })

  test('seed library is deterministic (same materials each call)', () => {
    const a = createSeedLibrary()
    const b = createSeedLibrary()
    expect(a.size).toBe(b.size)
    // Same ids (idCounter is module-level, but seed library materials use
    // generated payloads with fixed seeds — the ids will differ due to the
    // counter, but the count and types match).
    const typesA = a
      .list()
      .map((m) => m.type)
      .sort()
    const typesB = b
      .list()
      .map((m) => m.type)
      .sort()
    expect(typesA).toEqual(typesB)
  })
})
