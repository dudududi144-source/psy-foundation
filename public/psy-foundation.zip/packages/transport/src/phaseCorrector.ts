/**
 * PhaseCorrector — reconciles predicted beat phase with observed beats.
 *
 * Given the transport's current `origin` (anchor) and a new observation, it
 * decides whether the transport is still "locked" (phase within tolerance) or
 * needs a relock (re-anchor the origin to the observation).
 *
 * One concern only: phase alignment. It does not change bpm (that's
 * BeatEstimator) and does not change confidence (that's ConfidenceTracker).
 *
 * Relock is the single operation that keeps transport honest: when reality
 * (an observation) disagrees with prediction by more than `relockWindow`, we
 * snap the origin to the observation and bump `revision`. This is how we
 * recover from drift, jitter spikes, and gaps.
 */

import type { AudioTime, MusicalTransport, TransportClockOptions } from './types.ts'

export interface PhaseCorrection {
  /** New origin after correction (may equal the old one if still locked). */
  origin: MusicalTransport['origin']
  /** Beat index implied by the observation (nearest integer). */
  observedBeatIndex: number
  /** Phase offset in beats, -0.5..0.5. 0 = perfectly aligned. */
  phaseOffsetBeats: number
  /** Phase offset in seconds. */
  phaseOffsetSec: number
  /** True if a relock happened (origin changed). */
  relocked: boolean
  /** True if the offset was small enough to stay locked. */
  withinWindow: boolean
}

export class PhaseCorrector {
  private readonly relockWindow: number
  private readonly correctionRate: number

  constructor(opts: Required<Pick<TransportClockOptions, 'relockWindow' | 'phaseCorrectionRate'>>) {
    this.relockWindow = opts.relockWindow
    this.correctionRate = opts.phaseCorrectionRate
  }

  /**
   * Evaluate an observation against the current origin.
   *
   * @param origin current anchor
   * @param bpm current smoothed bpm
   * @param observedAt audio time of the new observation
   */
  evaluate(
    origin: MusicalTransport['origin'],
    bpm: number,
    observedAt: AudioTime
  ): PhaseCorrection {
    const secPerBeat = 60 / bpm
    const elapsed = observedAt - origin.audioTime
    const predictedBeatIndex = origin.beatIndex + elapsed / secPerBeat
    const observedBeatIndex = Math.round(predictedBeatIndex)
    const phaseOffsetBeats = predictedBeatIndex - observedBeatIndex
    const phaseOffsetSec = phaseOffsetBeats * secPerBeat
    const withinWindow = Math.abs(phaseOffsetSec) <= this.relockWindow

    if (withinWindow) {
      // Stay locked. Optionally nudge the origin toward the observation by
      // `correctionRate` of the offset — gentle tracking without snapping.
      if (this.correctionRate > 0 && Math.abs(phaseOffsetSec) > 1e-6) {
        const nudge = phaseOffsetSec * this.correctionRate
        const nudgedOrigin = {
          audioTime: origin.audioTime + nudge,
          beatIndex: observedBeatIndex,
          bpm,
        }
        return {
          origin: nudgedOrigin,
          observedBeatIndex,
          phaseOffsetBeats: phaseOffsetBeats - nudge / secPerBeat,
          phaseOffsetSec: phaseOffsetSec - nudge,
          relocked: false,
          withinWindow: true,
        }
      }
      return {
        origin,
        observedBeatIndex,
        phaseOffsetBeats,
        phaseOffsetSec,
        relocked: false,
        withinWindow: true,
      }
    }

    // Relock: snap origin to the observation.
    const relockedOrigin = { audioTime: observedAt, beatIndex: observedBeatIndex, bpm }
    return {
      origin: relockedOrigin,
      observedBeatIndex,
      phaseOffsetBeats,
      phaseOffsetSec,
      relocked: true,
      withinWindow: false,
    }
  }
}
