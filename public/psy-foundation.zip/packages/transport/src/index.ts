/**
 * @psy-foundation/transport
 *
 * Musical time model for the PSY device family. Observer-fed transport:
 * `RADIO → OBSERVATION → ESTIMATION → MUSICAL TRANSPORT → LOCAL SCHEDULER → AUDIO`.
 *
 * The TransportClock is the single source of truth for beat/bar/phase/bpm.
 */

export type {
  AudioTime,
  BeatObservation,
  EstimatedBeatTime,
  MusicalTransport,
  ObservedBeatTime,
  PredictedBeatTime,
  TransportClockOptions,
} from './types.ts'

export { TransportClock } from './transport.ts'
export { BeatEstimator } from './beatEstimator.ts'
export type { BeatEstimateResult } from './beatEstimator.ts'
export { PhaseCorrector } from './phaseCorrector.ts'
export type { PhaseCorrection } from './phaseCorrector.ts'
export { ConfidenceTracker } from './confidenceTracker.ts'
