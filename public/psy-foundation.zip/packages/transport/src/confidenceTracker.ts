/**
 * ConfidenceTracker — how much should the transport trust itself right now?
 *
 * Confidence is a pure function of:
 *  - consistency of recent inter-onset intervals (low jitter → high);
 *  - recency of the last observation (stale → decays);
 *  - stability history (relocks and octave folds lower it).
 *
 * One concern only: confidence. Reads intervals from the outside (the
 * TransportClock passes them in) and never touches bpm or phase.
 */

import type { TransportClockOptions } from './types.ts'

const RING = 8 // intervals kept for jitter estimation

export class ConfidenceTracker {
  private confidence = 0
  private intervals: number[] = []
  private lastObservedAt: number | null = null
  private readonly gainPerObs: number
  private readonly decayPerSec: number

  constructor(
    opts: Required<Pick<TransportClockOptions, 'confidenceGainPerObs' | 'confidenceDecayPerSec'>>
  ) {
    this.gainPerObs = opts.confidenceGainPerObs
    this.decayPerSec = opts.confidenceDecayPerSec
  }

  get current(): number {
    return this.confidence
  }

  reset(): void {
    this.confidence = 0
    this.intervals = []
    this.lastObservedAt = null
  }

  /** Decay confidence based on elapsed audio time since the last snapshot read. */
  decay(now: number): void {
    if (this.lastObservedAt !== null) {
      const dt = Math.max(0, now - this.lastObservedAt)
      this.confidence = Math.max(0, this.confidence - this.decayPerSec * dt)
    }
  }

  /**
   * Account for a new observation.
   *
   * @param observedAt audio time of the observation
   * @param intervalSec inter-onset interval (already octave-folded) or null
   * @param relocked whether this observation caused a relock
   * @param folded whether the interval was octave-folded (ambiguity)
   */
  onObservation(
    observedAt: number,
    intervalSec: number | null,
    relocked: boolean,
    folded: 'none' | 'half' | 'double'
  ): void {
    let consistency = 1
    if (intervalSec !== null) {
      this.intervals.push(intervalSec)
      if (this.intervals.length > RING) this.intervals.shift()
      if (this.intervals.length >= 2) {
        const mean = this.intervals.reduce((a, b) => a + b, 0) / this.intervals.length
        if (mean > 1e-9) {
          let varSum = 0
          for (const v of this.intervals) varSum += (v - mean) * (v - mean)
          const stddev = Math.sqrt(varSum / this.intervals.length)
          // Normalized jitter: stddev/mean. 0 = perfect, 0.5+ = terrible.
          const normJitter = Math.min(1, stddev / mean / 0.5)
          consistency = 1 - normJitter
        }
      }
    }

    // Gain scaled by consistency; a jittery observation contributes little.
    this.confidence = Math.min(1, this.confidence + this.gainPerObs * consistency)

    // A relock means prediction was wrong — lower confidence.
    if (relocked) this.confidence *= 0.6
    // An octave fold means we resolved an ambiguity — small penalty.
    if (folded !== 'none') this.confidence *= 0.85

    this.lastObservedAt = observedAt
  }
}
