/**
 * BeatEstimator — tempo estimation from a stream of beat observations.
 *
 * Adapted from `psy4/src/lib/beatPLL.ts` (152 lines, pure-logic, the cleanest
 * piece of PSY timing code). Restructured to:
 *  - be a pure function of its input state + a new observation (no hidden state
 *    beyond what's on `this`);
 *  - expose octave-error folding explicitly (half/double-time handling);
 *  - emit a `revision` signal whenever the estimate changes non-trivially, so
 *    the TransportClock can bump its deterministic revision counter.
 *
 * What it is NOT: it does not own phase. Phase is reconciled by PhaseCorrector.
 * It does not own confidence. That is ConfidenceTracker's job. One concern only.
 */

import type { BeatObservation, TransportClockOptions } from './types.ts'

export interface BeatEstimateResult {
  /** New smoothed bpm. */
  bpm: number
  /** Inter-onset interval (seconds) used for this update, after octave folding. */
  intervalSec: number
  /** True if the interval was octave-folded (half/double ambiguity resolved). */
  folded: 'none' | 'half' | 'double'
  /** True if the bpm estimate moved enough to warrant a revision bump. */
  changed: boolean
}

export class BeatEstimator {
  private bpm: number
  private lastObservedAt: number | null = null
  private readonly minBpm: number
  private readonly maxBpm: number
  private readonly smoothing: number
  private readonly octaveTol: number

  constructor(
    opts: Required<
      Pick<
        TransportClockOptions,
        'initialBpm' | 'minBpm' | 'maxBpm' | 'tempoSmoothing' | 'octaveFoldTolerance'
      >
    >
  ) {
    this.bpm = opts.initialBpm
    this.minBpm = opts.minBpm
    this.maxBpm = opts.maxBpm
    this.smoothing = opts.tempoSmoothing
    this.octaveTol = opts.octaveFoldTolerance
  }

  get currentBpm(): number {
    return this.bpm
  }

  /** Reset to initial state (used on TransportClock.reset). */
  reset(initialBpm: number): void {
    this.bpm = initialBpm
    this.lastObservedAt = null
  }

  /**
   * Ingest a new observation and return the updated estimate.
   * Returns `null` if there is not enough data yet (first observation).
   */
  ingest(obs: BeatObservation): BeatEstimateResult | null {
    if (this.lastObservedAt === null) {
      this.lastObservedAt = obs.observedAt
      return null
    }

    let intervalSec = obs.observedAt - this.lastObservedAt
    this.lastObservedAt = obs.observedAt

    // Guard against non-monotonic or zero intervals.
    if (!(intervalSec > 0)) return null

    // Expected interval from current bpm.
    const expected = 60 / this.bpm

    // Octave-error folding: half-time (interval ~2x) or double-time (~0.5x).
    let folded: BeatEstimateResult['folded'] = 'none'
    const halfRatio = intervalSec / (expected * 2)
    const doubleRatio = expected / 2 / intervalSec
    if (Math.abs(halfRatio - 1) <= this.octaveTol && halfRatio > 0) {
      // Interval is ~2x expected → we likely missed a beat. Halve it.
      intervalSec /= 2
      folded = 'half'
    } else if (Math.abs(doubleRatio - 1) <= this.octaveTol && doubleRatio > 0) {
      // Interval is ~0.5x expected → likely a false/double trigger. Double it.
      intervalSec *= 2
      folded = 'double'
    }

    // Clamp interval to the legal bpm range before converting.
    const minInterval = 60 / this.maxBpm
    const maxInterval = 60 / this.minBpm
    const clamped = Math.min(maxInterval, Math.max(minInterval, intervalSec))

    const observedBpm = 60 / clamped
    const prevBpm = this.bpm
    this.bpm = prevBpm + (observedBpm - prevBpm) * this.smoothing

    // A change > 0.1 bpm counts as a revision-worthy change.
    const changed = Math.abs(this.bpm - prevBpm) > 0.1

    return { bpm: this.bpm, intervalSec: clamped, folded, changed }
  }
}
