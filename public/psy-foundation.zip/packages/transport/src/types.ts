/**
 * Musical transport — the time model for the entire PSY family.
 *
 * INVARIANTS (enforced by TransportClock):
 *  - Transport is OBSERVER-fed, never radio-clock-fed.
 *    `RADIO → OBSERVATION → ESTIMATION → MUSICAL TRANSPORT → LOCAL SCHEDULER → AUDIO`
 *  - `observedBeatTime`, `estimatedBeatTime`, `predictedBeatTime` are distinct
 *    quantities and never mix with `AudioContext.currentTime` without explicit
 *    latency compensation.
 *  - Transport is NOT an audio renderer. NOT a radio. NOT UI.
 *  - The TransportClock is the SINGLE SOURCE OF TRUTH for beat/bar/phase/bpm.
 *    Nothing else may own this state.
 *  - Determinism: given the same observation sequence and the same `atAudioTime`,
 *    `snapshot()` returns the same value. No `Date.now()`, no `Math.random()`
 *    in the hot path. Confidence decays as a pure function of audio-time delta.
 */

/** Audio-context time domain (seconds). Distinct from musical time. */
export type AudioTime = number

/** Raw timestamp of an observed beat, in audio-time seconds. */
export type ObservedBeatTime = number

/** Beat time after filtering / PLL. In musical seconds since beat 0. */
export type EstimatedBeatTime = number

/** Beat time extrapolated to a future audio time, for look-ahead scheduling. */
export type PredictedBeatTime = number

/**
 * A beat observation pushed into the transport by a radio / observer.
 * The transport NEVER pulls from the radio — observations are pushed in.
 */
export interface BeatObservation {
  /** Audio-context time (seconds) when the beat was observed. */
  observedAt: AudioTime
  /** Estimated strength / salience 0..1 (e.g. onset energy). */
  strength: number
  /** Optional source label for debugging (e.g. 'radio-kick', 'midi'). */
  source?: string
}

/**
 * Immutable snapshot of the musical transport at a given audio time.
 *
 * `revision` bumps on every correction (phase relock, tempo change, octave
 * fold, gap recovery) — this makes transport changes deterministic and
 * testable: a test can assert "revision went 0 → 1 → 1 → 2" without timing
 * flakiness.
 */
export interface MusicalTransport {
  /** Beats per minute. Smoothed estimate. */
  bpm: number
  /** Monotonically increasing beat index since transport start. */
  beat: number
  /** Bar index since transport start. */
  bar: number
  /** Time signature numerator (default 4). */
  beatsPerBar: number
  /** Musical seconds since beat 0 (estimated). */
  beatTime: EstimatedBeatTime
  /** Musical seconds since bar 0 (estimated). */
  barTime: number
  /** Phase within the current beat, 0..1. */
  phase: number
  /** Phase within the current bar, 0..1. */
  barPhase: number
  /** Confidence 0..1 — how sure the transport is about the current state. */
  confidence: number
  /** True when phase is locked to recent observations. */
  locked: boolean
  /** Bumps on every correction. Deterministic testing anchor. */
  revision: number
  /** Anchor point used for prediction: at this audio time, this beat index
   *  and this bpm held. Extrapolation = origin + (now - origin.audioTime) * bpm/60. */
  origin: {
    audioTime: AudioTime
    beatIndex: number
    bpm: number
  }
  /** Seconds since the last observation was received. Large => gap / unlocked. */
  lastObservationAgo: number
  /** Total observations received. */
  observationCount: number
}

/** Options for constructing a {@link TransportClock}. */
export interface TransportClockOptions {
  /** Time signature numerator. Default 4. */
  beatsPerBar?: number
  /** Initial bpm before any observation. Default 120 (unlocked). */
  initialBpm?: number
  /** Clamp bpm to [minBpm, maxBpm]. Default [60, 200]. */
  minBpm?: number
  maxBpm?: number
  /** Tempo smoothing factor 0..1 (0 = ignore new, 1 = snap). Default 0.3. */
  tempoSmoothing?: number
  /** Phase correction rate 0..1 on relock. Default 0.5. */
  phaseCorrectionRate?: number
  /** Max |observed - predicted| (seconds) still considered "locked". Default 0.08. */
  relockWindow?: number
  /** After this many seconds without an observation, mark unlocked. Default 2.0. */
  gapTimeout?: number
  /** Confidence decay per second without observation. Default 0.15. */
  confidenceDecayPerSec?: number
  /** Confidence gained per consistent observation. Default 0.25. */
  confidenceGainPerObs?: number
  /** Min observations before reporting "locked". Default 3. */
  lockMinObservations?: number
  /** Octave-fold threshold: if interval ratio within this of 2.0 or 0.5, fold. Default 0.08. */
  octaveFoldTolerance?: number
}
