/**
 * Fixture corpus types for the PSY foundation.
 *
 * A {@link Fixture} is a fully-synthetic, deterministic audio signal paired
 * with ground-truth beat annotations. The corpus is the canonical input that
 * transport, scheduler, analysis, and benchmark packages test against.
 *
 * INVARIANTS:
 *  - Every fixture is reproducible: same seed → byte-identical signal.
 *  - `signal` is mono Float32Array in [-1, 1], length ceil(durationSec * sampleRate).
 *  - `groundTruthBeats` are strictly increasing audio-context times in [0, durationSec].
 *  - `sampleRate` is always 44100 for the v0.1 corpus.
 */

export type Anomaly =
  | 'perfect'
  | 'jitter'
  | 'tempo-ramp'
  | 'tempo-jump'
  | 'missing-beat'
  | 'false-kick'
  | 'half-time'
  | 'double-time'
  | 'gap-500ms'
  | 'gap-2s'
  | 'sparse'
  | 'dense-bass'
  | 'lead-heavy'
  | 'breakdown'

export interface Fixture {
  /** Stable id, e.g. 'perfect-150'. */
  id: string
  /** Human name, e.g. '150 BPM perfect grid'. */
  name: string
  /** The anomaly category. */
  anomaly: Anomaly
  /** Sample rate of the signal (Hz). Use 44100. */
  sampleRate: number
  /** Duration in seconds. */
  durationSec: number
  /** Mono audio signal — synthetic kick-like transients at each ground-truth beat. Float32Array, -1..1. */
  signal: Float32Array
  /** Audio-context times (seconds) of each TRUE beat. The ground truth transport should recover. */
  groundTruthBeats: number[]
  /** The nominal bpm a perfect estimator would report. null for ramps/jumps. */
  groundTruthBpm: number | null
  /** Short description of what this fixture stresses. */
  description: string
}
