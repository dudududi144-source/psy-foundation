/**
 * Deterministic mulberry32 PRNG.
 *
 * Returns a function that produces uniformly-distributed floats in [0, 1).
 * Used by fixture generators that need reproducible jitter — never Math.random.
 *
 * Reference: https://gist.github.com/tommyettinger/46da36198ab3ed10c5bfe6461a4844c5
 */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
