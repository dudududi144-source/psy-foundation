/**
 * The canonical fixture corpus.
 *
 * Built once at module load from the pure generator functions in
 * {@link ./generators}. Downstream packages (transport, scheduler, analysis,
 * benchmark) import `corpus` to get a stable, deterministic set of test inputs.
 */

import {
  generateBreakdown,
  generateDenseBass,
  generateDoubleTime,
  generateFalseKick,
  generateGap2s,
  generateGap500ms,
  generateHalfTime,
  generateJitter150,
  generateLeadHeavy,
  generateMissingBeat,
  generatePerfect150,
  generateSparse,
  generateTempoJump,
  generateTempoRamp,
} from './generators'
import type { Fixture } from './types'

export const corpus: Fixture[] = [
  generatePerfect150(),
  generateJitter150(),
  generateTempoRamp(),
  generateTempoJump(),
  generateMissingBeat(),
  generateFalseKick(),
  generateHalfTime(),
  generateDoubleTime(),
  generateGap500ms(),
  generateGap2s(),
  generateSparse(),
  generateDenseBass(),
  generateLeadHeavy(),
  generateBreakdown(),
]

/** Look up a fixture by stable id. Throws if not found. */
export function getFixture(id: string): Fixture {
  const f = corpus.find((x) => x.id === id)
  if (!f) throw new Error(`Fixture not found: ${id}`)
  return f
}
