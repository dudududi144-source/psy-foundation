/**
 * Synthetic kick-drum transient renderer.
 *
 * Writes a short (~60ms) decaying 50Hz sine burst with a 1ms attack into the
 * target signal buffer at sample floor(at * sampleRate). The burst is sharp
 * enough for onset detection and short enough not to bleed into the next beat
 * at typical psytrance tempos (>= 130 BPM → >= 0.46s between beats).
 *
 * Samples are ADDED to the existing buffer (not overwritten) so that dense-bass,
 * lead-heavy, and breakdown fixtures can layer sustained tones underneath kicks.
 */

const KICK_DURATION_SEC = 0.06
const KICK_FREQ_HZ = 50
const KICK_ATTACK_SEC = 0.001
const TWO_PI = Math.PI * 2

export function synthesizeKick(
  at: number,
  sampleRate: number,
  signal: Float32Array,
  gain = 1
): void {
  const startSample = Math.floor(at * sampleRate)
  const length = Math.floor(KICK_DURATION_SEC * sampleRate)
  for (let i = 0; i < length; i++) {
    const idx = startSample + i
    if (idx < 0 || idx >= signal.length) continue
    const t = i / sampleRate
    const attack = t < KICK_ATTACK_SEC ? t / KICK_ATTACK_SEC : 1
    const decay = Math.exp(-t * 35)
    const env = attack * decay * gain
    const sample = Math.sin(TWO_PI * KICK_FREQ_HZ * t) * env
    signal[idx] = (signal[idx] ?? 0) + sample
  }
}
