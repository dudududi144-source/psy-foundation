/**
 * @psy-foundation/fixtures — synthetic radio corpus.
 *
 * Public API:
 *  - {@link Anomaly}, {@link Fixture}  types
 *  - {@link corpus}                    all 14 fixtures
 *  - {@link getFixture}                id → Fixture lookup (throws if missing)
 *  - {@link mulberry32}                deterministic PRNG
 *  - {@link synthesizeKick}            kick transient renderer
 *  - the 14 `generate*` functions      one per fixture (pure, deterministic)
 */

export type { Anomaly, Fixture } from './types'
export { mulberry32 } from './rng'
export { synthesizeKick } from './kick'
export { corpus, getFixture } from './corpus'
export {
  generateBreakdown,
  generateDenseBass,
  generateDoubleTime,
  generateFalseKick,
  generateGap2s,
  generateGap500ms,
  generateHalfTime,
  generateJitter150,
  generateLeadHeavy,
  generateMissingBeat,
  generatePerfect150,
  generateSparse,
  generateTempoJump,
  generateTempoRamp,
} from './generators'
