/**
 * Fixture generators — one pure function per corpus entry.
 *
 * Every generator is deterministic: the only source of pseudo-randomness is
 * the seeded {@link mulberry32} RNG. No `Math.random`, no `Date.now`, no
 * ambient state. Calling a generator twice (with the same seed) produces a
 * byte-identical signal.
 *
 * All fixtures use sampleRate = 44100 and a 4/4 grid. Kick onsets are rendered
 * via {@link synthesizeKick}. Sustained tones (bass, lead, pad) are rendered
 * via {@link addSustainedTone} and layered additively.
 */

import { synthesizeKick } from './kick'
import { mulberry32 } from './rng'
import type { Fixture } from './types'

const SAMPLE_RATE = 44100
const TWO_PI = Math.PI * 2

/** Allocate a zero-filled mono signal buffer of the right length for `durationSec`. */
function makeSignal(durationSec: number): Float32Array {
  return new Float32Array(Math.ceil(durationSec * SAMPLE_RATE))
}

/** Hard-clamp a signal into [-1, 1] in place. Guarantees the Fixture contract. */
function clampSignal(signal: Float32Array): void {
  for (let i = 0; i < signal.length; i++) {
    const v = signal[i] ?? 0
    if (v > 1) signal[i] = 1
    else if (v < -1) signal[i] = -1
  }
}

/** Return the last element of `beats`, or 0 if empty. */
function lastOf(beats: number[]): number {
  return beats[beats.length - 1] ?? 0
}

/** Round `lastBeat` up to the next whole second + 0.5s headroom for the kick tail. */
function durationFromLastBeat(lastBeat: number): number {
  return Math.ceil(lastBeat + 0.5)
}

/**
 * Add a sustained sine tone with a 50ms attack and 200ms release into `signal`.
 * Used for basslines, lead pads, and breakdown ambience — layered additively.
 */
function addSustainedTone(
  signal: Float32Array,
  startSec: number,
  endSec: number,
  freq: number,
  gain: number
): void {
  const startSample = Math.floor(startSec * SAMPLE_RATE)
  const endSample = Math.min(signal.length, Math.floor(endSec * SAMPLE_RATE))
  const attackSec = 0.05
  const releaseSec = 0.2
  for (let i = startSample; i < endSample; i++) {
    const t = (i - startSample) / SAMPLE_RATE
    const timeFromEnd = (endSample - i) / SAMPLE_RATE
    const attack = Math.min(1, t / attackSec)
    const release = Math.min(1, timeFromEnd / releaseSec)
    const env = attack * release * gain
    const sample = Math.sin(TWO_PI * freq * t) * env
    signal[i] = (signal[i] ?? 0) + sample
  }
}

// ---------------------------------------------------------------------------
// perfect-150
// ---------------------------------------------------------------------------

export function generatePerfect150(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64 // 16 bars * 4
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval // 25.6
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'perfect-150',
    name: '150 BPM perfect grid',
    anomaly: 'perfect',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description: '16 bars of perfectly regular 150 BPM kicks — the baseline corpus entry.',
  }
}

// ---------------------------------------------------------------------------
// jitter-150
// ---------------------------------------------------------------------------

export function generateJitter150(seed = 42): Fixture {
  const rng = mulberry32(seed)
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats: number[] = [0]
  for (let i = 1; i < beatCount; i++) {
    const jitter = (rng() - 0.5) * 0.02 // ±10ms deterministic
    beats.push(i * interval + jitter)
  }
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'jitter-150',
    name: '150 BPM with ±10ms jitter',
    anomaly: 'jitter',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description: '150 BPM grid with deterministic ±10ms timing jitter per beat.',
  }
}

// ---------------------------------------------------------------------------
// tempo-ramp  (130 → 170 BPM over ~20s)
// ---------------------------------------------------------------------------

export function generateTempoRamp(): Fixture {
  const bpmStart = 130
  const bpmEnd = 170
  const rampSec = 20
  const beats: number[] = [0]
  let t = 0
  // Integrate: each step uses the instantaneous bpm at the current beat time.
  // bpm(t) = bpmStart + (bpmEnd - bpmStart) * (t / rampSec), strictly increasing,
  // so each interval (60 / bpm(t)) is strictly smaller than the previous.
  for (;;) {
    const bpm = bpmStart + (bpmEnd - bpmStart) * (t / rampSec)
    const interval = 60 / bpm
    const next = t + interval
    if (next > rampSec) break
    beats.push(next)
    t = next
  }
  const durationSec = durationFromLastBeat(lastOf(beats))
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'tempo-ramp',
    name: 'Tempo ramp 130→170 BPM over 20s',
    anomaly: 'tempo-ramp',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: null,
    description:
      'Linear tempo ramp from 130 to 170 BPM over 20 seconds; beats get progressively closer.',
  }
}

// ---------------------------------------------------------------------------
// tempo-jump  (130 BPM × 8 bars, then instant 160 BPM × 8 bars)
// ---------------------------------------------------------------------------

export function generateTempoJump(): Fixture {
  const bpm1 = 130
  const bpm2 = 160
  const interval1 = 60 / bpm1
  const interval2 = 60 / bpm2
  const beatsPerSection = 32 // 8 bars * 4
  const beats: number[] = []
  for (let i = 0; i < beatsPerSection; i++) beats.push(i * interval1)
  const section1End = beatsPerSection * interval1
  for (let i = 0; i < beatsPerSection; i++) beats.push(section1End + i * interval2)
  const durationSec = durationFromLastBeat(lastOf(beats))
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'tempo-jump',
    name: 'Tempo jump 130→160 BPM',
    anomaly: 'tempo-jump',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: null,
    description: '130 BPM for 8 bars, then an instant jump to 160 BPM for 8 bars.',
  }
}

// ---------------------------------------------------------------------------
// missing-beat  (beat 32 removed → one 2x interval)
// ---------------------------------------------------------------------------

export function generateMissingBeat(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats: number[] = []
  for (let i = 0; i < beatCount; i++) {
    if (i === 32) continue // remove the downbeat of bar 9
    beats.push(i * interval)
  }
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'missing-beat',
    name: '150 BPM with beat 32 missing',
    anomaly: 'missing-beat',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description: '150 BPM grid with beat 32 (bar 9 downbeat) removed, creating one 2x interval.',
  }
}

// ---------------------------------------------------------------------------
// false-kick  (low-strength extra kick between beats 40 and 41)
// ---------------------------------------------------------------------------

export function generateFalseKick(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  // False kick exactly midway between beats 40 and 41, rendered at low gain.
  const falseKickAt = (40 * interval + 41 * interval) / 2
  synthesizeKick(falseKickAt, SAMPLE_RATE, signal, 0.4)
  return {
    id: 'false-kick',
    name: '150 BPM with false low-strength kick',
    anomaly: 'false-kick',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description: '150 BPM grid with a low-strength extra kick inserted between beats 40 and 41.',
  }
}

// ---------------------------------------------------------------------------
// half-time  (alternating accent: even beats strong, odd beats weak)
// ---------------------------------------------------------------------------

export function generateHalfTime(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  for (let i = 0; i < beats.length; i++) {
    const gain = i % 2 === 0 ? 1.0 : 0.5
    synthesizeKick(beats[i] ?? 0, SAMPLE_RATE, signal, gain)
  }
  return {
    id: 'half-time',
    name: '150 BPM with alternating accent pattern',
    anomaly: 'half-time',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM grid with every other beat weaker — tempts a half-time lock; true bpm is 150.',
  }
}

// ---------------------------------------------------------------------------
// double-time  (75 BPM strong kicks + quiet ghost kicks halfway between)
// ---------------------------------------------------------------------------

export function generateDoubleTime(): Fixture {
  const bpm = 75
  const interval = 60 / bpm
  const beatCount = 64
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval // 51.2
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal, 1.0)
  for (let i = 0; i < beatCount - 1; i++) {
    const ghostAt = (beats[i] ?? 0) + interval / 2
    synthesizeKick(ghostAt, SAMPLE_RATE, signal, 0.4)
  }
  return {
    id: 'double-time',
    name: '75 BPM with ghost kicks',
    anomaly: 'double-time',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '75 BPM strong kicks with quiet ghost kicks halfway between — tempts a double-time lock.',
  }
}

// ---------------------------------------------------------------------------
// gap-500ms  (500ms silence after beat 24, shorter than typical gapTimeout)
// ---------------------------------------------------------------------------

export function generateGap500ms(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const gapAfter = 24
  const gapSec = 0.5
  const beats: number[] = []
  let t = 0
  for (let i = 0; i < beatCount; i++) {
    beats.push(t)
    t += i === gapAfter ? gapSec : interval
  }
  const durationSec = durationFromLastBeat(lastOf(beats))
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'gap-500ms',
    name: '150 BPM with 500ms gap after beat 24',
    anomaly: 'gap-500ms',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM grid with a 500ms silence after beat 24 — shorter than the typical gapTimeout.',
  }
}

// ---------------------------------------------------------------------------
// gap-2s  (2-second silence after beat 24, exceeds typical gapTimeout=2.0)
// ---------------------------------------------------------------------------

export function generateGap2s(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const gapAfter = 24
  const gapSec = 2.0
  const beats: number[] = []
  let t = 0
  for (let i = 0; i < beatCount; i++) {
    beats.push(t)
    t += i === gapAfter ? gapSec : interval
  }
  const durationSec = durationFromLastBeat(lastOf(beats))
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'gap-2s',
    name: '150 BPM with 2s gap after beat 24',
    anomaly: 'gap-2s',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM grid with a 2-second silence after beat 24 — exceeds the typical gapTimeout.',
  }
}

// ---------------------------------------------------------------------------
// sparse  (kicks only on beats 1 and 3 of each bar)
// ---------------------------------------------------------------------------

export function generateSparse(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats: number[] = []
  for (let i = 0; i < beatCount; i++) {
    const withinBar = i % 4
    if (withinBar === 0 || withinBar === 2) beats.push(i * interval)
  }
  const durationSec = beatCount * interval // full 16-bar duration
  const signal = makeSignal(durationSec)
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  return {
    id: 'sparse',
    name: '150 BPM sparse (beats 1 and 3 only)',
    anomaly: 'sparse',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM grid with kicks only on beats 1 and 3 of each bar — tests sparse-observation recovery.',
  }
}

// ---------------------------------------------------------------------------
// dense-bass  (150 BPM kicks + continuous bass and sub-bass tones)
// ---------------------------------------------------------------------------

export function generateDenseBass(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  addSustainedTone(signal, 0, durationSec, 82.41, 0.2) // E2 bass
  addSustainedTone(signal, 0, durationSec, 41.0, 0.15) // E1 sub-bass
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  clampSignal(signal)
  return {
    id: 'dense-bass',
    name: '150 BPM with continuous dense bass',
    anomaly: 'dense-bass',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM kicks plus continuous bass and sub-bass tones — tests onset detection through low-frequency energy.',
  }
}

// ---------------------------------------------------------------------------
// lead-heavy  (150 BPM kicks + sustained lead chord)
// ---------------------------------------------------------------------------

export function generateLeadHeavy(): Fixture {
  const bpm = 150
  const interval = 60 / bpm
  const beatCount = 64
  const beats = Array.from({ length: beatCount }, (_, i) => i * interval)
  const durationSec = beatCount * interval
  const signal = makeSignal(durationSec)
  addSustainedTone(signal, 0, durationSec, 440.0, 0.1) // A4
  addSustainedTone(signal, 0, durationSec, 554.37, 0.1) // C#5
  addSustainedTone(signal, 0, durationSec, 659.25, 0.1) // E5
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  clampSignal(signal)
  return {
    id: 'lead-heavy',
    name: '150 BPM with sustained lead chord',
    anomaly: 'lead-heavy',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '150 BPM kicks plus a sustained A-major lead chord — tests onset detection through sustained high-frequency energy.',
  }
}

// ---------------------------------------------------------------------------
// breakdown  (140 BPM: bars 1-4 kicks, 5-8 pad only, 9-16 kicks return)
// ---------------------------------------------------------------------------

export function generateBreakdown(): Fixture {
  const bpm = 140
  const interval = 60 / bpm
  const beatCount = 64
  const beats: number[] = []
  for (let i = 0; i < beatCount; i++) {
    if (i >= 16 && i < 32) continue // breakdown: bars 5-8, no kicks
    beats.push(i * interval)
  }
  const durationSec = durationFromLastBeat(lastOf(beats))
  const signal = makeSignal(durationSec)
  // Ambient A-minor pad during the breakdown bars (beats 16..32).
  const padStart = 16 * interval
  const padEnd = 32 * interval
  addSustainedTone(signal, padStart, padEnd, 220.0, 0.08) // A3
  addSustainedTone(signal, padStart, padEnd, 261.63, 0.08) // C4
  addSustainedTone(signal, padStart, padEnd, 329.63, 0.08) // E4
  for (const b of beats) synthesizeKick(b, SAMPLE_RATE, signal)
  clampSignal(signal)
  return {
    id: 'breakdown',
    name: '140 BPM with 4-bar breakdown',
    anomaly: 'breakdown',
    sampleRate: SAMPLE_RATE,
    durationSec,
    signal,
    groundTruthBeats: beats,
    groundTruthBpm: bpm,
    description:
      '140 BPM: bars 1-4 kicks, bars 5-8 breakdown (pad only), bars 9-16 kicks return — tests gap recovery and relock.',
  }
}
