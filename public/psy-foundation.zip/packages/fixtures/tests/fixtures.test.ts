import { describe, expect, test } from 'bun:test'
import { corpus, getFixture } from '../src/corpus'
import * as gen from '../src/generators'
import type { Fixture } from '../src/types'

/** Compute inter-beat intervals from a beat list. */
function intervals(beats: number[]): number[] {
  const out: number[] = []
  for (let i = 1; i < beats.length; i++) {
    out.push((beats[i] ?? 0) - (beats[i - 1] ?? 0))
  }
  return out
}

/** All 14 generator functions, wrapped to take no args for uniform determinism checks. */
const GENERATORS: Array<() => Fixture> = [
  gen.generatePerfect150,
  gen.generateJitter150,
  gen.generateTempoRamp,
  gen.generateTempoJump,
  gen.generateMissingBeat,
  gen.generateFalseKick,
  gen.generateHalfTime,
  gen.generateDoubleTime,
  gen.generateGap500ms,
  gen.generateGap2s,
  gen.generateSparse,
  gen.generateDenseBass,
  gen.generateLeadHeavy,
  gen.generateBreakdown,
]

describe('fixtures corpus', () => {
  test('has exactly 14 fixtures with unique ids', () => {
    expect(corpus).toHaveLength(14)
    const ids = corpus.map((f) => f.id)
    expect(new Set(ids).size).toBe(14)
    const expected = [
      'perfect-150',
      'jitter-150',
      'tempo-ramp',
      'tempo-jump',
      'missing-beat',
      'false-kick',
      'half-time',
      'double-time',
      'gap-500ms',
      'gap-2s',
      'sparse',
      'dense-bass',
      'lead-heavy',
      'breakdown',
    ]
    expect(ids).toEqual(expected)
  })

  test('every signal length matches ceil(durationSec * sampleRate)', () => {
    for (const f of corpus) {
      expect(f.signal.length).toBe(Math.ceil(f.durationSec * f.sampleRate))
    }
  })

  test('every groundTruthBeats is monotonically increasing and within [0, durationSec]', () => {
    for (const f of corpus) {
      expect(f.groundTruthBeats.length).toBeGreaterThan(0)
      for (let i = 0; i < f.groundTruthBeats.length; i++) {
        const b = f.groundTruthBeats[i] ?? 0
        expect(b).toBeGreaterThanOrEqual(0)
        expect(b).toBeLessThanOrEqual(f.durationSec)
        if (i > 0) {
          const prev = f.groundTruthBeats[i - 1] ?? 0
          expect(b).toBeGreaterThan(prev)
        }
      }
    }
  })

  test('perfect-150 inter-beat intervals are all within 1ms of 60/150', () => {
    const f = getFixture('perfect-150')
    const target = 60 / 150
    for (const d of intervals(f.groundTruthBeats)) {
      expect(Math.abs(d - target)).toBeLessThan(0.001)
    }
  })

  test('missing-beat has exactly one interval ~2x the others', () => {
    const f = getFixture('missing-beat')
    const iv = intervals(f.groundTruthBeats)
    const base = 60 / 150
    const doubled = iv.filter((x) => Math.abs(x - 2 * base) < 0.01)
    const normal = iv.filter((x) => Math.abs(x - base) < 0.01)
    expect(doubled).toHaveLength(1)
    expect(normal).toHaveLength(iv.length - 1)
  })

  test('tempo-ramp intervals are strictly decreasing', () => {
    const f = getFixture('tempo-ramp')
    const iv = intervals(f.groundTruthBeats)
    expect(iv.length).toBeGreaterThan(1)
    for (let i = 1; i < iv.length; i++) {
      expect(iv[i] ?? 0).toBeLessThan(iv[i - 1] ?? 0)
    }
  })

  test('tempo-jump has exactly one discontinuous interval change', () => {
    const f = getFixture('tempo-jump')
    const iv = intervals(f.groundTruthBeats)
    let jumps = 0
    for (let i = 1; i < iv.length; i++) {
      if (Math.abs((iv[i] ?? 0) - (iv[i - 1] ?? 0)) > 0.05) jumps++
    }
    expect(jumps).toBe(1)
  })

  test('breakdown has a gap in beats during the breakdown bars', () => {
    const f = getFixture('breakdown')
    const iv = intervals(f.groundTruthBeats)
    const base = 60 / 140
    const gaps = iv.filter((x) => x > base * 3)
    expect(gaps.length).toBeGreaterThanOrEqual(1)
    const maxGap = Math.max(...iv)
    expect(maxGap).toBeGreaterThan(base * 5)
  })

  test('determinism: calling any generator twice yields byte-identical signals', () => {
    for (const g of GENERATORS) {
      const a = g()
      const b = g()
      expect(a.signal.length).toBe(b.signal.length)
      const bufA = Buffer.from(a.signal.buffer, a.signal.byteOffset, a.signal.byteLength)
      const bufB = Buffer.from(b.signal.buffer, b.signal.byteOffset, b.signal.byteLength)
      expect(bufA.equals(bufB)).toBe(true)
    }
  })

  test("getFixture('perfect-150') returns the perfect fixture; nonexistent throws", () => {
    const f = getFixture('perfect-150')
    expect(f.id).toBe('perfect-150')
    expect(f.anomaly).toBe('perfect')
    expect(f.groundTruthBpm).toBe(150)
    expect(() => getFixture('nonexistent')).toThrow()
  })
})
