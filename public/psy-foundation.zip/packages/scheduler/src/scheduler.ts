/**
 * Scheduler — converts a {@link MusicalPlan} into {@link ScheduledEvent}[]
 * aligned to a {@link MusicalTransport}'s beat grid.
 *
 * Pure function. No side effects. No wall-clock. No randomness except through
 * the injected seed (deterministic). The scheduler does not know about:
 *   - React / UI
 *   - radio / beat observation
 *   - presets / sound banks
 *   - specific synth implementations
 *   - AudioContext (it emits audio-TIME values, not audio nodes)
 *
 * What it DOES know:
 *   - the transport's bpm and origin (to convert bars → audio seconds)
 *   - the plan's tracks and steps
 *   - swing, humanize, probability (all deterministic)
 *
 * Determinism proof: `schedule(plan, opts)` with the same inputs returns the
 * same output. Two runs → byte-identical event arrays. Tested explicitly.
 */

import type { AudioTime } from '@psy-foundation/transport'
import { Rng } from './rng.ts'
import type {
  MusicalPlan,
  PatternStep,
  PatternTrack,
  ScheduledEvent,
  SchedulerOptions,
} from './types.ts'

const DEFAULT_OPTS: Required<Omit<SchedulerOptions, 'originAudioTime' | 'bpm'>> = {
  beatsPerBar: 4,
  swing: 0,
  humanizeSec: 0,
  seed: 1,
}

/**
 * Schedule a plan against a transport grid.
 *
 * @returns a flat, time-sorted list of ScheduledEvent.
 */
export function schedule(plan: MusicalPlan, opts: SchedulerOptions): ScheduledEvent[] {
  const o = { ...DEFAULT_OPTS, ...opts }
  const rng = new Rng(o.seed)
  const secPerBeat = 60 / o.bpm
  const secPerBar = secPerBeat * o.beatsPerBar
  const events: ScheduledEvent[] = []

  for (let barOffset = 0; barOffset < plan.barCount; barOffset++) {
    const barIndex = plan.fromBar + barOffset
    const barAudioTime: AudioTime = o.originAudioTime + barIndex * secPerBar

    for (const track of plan.tracks) {
      scheduleTrack(track, barIndex, barAudioTime, secPerBeat, o, rng, events)
    }
  }

  // Stable sort by `at` (preserves track order within the same time).
  events.sort((a, b) => a.at - b.at)
  return events
}

function scheduleTrack(
  track: PatternTrack,
  _barIndex: number,
  barAudioTime: AudioTime,
  secPerBeat: number,
  opts: Required<Omit<SchedulerOptions, 'originAudioTime' | 'bpm'>>,
  rng: Rng,
  out: ScheduledEvent[]
): void {
  const steps = track.steps
  const len = steps.length
  if (len === 0) return

  // Per-step duration in beats: depends on how many steps fit in a bar.
  // We assume one bar = len steps (step sequencer convention). If the track
  // has a different length than beatsPerBar * resolution, it loops within
  // the bar — the caller controls resolution by choosing step count.
  const stepBeats = opts.beatsPerBar / len

  for (let i = 0; i < len; i++) {
    const step = steps[i]
    if (!step) continue
    if (!step.on) continue

    // Probability gate (deterministic via rng).
    if (step.prob < 1 && rng.next() > step.prob) continue

    // Swing: delay odd 16th-style steps. Apply to every other step.
    let swingOffsetBeats = 0
    if (opts.swing > 0 && i % 2 === 1) {
      swingOffsetBeats = opts.swing * stepBeats
    }

    // Micro-timing + swing.
    const offsetBeats = i * stepBeats + step.micro + swingOffsetBeats
    let at = barAudioTime + offsetBeats * secPerBeat

    // Deterministic humanize.
    if (opts.humanizeSec > 0) {
      at += (rng.next() * 2 - 1) * opts.humanizeSec
    }

    const note = step.note > 0 ? step.note : track.defaultNote
    const velocity = step.vel
    const duration = track.durationBeats * secPerBeat

    out.push({
      type: 'note',
      at,
      note,
      velocity,
      duration,
      channel: track.role,
    })

    // Per-step parameter locks → param events at the same time.
    if (step.lock) {
      for (const [param, value] of Object.entries(step.lock)) {
        out.push({
          type: 'param',
          at,
          channel: track.role,
          param,
          value,
          rampSec: 0.005,
        })
      }
    }
  }
}

/** Convenience: convert a bar index + beat offset to an audio time. */
export function barBeatToAudioTime(
  originAudioTime: AudioTime,
  bpm: number,
  beatsPerBar: number,
  bar: number,
  beatInBar: number
): AudioTime {
  const secPerBeat = 60 / bpm
  return originAudioTime + (bar * beatsPerBar + beatInBar) * secPerBeat
}

/** Convenience: build a step. */
export function step(partial: Partial<PatternStep> = {}): PatternStep {
  return {
    on: partial.on ?? false,
    vel: partial.vel ?? 1,
    prob: partial.prob ?? 1,
    micro: partial.micro ?? 0,
    note: partial.note ?? 0,
    lock: partial.lock,
  }
}

/** Convenience: build a track of N empty steps. */
export function emptyTrack(
  id: string,
  role: string,
  defaultNote: number,
  stepCount: number,
  durationBeats = 0.5
): PatternTrack {
  const steps: PatternStep[] = Array.from({ length: stepCount }, () => step())
  return { id, role, defaultNote, durationBeats, steps }
}
