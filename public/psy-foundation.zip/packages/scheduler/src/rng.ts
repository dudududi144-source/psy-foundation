/**
 * Deterministic RNG for the scheduler.
 *
 * mulberry32 — same algorithm as packages/fixtures/src/rng.ts. Duplicated
 * intentionally to keep the scheduler dependency-free (it must not depend on
 * the fixtures package — that would invert the dependency direction). If we
 * ever extract a shared @psy-foundation/rng package, both can import from it.
 */

export class Rng {
  private state: number

  constructor(seed: number) {
    // Coerce to uint32.
    this.state = seed >>> 0
  }

  /** Next float in [0, 1). */
  next(): number {
    this.state = (this.state + 0x6d2b79f5) >>> 0
    let t = this.state
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }

  /** Float in [min, max). */
  range(min: number, max: number): number {
    return min + this.next() * (max - min)
  }
}
