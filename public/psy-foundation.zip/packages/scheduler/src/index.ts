/**
 * @psy-foundation/scheduler
 *
 * Deterministic musical scheduler. Converts a MusicalPlan into ScheduledEvent[]
 * aligned to a MusicalTransport beat grid. Pure function — no React, no radio,
 * no presets, no synth. The scheduler only emits intent in audio-time.
 */

export type {
  MusicalPlan,
  PatternStep,
  PatternTrack,
  ScheduledEvent,
  ScheduledNote,
  SchedulerOptions,
} from './types.ts'
export { schedule, barBeatToAudioTime, step, emptyTrack } from './scheduler.ts'
export { Rng } from './rng.ts'
