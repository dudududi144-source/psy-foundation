/**
 * Scheduler types.
 *
 * The scheduler takes a {@link MusicalTransport} snapshot + a {@link MusicalPlan}
 * and produces {@link ScheduledEvent}[] in audio-time. It is the bridge between
 * the abstract time model and the concrete "what should sound when".
 *
 * Determinism contract: given the same (transport, plan, options), `schedule()`
 * returns the SAME event list. No wall-clock, no randomness, no side effects.
 * The scheduler is a pure function. Audio renderers consume its output.
 */

import type { AudioTime } from '@psy-foundation/transport'

/**
 * A single note to be played at a future audio time.
 * The scheduler does not know what synth will render it — it only emits the
 * intent. A device/audio-renderer picks it up and turns it into sound.
 */
export interface ScheduledNote {
  /** Audio-context time (seconds) at which the note should start. */
  at: AudioTime
  /** MIDI note number. */
  note: number
  /** 0..1 velocity. */
  velocity: number
  /** Duration in seconds. */
  duration: number
  /** Logical channel / track id (matched against device capabilities.roles). */
  channel: string
}

/** Any scheduled musical intent. Today: notes. Future: parameter ramps, etc. */
export type ScheduledEvent =
  | ({ type: 'note' } & ScheduledNote)
  | { type: 'param'; at: AudioTime; channel: string; param: string; value: number; rampSec: number }

/**
 * A step in a pattern. Mirrors the psy5 step schema (verified working in M1
 * audit) but transport-agnostic: the scheduler converts steps into scheduled
 * notes using the transport's beat grid.
 */
export interface PatternStep {
  /** Is this step active? */
  on: boolean
  /** 0..1 velocity override (1 = full). */
  vel: number
  /** 0..1 probability of triggering (1 = always). */
  prob: number
  /** Micro-timing offset in beats (-0.5..0.5). */
  micro: number
  /** MIDI note override (0 = use track default). */
  note: number
  /** Per-step parameter locks (e.g. { cutoff: 0.8 }). */
  lock?: Record<string, number>
}

/** A track in a pattern: a stream of steps + a default note. */
export interface PatternTrack {
  id: string
  /** Role this track fills (e.g. 'kick', 'bass', 'lead'). */
  role: string
  /** Default MIDI note when step.note === 0. */
  defaultNote: number
  /** Default note duration in beats. */
  durationBeats: number
  /** Steps. Length may differ from other tracks (polyrhythm support). */
  steps: PatternStep[]
}

/**
 * A musical plan: the input to the scheduler.
 *
 * A plan is a snapshot of "what we intend to play". It contains patterns per
 * track, plus the bar range to schedule. The scheduler does NOT own the plan
 * — something upstream (a composer, a sequencer UI, a learning policy) does.
 */
export interface MusicalPlan {
  /** Tracks to schedule. */
  tracks: PatternTrack[]
  /** Bar index to start scheduling at (inclusive). */
  fromBar: number
  /** Number of bars to schedule. */
  barCount: number
}

export interface SchedulerOptions {
  /** Beats per bar (must match the transport's beatsPerBar). Default 4. */
  beatsPerBar?: number
  /** Master swing amount 0..0.5 (0 = straight, 0.5 = triplet feel). Default 0. */
  swing?: number
  /** Humanize amount in seconds (0 = none). Applied per-note, deterministic. Default 0. */
  humanizeSec?: number
  /** Seed for deterministic humanize / probability. Default 1. */
  seed?: number
  /** Audio-time anchor: the transport's origin audio time for `fromBar`. */
  originAudioTime: AudioTime
  /** Bpm to schedule with (usually transport.bpm). */
  bpm: number
}
