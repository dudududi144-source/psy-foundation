import { describe, expect, test } from 'bun:test'
import { emptyTrack, schedule, step } from '../src/index.ts'
import type { MusicalPlan } from '../src/index.ts'

function kickTrack(): ReturnType<typeof emptyTrack> {
  const t = emptyTrack('kick', 'kick', 36, 16, 0.5)
  // Kick on every beat (steps 0, 4, 8, 12 in a 16-step bar).
  for (const i of [0, 4, 8, 12]) t.steps[i] = step({ on: true, vel: 1 })
  return t
}

function bassTrack(): ReturnType<typeof emptyTrack> {
  const t = emptyTrack('bass', 'bass', 43, 16, 0.25)
  // Bass on every off-beat (steps 2, 6, 10, 14).
  for (const i of [2, 6, 10, 14]) t.steps[i] = step({ on: true, vel: 0.8 })
  return t
}

function plan(barCount = 1): MusicalPlan {
  return { tracks: [kickTrack(), bassTrack()], fromBar: 0, barCount }
}

const opts = { originAudioTime: 0, bpm: 150, beatsPerBar: 4 }

describe('schedule — basic', () => {
  test('emits one event per active step', () => {
    const evs = schedule(plan(), opts)
    // 4 kicks + 4 bass = 8 events
    expect(evs).toHaveLength(8)
  })

  test('events are sorted by audio time', () => {
    const evs = schedule(plan(), opts)
    for (let i = 1; i < evs.length; i++) {
      expect(evs[i].at).toBeGreaterThanOrEqual(evs[i - 1].at)
    }
  })

  test('kick lands on beat 0 (audio time 0)', () => {
    const evs = schedule(plan(), opts)
    const firstKick = evs.find((e) => e.type === 'note' && e.channel === 'kick')
    expect(firstKick).toBeDefined()
    expect(firstKick?.at).toBeCloseTo(0, 6)
  })

  test('bass lands on beat 0.5 (audio time 0.2 at 150bpm)', () => {
    const evs = schedule(plan(), opts)
    const firstBass = evs.find((e) => e.type === 'note' && e.channel === 'bass')
    expect(firstBass).toBeDefined()
    // 0.5 beat * 0.4 sec/beat = 0.2s
    expect(firstBass?.at).toBeCloseTo(0.2, 6)
  })
})

describe('schedule — determinism', () => {
  test('same inputs → identical outputs (no wall-clock, no Math.random)', () => {
    const a = schedule(plan(), opts)
    const b = schedule(plan(), opts)
    expect(a).toEqual(b)
  })

  test('different seed → different humanize (when humanizeSec > 0)', () => {
    const plan1 = plan()
    const optsA = { ...opts, humanizeSec: 0.01, seed: 1 }
    const optsB = { ...opts, humanizeSec: 0.01, seed: 2 }
    const a = schedule(plan1, optsA)
    const b = schedule(plan1, optsB)
    // Same count, but at least one time should differ.
    expect(a).toHaveLength(b.length)
    const someDiff = a.some((e, i) => e.at !== b[i].at)
    expect(someDiff).toBe(true)
  })

  test('same seed → identical humanize', () => {
    const plan1 = plan()
    const o = { ...opts, humanizeSec: 0.02, seed: 42 }
    const a = schedule(plan1, o)
    const b = schedule(plan1, o)
    expect(a).toEqual(b)
  })
})

describe('schedule — swing', () => {
  test('swing delays odd steps (16th swing)', () => {
    const t = emptyTrack('hat', 'hat', 42, 16, 0.1)
    for (let i = 0; i < 16; i++) t.steps[i] = step({ on: true })
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }

    const straight = schedule(p, { ...opts, swing: 0 })
    const swung = schedule(p, { ...opts, swing: 0.25 })

    // Even steps (0, 2, 4, ...) unchanged.
    for (let i = 0; i < 16; i += 2) {
      expect(straight[i].at).toBeCloseTo(swung[i].at, 6)
    }
    // Odd steps delayed.
    for (let i = 1; i < 16; i += 2) {
      expect(swung[i].at).toBeGreaterThan(straight[i].at)
    }
  })
})

describe('schedule — probability', () => {
  test('prob=0 → no events', () => {
    const t = emptyTrack('lead', 'lead', 60, 4, 0.5)
    t.steps[0] = step({ on: true, prob: 0 })
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }
    const evs = schedule(p, opts)
    expect(evs).toHaveLength(0)
  })

  test('prob=1 → all events', () => {
    const t = emptyTrack('lead', 'lead', 60, 4, 0.5)
    t.steps[0] = step({ on: true, prob: 1 })
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }
    const evs = schedule(p, opts)
    expect(evs).toHaveLength(1)
  })

  test('prob is deterministic given the same seed', () => {
    const t = emptyTrack('lead', 'lead', 60, 16, 0.5)
    for (let i = 0; i < 16; i++) t.steps[i] = step({ on: true, prob: 0.5 })
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }
    const o = { ...opts, seed: 7 }
    const a = schedule(p, o)
    const b = schedule(p, o)
    expect(a).toEqual(b)
    // At least some survived the gate (probabilistic, but with 16 trials at p=0.5
    // the chance of zero is ~1.5e-5).
    expect(a.length).toBeGreaterThan(0)
    expect(a.length).toBeLessThan(16)
  })
})

describe('schedule — multi-bar', () => {
  test('schedules across multiple bars', () => {
    const evs = schedule(plan(4), opts)
    // 8 events/bar * 4 bars = 32
    expect(evs).toHaveLength(32)
    // First event at t=0, last event near end of bar 4.
    expect(evs[0].at).toBeCloseTo(0, 6)
    const secPerBar = (60 / 150) * 4
    expect(evs[evs.length - 1].at).toBeLessThan(4 * secPerBar)
  })

  test('fromBar offset shifts all events', () => {
    const p: MusicalPlan = { tracks: [kickTrack()], fromBar: 2, barCount: 1 }
    const evs = schedule(p, opts)
    const secPerBar = (60 / 150) * 4
    // First kick at bar 2 = 2 * secPerBar
    expect(evs[0].at).toBeCloseTo(2 * secPerBar, 6)
  })
})

describe('schedule — per-step locks', () => {
  test('emits param events for step.lock', () => {
    const t = emptyTrack('bass', 'bass', 43, 4, 0.5)
    t.steps[0] = step({ on: true, lock: { cutoff: 0.9 } })
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }
    const evs = schedule(p, opts)
    expect(evs).toHaveLength(2) // 1 note + 1 param
    const param = evs.find((e) => e.type === 'param')
    expect(param).toBeDefined()
    if (param && param.type === 'param') {
      expect(param.param).toBe('cutoff')
      expect(param.value).toBe(0.9)
    }
  })
})

describe('schedule — polyrhythm', () => {
  test('tracks with different step counts coexist', () => {
    const t3 = emptyTrack('a', 'a', 60, 3, 0.5) // 3 steps per bar
    const t4 = emptyTrack('b', 'b', 62, 4, 0.5) // 4 steps per bar
    t3.steps[0] = step({ on: true })
    t4.steps[0] = step({ on: true })
    const p: MusicalPlan = { tracks: [t3, t4], fromBar: 0, barCount: 1 }
    const evs = schedule(p, opts)
    expect(evs).toHaveLength(2)
    // Both first steps land at t=0.
    expect(evs[0].at).toBeCloseTo(0, 6)
    expect(evs[1].at).toBeCloseTo(0, 6)
    // Track a's step 1 at 1/3 of a bar; track b's step 1 at 1/4.
    const secPerBar = (60 / 150) * 4
    void secPerBar
  })
})

describe('schedule — empty / edge cases', () => {
  test('empty plan → empty events', () => {
    const p: MusicalPlan = { tracks: [], fromBar: 0, barCount: 1 }
    expect(schedule(p, opts)).toHaveLength(0)
  })

  test('track with no active steps → no events for that track', () => {
    const t = emptyTrack('silent', 'silent', 60, 16, 0.5)
    const p: MusicalPlan = { tracks: [t], fromBar: 0, barCount: 1 }
    expect(schedule(p, opts)).toHaveLength(0)
  })

  test('barCount=0 → empty', () => {
    const p: MusicalPlan = { tracks: [kickTrack()], fromBar: 0, barCount: 0 }
    expect(schedule(p, opts)).toHaveLength(0)
  })
})
