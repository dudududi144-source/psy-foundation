# psy-foundation architecture

## Origin

Built from the forensic audit of 7 existing PSY-family repositories
(`psy`, `psy3-clean`, `psy4`, `psy5`, `forge`, `nova`, `PromptForge`).
Full audit findings live in the project worklog; the condensed reusable /
retire tables live here.

## What we extracted (verified by reading code, not READMEs)

| Asset | Source | Target package |
| --- | --- | --- |
| BeatPLL (octave-error folding, `predictBeats`) | `psy4/src/lib/beatPLL.ts` | `transport` |
| Forensic offline renderer + voices + DSP (Moog/polyBLEP/FFT/LUFS) | `psy4/src/lib/studio/engine/forensic/*` | `analysis`, `dsp` |
| mulberry32 Rng + sample-accurate Transport + wavetable | `psy4/src/lib/studio/{rng,clock,dsp/wavetable}.ts` | `transport`, `dsp`, `music` |
| Reference training loop (closed-loop optimizer) | `psy4/src/lib/studio/engine/reference/*` | `learning` (ADAPT to context/action/outcome) |
| Melody observer + scale detection + pattern mutator | `psy4/src/lib/{melodyObserver,learning,patternMutator}.ts` | `analysis`, `music` |
| Lead motif generator (call-&-response, stable tones, accents) | `psy/index.html:200-281` | `music` |
| PooledEngine + SynthVoice + DrumVoice (lifelong oscillators) | `psy5/index.html:354-372` | `dsp` |
| `makeTimerWorker` factory (Web Worker timer + fallback) | `psy5/index.html:133-146` | `scheduler` |
| Step/Pattern/Project schema (`{on,vel,prob,micro,note,lock}`, gcd loop) | `psy5/index.html:160-186` | `material` |
| OfflineAudioContext self-gate harness | `psy5/index.html:407-412` | `fixtures` (as pattern) |

## What we retired (and why)

| Asset | Source | Reason |
| --- | --- | --- |
| `psy4EngineV2.ts` (5485 lines) + glue | `psy4/src/lib/studio/engine/` | Dead hub. Never instantiated. Couples clean modules to a giant core. |
| Worklet wrappers + `pooledEngine.ts` | `psy4/...` | Orphan. DSP already ported to forensic cluster. |
| `soundBank.ts` (688 lines) | `psy4/src/lib/soundBank.ts` | Dead import. 4 inline presets used instead. |
| `audit-reports/*.md` | `psy4/audit-reports/` | Fabricated. Claim "14/14 tests passed" — no test runner exists. |
| `psy3-clean` (whole repo) | — | 4-line patch of `psy`. No unique value after worker-timer extraction. |
| `psy5` state model | `psy5/index.html` | **Origin of the PSY6 multi-source-of-truth disease.** 4-layer cutoff, dual-DOM writers. |
| `factory-presets.js`, `psy/soundBank.js` | — | Byte-identical duplicates, never loaded. |
| `forge` (almost all) | — | Vaporware. Only Prisma skeleton + libSQL adapter worth keeping as a seed. |
| `PromptForge` | — | Python, stub agents. Separate universe. |
| 1065 vendored ClawHub skill files | `psy4/skills/` | Unrelated to PSY. Inflates repo to 115 MB. |

## Security

- `nova/nova-server.cjs:12` commits a **live Z.AI session JWT**
  (`userId 851fa622…`, `chatId chat-dc1fb2f6…`) in a public repo.
  `nova/worker.js:4` has the matching preview URL. **Action: rotate the
  session, scrub both files from git history.** Foundation never imports them.
- `psy4/.env` committed but only contains a local SQLite path — hygiene issue,
  not a leak. Action: untrack.
- All other env usage across the family is clean (env vars / `globalThis`
  settings, no hardcoded secrets).

## Ownership matrix (single source of truth)

| State | Owner | Readers |
| --- | --- | --- |
| transport (beat / bar / phase / bpm / confidence / revision) | `packages/transport` → `TransportClock` | all devices (read-only via subscription) |
| musical context (key / scale / energy / style / section) | `packages/music` → `MusicalContextStore` | devices, scheduler, learning |
| analysis features | `packages/analysis` → `FeatureStore` | transport estimator, music inference |
| arrangement | `packages/scheduler` → `ArrangementStore` | devices |
| scheduled events | `packages/scheduler` → `Scheduler` | audio renderers |
| device state | the device itself | foundation reads only `capabilities()` |
| learning state | `packages/learning` → `ExperienceStore` | music / scheduler (advisory) |
| audio time | `packages/dsp` → `AudioClock` (over `AudioContext`) | scheduler only |

Anything not in this table does not exist as owned state. Derived values are
computed on read, never stored as if they were owned.

## Transport contract

`Radio → Observation → Estimation → Musical Transport → Local Scheduler → Audio`

- `observedBeatTime` — raw timestamp from radio analysis.
- `estimatedBeatTime` — after filtering / PLL.
- `predictedBeatTime` — extrapolated to a future audio time.

These three never mix with `AudioContext.currentTime` without explicit latency
compensation.

## Build order

| Milestone | Packages | Exit criterion |
| --- | --- | --- |
| M0 | forensic audit | this document |
| M1 | transport · protocol · device-sdk · fixtures | MusicalTransport tracks all 14 fixtures; PsyDevice subscribes; events flow |
| M2 | scheduler · analysis | scheduler deterministic; analysis emits features from fixture signals |
| M3 | music · material | motif generator + material library + schema |
| M4 | learning | ExperienceStore; `DO NOTHING` legal; reward tracking |
| M5 | dsp | PooledEngine ported; forensic DSP ported; A/B benchmarks |
| M6 | reference-lab · sync-lab · benchmark-lab | three usable research apps |

Every milestone: inspect → implement → test → benchmark → build → git diff →
commit → push.
