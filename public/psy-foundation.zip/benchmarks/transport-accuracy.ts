/**
 * Transport accuracy benchmark.
 *
 * For each fixture in the synthetic corpus, feeds ground-truth beats into a
 * TransportClock one at a time and measures the ONLINE PREDICTION ERROR:
 * before feeding beat i, what did the transport predict for time t_i?
 *
 * Metrics per fixture:
 *   - mean / median / P95 absolute phase error (milliseconds)
 *   - bpm error vs ground truth (where known)
 *   - lock rate (fraction of beats where transport reported locked)
 *
 * This is the quantitative evidence that the transport works. A test asserts
 * "bpm converges"; a benchmark asserts "median phase error < 15ms on perfect".
 *
 * Run:  bun run benchmarks:transport
 *       (or) bun benchmarks/transport-accuracy.ts
 */

import { corpus } from '../packages/fixtures/src/index.ts'
import type { Fixture } from '../packages/fixtures/src/index.ts'
import { TransportClock } from '../packages/transport/src/index.ts'

interface FixtureMetrics {
  id: string
  anomaly: string
  samples: number
  meanMs: number
  medianMs: number
  p95Ms: number
  maxMs: number
  bpmError: number | null
  lockRate: number
}

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0
  const pos = (sorted.length - 1) * q
  const lo = Math.floor(pos)
  const hi = Math.ceil(pos)
  if (lo === hi) return sorted[lo] ?? 0
  const frac = pos - lo
  return (sorted[lo] ?? 0) * (1 - frac) + (sorted[hi] ?? 0) * frac
}

function benchmarkFixture(fixture: Fixture): FixtureMetrics {
  const beats = fixture.groundTruthBeats
  const clock = new TransportClock({ initialBpm: 130 })
  const errorsMs: number[] = []
  let lockedCount = 0
  let measured = 0

  // Warmup: feed the first 4 beats without measuring.
  const warmup = Math.min(4, beats.length)
  for (let i = 0; i < warmup; i++) {
    clock.observe({ observedAt: beats[i] ?? 0, strength: 1 })
  }

  // Online prediction: before feeding beat i, predict at beats[i].
  for (let i = warmup; i < beats.length; i++) {
    const t = beats[i]
    if (t === undefined) continue
    const snap = clock.snapshot(t)
    if (snap.locked) lockedCount += 1
    measured += 1
    // At a true beat, phase should be ~0. Phase error in beats = |phase - 0|
    // but phase wraps, so distance-to-nearest-integer-beat:
    const secPerBeat = 60 / snap.bpm
    // predicted beat index (float) vs the integer it should be:
    const predicted = clock.predict(t)
    const nearest = Math.round(predicted)
    const phaseErrorBeats = Math.abs(predicted - nearest)
    const phaseErrorSec = phaseErrorBeats * secPerBeat
    errorsMs.push(phaseErrorSec * 1000)
    // Now feed the beat (the transport learns from it).
    clock.observe({ observedAt: t, strength: 1 })
  }

  errorsMs.sort((a, b) => a - b)
  const sum = errorsMs.reduce((a, b) => a + b, 0)
  const mean = errorsMs.length ? sum / errorsMs.length : 0

  let bpmError: number | null = null
  if (fixture.groundTruthBpm !== null) {
    const finalSnap = clock.snapshot(beats[beats.length - 1] ?? 0)
    bpmError = Math.abs(finalSnap.bpm - fixture.groundTruthBpm)
  }

  return {
    id: fixture.id,
    anomaly: fixture.anomaly,
    samples: measured,
    meanMs: mean,
    medianMs: quantile(errorsMs, 0.5),
    p95Ms: quantile(errorsMs, 0.95),
    maxMs: errorsMs[errorsMs.length - 1] ?? 0,
    bpmError,
    lockRate: measured ? lockedCount / measured : 0,
  }
}

function formatMs(v: number): string {
  return v < 10 ? v.toFixed(2) : v.toFixed(1)
}

function main(): void {
  const metrics: FixtureMetrics[] = corpus.map(benchmarkFixture)

  const idW = Math.max(8, ...metrics.map((m) => m.id.length))
  const anomW = 14
  const header =
    `${'fixture'.padEnd(idW)}  ${'anomaly'.padEnd(anomW)}  ${'n'.padStart(4)}  ` +
    `${'mean'.padStart(7)}  ${'median'.padStart(7)}  ${'p95'.padStart(7)}  ` +
    `${'max'.padStart(7)}  ${'bpmΔ'.padStart(6)}  ${'lock%'.padStart(5)}`
  console.log(header)
  console.log('-'.repeat(header.length))
  for (const m of metrics) {
    console.log(
      `${m.id.padEnd(idW)}  ${m.anomaly.padEnd(anomW)}  ${String(m.samples).padStart(4)}  ` +
        `${formatMs(m.meanMs).padStart(7)}  ${formatMs(m.medianMs).padStart(7)}  ` +
        `${formatMs(m.p95Ms).padStart(7)}  ${formatMs(m.maxMs).padStart(7)}  ` +
        `${(m.bpmError ?? '-').toString().padStart(6)}  ` +
        `${(m.lockRate * 100).toFixed(0).padStart(5)}`
    )
  }
  console.log('-'.repeat(header.length))

  // Machine-readable JSON to stdout as a second block (for CI / forge).
  console.log('\n--- JSON ---')
  console.log(JSON.stringify(metrics, null, 2))
}

main()
