/**
 * Analysis benchmark — runs the full analysis pipeline (onset detection +
 * multi-hypothesis tempo estimation + refinement) on every fixture in the
 * corpus and reports the estimated bpm vs ground truth.
 *
 * This is the quantitative evidence that:
 *  1. The analysis pipeline correctly estimates tempo from synthetic audio
 *     (not just from pre-labeled beat times).
 *  2. The M1 sparse-fixture limitation is FIXED: the sparse fixture now
 *     estimates 150 BPM (not 75) thanks to refineTempoWithContext.
 *
 * Run:  bun run benchmarks:analysis
 *       (or) bun benchmarks/analysis-accuracy.ts
 */

import { detectOnsets, estimateTempo, pickMusicalWinner } from '../packages/analysis/src/index.ts'
import { refineTempoWithContext } from '../packages/analysis/src/inference.ts'
import { corpus } from '../packages/fixtures/src/index.ts'
import type { Fixture } from '../packages/fixtures/src/index.ts'

interface AnalysisMetric {
  id: string
  anomaly: string
  onsetsDetected: number
  estimatedBpm: number
  groundTruthBpm: number | null
  bpmError: number | null
  fixed: boolean // true if refinement changed the result
}

function benchmarkFixture(fixture: Fixture): AnalysisMetric {
  const onsets = detectOnsets(fixture.signal, {
    sampleRate: fixture.sampleRate,
    frameSize: 1024,
    hopSize: 512,
  })

  const { top } = estimateTempo(onsets)
  const refined = top.map((h) => refineTempoWithContext(h, onsets))
  const winner = pickMusicalWinner(refined)

  const estimatedBpm = winner?.bpm ?? 0
  const groundTruthBpm = fixture.groundTruthBpm
  const bpmError = groundTruthBpm !== null ? Math.abs(estimatedBpm - groundTruthBpm) : null

  // Check if refinement changed the result (compare raw best vs refined winner).
  const rawBest = top[0]?.bpm ?? 0
  const fixed = Math.abs(rawBest - estimatedBpm) > 0.5

  return {
    id: fixture.id,
    anomaly: fixture.anomaly,
    onsetsDetected: onsets.length,
    estimatedBpm,
    groundTruthBpm,
    bpmError,
    fixed,
  }
}

function main(): void {
  const metrics: AnalysisMetric[] = corpus.map(benchmarkFixture)

  const idW = Math.max(8, ...metrics.map((m) => m.id.length))
  const header =
    `${'fixture'.padEnd(idW)}  ${'anomaly'.padEnd(14)}  ${'onsets'.padStart(6)}  ` +
    `${'est bpm'.padStart(8)}  ${'truth bpm'.padStart(9)}  ${'error'.padStart(7)}  ${'refined'.padStart(8)}`
  console.log(header)
  console.log('-'.repeat(header.length))

  let sparseFixed = false
  for (const m of metrics) {
    const errStr = m.bpmError !== null ? m.bpmError.toFixed(1) : '—'
    const truthStr = m.groundTruthBpm !== null ? m.groundTruthBpm.toString() : '—'
    console.log(
      `${m.id.padEnd(idW)}  ${m.anomaly.padEnd(14)}  ${String(m.onsetsDetected).padStart(6)}  ` +
        `${m.estimatedBpm.toFixed(1).padStart(8)}  ${truthStr.padStart(9)}  ${errStr.padStart(7)}  ` +
        `${(m.fixed ? 'YES' : 'no').padStart(8)}`
    )
    if (m.id === 'sparse') {
      sparseFixed = m.fixed && (m.bpmError ?? 999) < 10
    }
  }
  console.log('-'.repeat(header.length))

  // Highlight the M1 sparse fix.
  console.log('')
  if (sparseFixed) {
    console.log('✓ M1 SPARSE FIX VERIFIED: sparse fixture now estimates ~150 BPM (was 75 in M1).')
  } else {
    console.log('✗ SPARSE FIX NOT WORKING — sparse fixture did not converge to 150 BPM.')
  }

  // JSON output for CI.
  console.log('\n--- JSON ---')
  console.log(JSON.stringify(metrics, null, 2))
}

main()
